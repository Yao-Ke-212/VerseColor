import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'
dotenv.config()

const supabaseUrl = process.env.VITE_SUPABASE_URL
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

async function test() {
  const { data } = await supabase.from('colors').select('color_family');
  const families = [...new Set(data.map(d => d.color_family))];
  console.log("Distinct families:", families.map(f => `'${f}'`));
}
test()
