import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'
dotenv.config()

const supabaseUrl = process.env.VITE_SUPABASE_URL
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

async function test() {
  let query = supabase
    .from('colors')
    .select('*, poems(id, poet, dynasty, color_sentence)', { count: 'exact' })
    .eq('color_family', '青蓝系');
  
  const { data, error, count } = await query;
  console.log("Data length:", data?.length)
  console.log("Error:", error)
}
test()
