import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import ColorDetailPage from './pages/ColorDetailPage';
import VisualizationPage from './pages/VisualizationPage';
import MyCollectionPage from './pages/MyCollectionPage';
import LoginPage from './pages/LoginPage';
import PoetsPage from './pages/PoetsPage';
import PoetDetailPage from './pages/PoetDetailPage';
import PoemDetailPage from './pages/PoemDetailPage';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** 无需登录即可访问 */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: '首页',
    path: '/',
    element: <HomePage />,
    public: true,
    visible: true,
  },
  {
    name: '色彩检索',
    path: '/search',
    element: <SearchPage />,
    public: true,
    visible: true,
  },
  {
    name: '色彩详情',
    path: '/color/:id',
    element: <ColorDetailPage />,
    public: true,
    visible: false,
  },
  {
    name: '诗人',
    path: '/poets',
    element: <PoetsPage />,
    public: true,
    visible: true,
  },
  {
    name: '诗人详情',
    path: '/poet/:name',
    element: <PoetDetailPage />,
    public: true,
    visible: false,
  },
  {
    name: '诗词详情',
    path: '/poem/:id',
    element: <PoemDetailPage />,
    public: true,
    visible: false,
  },
  {
    name: '可视化',
    path: '/visualization',
    element: <VisualizationPage />,
    public: true,
    visible: true,
  },
  {
    name: '我的色彩集',
    path: '/my-collection',
    element: <MyCollectionPage />,
    public: false,
    visible: true,
  },
  {
    name: '登录',
    path: '/login',
    element: <LoginPage />,
    public: true,
    visible: false,
  },
];
