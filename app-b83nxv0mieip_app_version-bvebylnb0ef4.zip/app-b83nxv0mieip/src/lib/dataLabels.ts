/**
 * 数据标签翻译工具函数
 * 用于将数据库中的中文固定值（色系、朝代、情感标签）转换为当前语言显示名
 */
import type { TranslationKey } from '@/i18n';
import { pinyin } from 'pinyin-pro';

type TFunc = (key: TranslationKey) => string;

/** 将任意中文字符串转为带声调拼音（首字母大写） */
function toPinyin(text: string): string {
  return pinyin(text, { toneType: 'symbol', type: 'array', nonZh: 'consecutive' })
    .map(syl => syl.charAt(0).toUpperCase() + syl.slice(1))
    .join(' ');
}

/**
 * 将中文色彩名转换为带声调的拼音（非中文模式使用）
 * 例：赭石 → Zhě Shí，天水碧 → Tiān Shuǐ Bì
 */
export function getColorDisplayName(name: string, isChinese: boolean): string {
  if (isChinese || !name) return name;
  return toPinyin(name);
}

/**
 * 诗人/古籍英文/拼音标准化名称映射
 * 包含学界通用罗马拼写；未在映射表中的诗人自动转为 pinyin-pro 声调拼音
 */
const POET_EN_MAP: Record<string, string> = {
  '李白': 'Li Bai',
  '杜甫': 'Du Fu',
  '苏轼': 'Su Shi',
  '李清照': 'Li Qingzhao',
  '白居易': 'Bai Juyi',
  '王维': 'Wang Wei',
  '辛弃疾': 'Xin Qiji',
  '陶渊明': 'Tao Yuanming',
  '杜牧': 'Du Mu',
  '李商隐': 'Li Shangyin',
  '欧阳修': 'Ouyang Xiu',
  '孟浩然': 'Meng Haoran',
  '王昌龄': 'Wang Changling',
  '柳宗元': 'Liu Zongyuan',
  '温庭筠': 'Wen Tingyun',
  '秦观': 'Qin Guan',
  '晏殊': 'Yan Shu',
  '晏几道': 'Yan Jidao',
  '姜夔': 'Jiang Kui',
  '曹操': 'Cao Cao',
  '曹植': 'Cao Zhi',
  '屈原': 'Qu Yuan',
  '元稹': 'Yuan Zhen',
  '冯延巳': 'Feng Yansi',
  '刘禹锡': 'Liu Yuxi',
  '周邦彦': 'Zhou Bangyan',
  '唐寅': 'Tang Yin',
  '孟郊': 'Meng Jiao',
  '岑参': 'Cen Shen',
  '张九龄': 'Zhang Jiuling',
  '张若虚': 'Zhang Ruoxu',
  '文天祥': 'Wen Tianxiang',
  '李煜': 'Li Yu',
  '李贺': 'Li He',
  '杨万里': 'Yang Wanli',
  '范仲淹': 'Fan Zhongyan',
  '贺知章': 'He Zhizhang',
  '陆游': 'Lu You',
  '陈子昂': 'Chen Ziang',
  '韩愈': 'Han Yu',
  '马致远': 'Ma Zhiyuan',
  '高适': 'Gao Shi',
  '纳兰性德': 'Nalan Xingde',
  '龚自珍': 'Gong Zizhen',
  '苏舜钦': 'Su Shunqin',
  '王建': 'Wang Jian',
  // 古籍
  '诗经': 'Book of Songs',
  '《诗经》': 'Book of Songs',
  '楚辞': 'Chu Ci',
  '《楚辞》': 'Chu Ci',
  '乐府': 'Yuefu',
  '乐府诗集': 'Yuefu Shiji',
  '《乐府诗集》': 'Yuefu Shiji',
  '汉乐府': 'Han Yuefu',
  '《汉乐府》': 'Han Yuefu',
  '古诗十九首': 'Nineteen Ancient Poems',
  '《古诗十九首》': 'Nineteen Ancient Poems',
};

/**
 * 获取诗人/古籍的非中文显示名
 * 有标准英文罗马化 → 返回英文；否则 → 拼音
 */
export function getPoetDisplayName(name: string, isChinese: boolean): string {
  if (isChinese || !name) return name;
  return POET_EN_MAP[name] ?? toPinyin(name);
}

/**
 * 翻译色彩家族名称（如"红色系"→"Reds"），无翻译时返回拼音
 */
export function getColorFamilyLabel(family: string, t: TFunc): string {
  const key = `cf_${family}` as TranslationKey;
  const result = t(key);
  if (result !== key) return result;
  // 判断当前语言是否中文（利用中文色系原文作为无翻译的标志）
  // 若 t('cf_红色系') 返回原 key，说明该语言无翻译键，则用拼音
  const zhCheck = t('cf_红色系' as TranslationKey);
  const isChinese = zhCheck === '红色系' || zhCheck === 'cf_红色系';
  return isChinese ? family : toPinyin(family.replace('系', ''));
}

/**
 * 翻译朝代名称（如"唐"→"Tang"），无翻译时返回拼音
 */
export function getDynastyLabel(dynasty: string, t: TFunc): string {
  const key = `dyn_${dynasty}` as TranslationKey;
  const result = t(key);
  if (result !== key) return result;
  
  const zhCheck = t('dyn_唐' as TranslationKey);
  const isChinese = zhCheck === '唐' || zhCheck === 'dyn_唐';
  return isChinese ? dynasty : toPinyin(dynasty);
}

/**
 * 翻译情感标签（如"柔美"→"Gentle"），无翻译时返回拼音
 */
export function getEmotionLabel(emotion: string, t: TFunc): string {
  const key = `em_${emotion}` as TranslationKey;
  const result = t(key);
  if (result !== key) return result;
  
  const zhCheck = t('em_离愁别绪' as TranslationKey);
  const isChinese = zhCheck === '离愁别绪' || zhCheck === 'em_离愁别绪';
  return isChinese ? emotion : toPinyin(emotion);
}

/**
 * 翻译时节名称，无翻译时返回原词或拼音
 */
export function getSeasonLabel(season: string, t: TFunc): string {
  const key = `season_${season}` as TranslationKey;
  const result = t(key);
  return result === key ? season : result;
}

/**
 * 翻译地域空间名称，无翻译时返回原词或拼音
 */
export function getRegionLabel(region: string, t: TFunc): string {
  const key = `region_${region}` as TranslationKey;
  const result = t(key);
  return result === key ? region : result;
}

/**
 * 翻译物象类型名称，无翻译时返回原词或拼音
 */
export function getImageryCategoryLabel(category: string, t: TFunc): string {
  const key = `imagery_category_${category}` as TranslationKey;
  const result = t(key);
  return result === key ? category : result;
}
