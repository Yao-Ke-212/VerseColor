/**
 * 诗人/古籍共享数据
 * PoetsPage 与 PoetDetailPage 均从此处导入，保证图像来源一致。
 */

/** 诗人历史画像 URL（优先使用传世画像） */
export const POET_PORTRAITS: Record<string, string> = {
  '李白': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_52fbde8b-8c6b-407a-b6f3-c48cce0c2173.jpg',
  '杜甫': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_53588f2c-2a38-4611-906a-677b567e8b0d.jpg',
  '苏轼': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_fd549017-6fd0-48d4-abf8-0c92c7af3cea.jpg',
  '李清照': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_d8f5f5dc-09f0-4ee7-87e2-4132cc840d7c.jpg',
  '白居易': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_9c096b19-45f5-49ac-9489-e784cfc5bdca.jpg',
  '王维': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_7d348176-005e-4bbc-806f-dc9c4da13f2a.jpg',
  '辛弃疾': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_407f4020-1d82-4958-ac8d-e4322a6984cd.jpg',
  '陶渊明': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_af5406db-b1d4-40fe-b992-910a8e895ad9.jpg',
  '杜牧': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_a94a12c7-8129-4bfc-a99b-9de6a408c8fe.jpg',
  '李商隐': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_af7ff11b-58f6-4945-bd36-094b940944a5.jpg',
  '欧阳修': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_7f851056-0d74-48b0-8876-e7777970e2f0.jpg',
  '孟浩然': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_71834c55-0f7c-432d-9b28-b7329a10f965.jpg',
  '王昌龄': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_712f945f-e20e-4701-96a8-4260880fa542.jpg',
  '柳宗元': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_49e64a10-4756-48bb-b218-d2952df8489b.jpg',
  '温庭筠': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_615bd341-26fe-4874-8360-6041e7209d8f.jpg',
  '秦观': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_eae98ee3-f2b0-4d5b-b7fc-33195cbb5a80.jpg',
  '晏殊': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_6f878f8a-550d-46a8-9bc7-089eac57297c.jpg',
  '姜夔': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_80d63ad5-806d-4c76-af48-bfc719232810.jpg',
  '曹操': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_597fe1f4-9c39-4f62-81d9-7421524d5f5f.jpg',
  '屈原': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_c537287d-c2de-448d-868e-44878359a827.jpg',
};

/**
 * 古籍封面图片（优先使用实物照片/影印件）
 * 同时覆盖带《》书名号和不带书名号两种格式，与数据库 poet 字段完全对应。
 */
export const BOOK_COVERS: Record<string, string> = {
  '诗经': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_2f847f4f-5e24-466a-bd50-e4f117b23bef.jpg',
  '《诗经》': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_2f847f4f-5e24-466a-bd50-e4f117b23bef.jpg',
  '楚辞': 'https://miaoda-site-img.cdn.bcebos.com/images/MiaoTu_fdcbfd04-d5a6-47cd-8dbf-bdbcc9eae61d.jpg',
  '《楚辞》': 'https://miaoda-site-img.cdn.bcebos.com/images/MiaoTu_fdcbfd04-d5a6-47cd-8dbf-bdbcc9eae61d.jpg',
  '乐府': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_4fa75fbc-4fba-4314-bc5c-047cb2ebea6e.jpg',
  '乐府诗集': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_f9fec477-86bf-42c6-85c0-2a82c174bb69.jpg',
  '《乐府诗集》': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_f9fec477-86bf-42c6-85c0-2a82c174bb69.jpg',
  '汉乐府': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_4fa75fbc-4fba-4314-bc5c-047cb2ebea6e.jpg',
  '《汉乐府》': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_4fa75fbc-4fba-4314-bc5c-047cb2ebea6e.jpg',
  '古诗十九首': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_0d541246-3b20-41f2-9ff4-9292308f227b.jpg',
  '《古诗十九首》': 'https://miaoda-site-img.cdn.bcebos.com/images/baidu_image_search_0d541246-3b20-41f2-9ff4-9292308f227b.jpg',
};

/** 集体作者/书籍条目名称集合（数据库中有带书名号《》和不带两种形式） */
export const BOOK_ENTRIES = new Set([
  '古诗十九首', '《古诗十九首》',
  '乐府', '乐府诗集', '《乐府诗集》',
  '诗经', '《诗经》',
  '楚辞', '《楚辞》',
  '汉乐府', '《汉乐府》',
  '民间',
]);

/** 诗人代表色（与数据库色彩系统对应） */
export const POET_DOMINANT_COLORS: Record<string, { hex: string; name: string }> = {
  '李白': { hex: '#B5D5E8', name: '天水碧' },
  '杜甫': { hex: '#7B6952', name: '赭石' },
  '苏轼': { hex: '#4A8B7B', name: '竹青' },
  '李清照': { hex: '#D4849A', name: '胭脂' },
  '白居易': { hex: '#9C5F5F', name: '朱砂' },
  '王维': { hex: '#688A68', name: '翠绿' },
  '辛弃疾': { hex: '#8B3A3A', name: '绛红' },
  '陶渊明': { hex: '#7A9A7A', name: '松绿' },
  '杜牧': { hex: '#C87B4E', name: '橙黄' },
  '李商隐': { hex: '#7B5A8B', name: '紫色' },
  '欧阳修': { hex: '#4A6B8B', name: '石青' },
  '孟浩然': { hex: '#6B8B6B', name: '碧色' },
  '王昌龄': { hex: '#8B6B4A', name: '黄褐' },
  '柳宗元': { hex: '#4A7B4A', name: '绿色' },
  '温庭筠': { hex: '#C8849C', name: '粉红' },
  '秦观': { hex: '#B5A5C8', name: '淡紫' },
  '晏殊': { hex: '#D4B896', name: '茶色' },
  '姜夔': { hex: '#A8B8C8', name: '白青' },
  '曹操': { hex: '#3A3A3A', name: '墨色' },
  '屈原': { hex: '#4A6B9C', name: '深蓝' },
};

/** 朝代代表色（当诗人无专属代表色时使用） */
export const DYNASTY_COLOR_MAP: Record<string, string> = {
  '先秦': '#6B5A4A', '汉': '#8B7355', '魏晋': '#6B7B5A', '南北朝': '#5A7B6B',
  '唐': '#3D4A5C', '宋': '#3A8B7A', '元': '#5B8B9C', '明': '#8B4A5A', '清': '#6B5A8B',
};

/** 根据诗人名获取背景色（代表色 → 朝代色 → 默认） */
export function getPoetBgColor(name: string, dynasty: string): string {
  return POET_DOMINANT_COLORS[name]?.hex
    || DYNASTY_COLOR_MAP[dynasty]
    || '#3D4A5C';
}
