import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { type LangCode, type TranslationKey, translations, LANGUAGES, LANG_STORAGE_KEY } from '@/i18n';

interface LangContextValue {
  lang: LangCode;
  setLang: (lang: LangCode) => void;
  t: (key: TranslationKey) => string;
  languages: typeof LANGUAGES;
}

const LangContext = createContext<LangContextValue | null>(null);

export function LangProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<LangCode>(() => {
    const stored = localStorage.getItem(LANG_STORAGE_KEY) as LangCode | null;
    return stored && translations[stored] ? stored : 'zh-CN';
  });

  const setLang = useCallback((newLang: LangCode) => {
    setLangState(newLang);
    localStorage.setItem(LANG_STORAGE_KEY, newLang);
  }, []);

  const t = useCallback((key: TranslationKey): string => {
    const dict = translations[lang] as Record<string, string>;
    return dict[key] ?? (translations['zh-CN'] as Record<string, string>)[key] ?? key;
  }, [lang]);

  // 同步 html lang 属性
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <LangContext.Provider value={{ lang, setLang, t, languages: LANGUAGES }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LangContext);
  if (!ctx) throw new Error('useLang must be used within LangProvider');
  return ctx;
}
