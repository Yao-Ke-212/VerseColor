// 数据类型定义 - 诗色·中华诗词色彩库

export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  username: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Color {
  id: string;
  name: string;
  hex_value: string;
  rgb_r: number;
  rgb_g: number;
  rgb_b: number;
  color_family: string;
  ancient_source: string | null;
  dye_craft: string | null;
  modern_evidence: string | null;
  cultural_interpretation: string | null;
  historical_story: string | null;
  emotion_tags: string[];
  sort_order: number;
  created_at: string;
}

export interface Poem {
  id: string;
  color_id: string;
  poem_title: string;
  full_text: string;
  color_sentence: string;
  poet: string;
  dynasty: string;
  creation_background: string | null;
  annotation: string | null;
  background?: string | null;
  translation?: string | null;
  poem_translation?: string | null;
  poem_annotation?: string | null;
  poetry_appreciation?: string | null;
  imagery_tags?: string[];
  imagery_category?: string | null;
  color_meaning: string | null;
  region: string | null;
  emotion_tags: string[];
  /** 人工审核的关联类型：direct=文本直接提及，indirect=文化解读，null=自动判断 */
  mention_type: 'direct' | 'indirect' | null;
  created_at: string;
}

export interface PoemWithColor extends Poem {
  colors?: Color;
}

export interface Favorite {
  id: string;
  user_id: string;
  color_id: string | null;
  poem_id: string | null;
  favorite_type: 'color' | 'poem';
  created_at: string;
}

export interface FavoriteWithDetail extends Favorite {
  colors?: Color | null;
  poems?: Poem | null;
}

// 检索过滤参数
export interface SearchFilters {
  keyword?: string;
  colorFamily?: string;
  dynasty?: string;
  poet?: string;
  emotion?: string;
}

// 色系列表
export const COLOR_FAMILIES = [
  '红色系', '橙黄系', '绿色系', '青蓝系', '紫色系', '黑色系', '白色系', '中性系'
] as const;

// 朝代列表
export const DYNASTIES = [
  '先秦', '汉', '魏晋', '南北朝', '隋', '唐',
  '五代', '宋', '金', '元', '明', '清', '近现代'
] as const;

// 时节列表
export const SEASONS = ['春', '夏', '秋', '冬', '其他'] as const;

// 地域空间列表
export const REGIONS = ['江南', '边塞', '中原', '巴蜀', '其他'] as const;

// 物象类型列表
export const IMAGERY_CATEGORIES = ['自然物象', '人物意象', '意境', '意象', '情感氛围'] as const;

// 情感意境标签（丰富细化分类）
export const EMOTION_TAGS = [
  // 情感类
  '柔美', '忧郁', '相思', '离愁', '喜悦', '壮美',
  '豪迈', '悲凉', '恬淡', '幽怨', '喜庆', '爱国',
  // 意象类
  '高洁', '神圣', '禅意', '书卷', '孤独', '清新',
  // 自然类
  '春天', '夏日', '秋天', '冬雪', '江南', '山水',
  '自然', '月夜', '风雨', '落花',
  // 场景类
  '边塞', '宫廷', '田园', '闺阁', '行旅',
] as const;

// 意象分类标签（用于诗词深度分类）
export const IMAGERY_TAGS = [
  '植物意象', '动物意象', '天象意象', '水文意象',
  '器物意象', '人物意象', '建筑意象', '色彩意象',
] as const;
