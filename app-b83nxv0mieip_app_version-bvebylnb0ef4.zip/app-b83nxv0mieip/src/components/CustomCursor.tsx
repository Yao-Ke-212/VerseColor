import { useEffect, useRef, useState, useCallback } from 'react';

/* ---------------------------------------------------------------
 * 自定义水墨圆形光标
 * 形态：正圆·实体墨环+淡填充·纯2D·清晰可见
 * 色系：鸦青实色环 + 月白半透明填充 + 烟青hover晕
 * 三态：静止(清晰实圆) / hover(放大+淡晕) / 点击(微缩+深色漾)
 * -------------------------------------------------------------- */

type CursorState = 'idle' | 'hover' | 'clicking';

export function CustomCursor() {
  const cursorRef  = useRef<HTMLDivElement>(null);
  const posRef     = useRef({ x: -100, y: -100 });
  const rafRef     = useRef<number>(0);
  const [state, setState]   = useState<CursorState>('idle');
  const [visible, setVisible] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  /* 触摸设备检测 */
  useEffect(() => {
    if (window.matchMedia('(pointer: coarse)').matches) setIsTouch(true);
  }, []);

  /* rAF 位置追踪 */
  useEffect(() => {
    const tick = () => {
      if (cursorRef.current) {
        const { x, y } = posRef.current;
        cursorRef.current.style.transform = `translate(${x}px, ${y}px)`;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  const onMouseMove = useCallback((e: MouseEvent) => {
    posRef.current = { x: e.clientX, y: e.clientY };
    if (!visible) setVisible(true);
  }, [visible]);

  /* 交互事件 */
  useEffect(() => {
    const isInteractive = (el: Element | null): boolean => {
      if (!el || el === document.documentElement) return false;
      const tag = el.tagName.toLowerCase();
      if (['a', 'button', 'select', 'label', 'input', 'textarea'].includes(tag)) return true;
      const role = el.getAttribute('role');
      if (role === 'button' || role === 'link' || role === 'tab' || role === 'menuitem') return true;
      if (el.getAttribute('data-interactive') !== null) return true;
      const cls = el.classList;
      if (cls.contains('cursor-pointer') || cls.contains('ink-ripple')) return true;
      return isInteractive(el.parentElement);
    };

    const onMove  = (e: MouseEvent) => {
      onMouseMove(e);
      setState(isInteractive(e.target as Element) ? 'hover' : 'idle');
    };
    const onDown  = () => setState('clicking');
    const onUp    = () => setState(s => s === 'clicking' ? 'idle' : s);
    const onLeave = () => setVisible(false);
    const onEnter = () => setVisible(true);

    document.addEventListener('mousemove',  onMove);
    document.addEventListener('mousedown',  onDown);
    document.addEventListener('mouseup',    onUp);
    document.addEventListener('mouseleave', onLeave);
    document.addEventListener('mouseenter', onEnter);
    return () => {
      document.removeEventListener('mousemove',  onMove);
      document.removeEventListener('mousedown',  onDown);
      document.removeEventListener('mouseup',    onUp);
      document.removeEventListener('mouseleave', onLeave);
      document.removeEventListener('mouseenter', onEnter);
    };
  }, [onMouseMove]);

  if (isTouch) return null;

  /* ── 视觉参数 ─────────────────────────────────────────────────
   * 静止：16px 实体鸦青环(2px) + 月白半透明填充
   * hover：24px 环(1.5px) + 外晕42px
   * 点击：12px 环(2.5px) 加深色，无外晕
   * ----------------------------------------------------------- */
  const mainSize   = state === 'hover' ? 24 : state === 'clicking' ? 12 : 16;
  const ringW      = state === 'hover' ? 1.5 : state === 'clicking' ? 2.5 : 2;

  /* 鸦青：hsl(197 22% 32%) — 深而不黑，雅致 */
  const ringColor  = state === 'clicking'
    ? 'hsla(197,28%,22%,0.92)'   /* 点击时加深 */
    : state === 'hover'
      ? 'hsla(197,22%,38%,0.82)' /* hover 稍浅 */
      : 'hsla(197,22%,32%,0.88)';/* 静止 清晰实色 */

  /* 月白填充：有一定不透明度，让圆点可见 */
  const fillColor  = state === 'clicking'
    ? 'hsla(197,22%,28%,0.22)'
    : state === 'hover'
      ? 'hsla(197,15%,88%,0.18)'
      : 'hsla(38,25%,96%,0.55)'; /* 静止：月白半透明，圆点清晰 */

  /* 外晕：hover 时才显示，烟青细环 */
  const haloSize   = state === 'hover' ? 42 : state === 'clicking' ? 26 : 0;
  const haloOpacity = state === 'hover' ? 0.28 : state === 'clicking' ? 0.20 : 0;
  const haloRingOp  = state === 'hover' ? 0.35 : state === 'clicking' ? 0.28 : 0;

  const mainTrans  = state === 'clicking'
    ? 'width 0.16s cubic-bezier(0.22,1,0.36,1), height 0.16s cubic-bezier(0.22,1,0.36,1), background 0.16s ease, border-color 0.16s ease, border-width 0.16s ease'
    : 'width 0.40s cubic-bezier(0.22,1,0.36,1), height 0.40s cubic-bezier(0.22,1,0.36,1), background 0.40s ease, border-color 0.40s ease, border-width 0.40s ease';

  const haloTrans  = state === 'clicking'
    ? 'all 0.24s cubic-bezier(0.22,1,0.36,1)'
    : 'all 0.52s cubic-bezier(0.22,1,0.36,1)';

  return (
    <div
      ref={cursorRef}
      aria-hidden="true"
      style={{
        position:      'fixed',
        top:           0,
        left:          0,
        pointerEvents: 'none',
        zIndex:        99999,
        willChange:    'transform',
        opacity:       visible ? 1 : 0,
        transition:    'opacity 0.2s ease',
      }}
    >
      {/* 外晕圆（hover / click 出现） */}
      <div
        style={{
          position:      'absolute',
          width:         haloSize,
          height:        haloSize,
          top:           -(haloSize / 2),
          left:          -(haloSize / 2),
          borderRadius:  '50%',
          border:        `1px solid hsla(197,18%,60%,${haloRingOp})`,
          background:    `hsla(197,18%,72%,${haloOpacity})`,
          transition:    haloTrans,
          pointerEvents: 'none',
        }}
      />

      {/* 主体正圆 */}
      <div
        style={{
          position:      'absolute',
          width:         mainSize,
          height:        mainSize,
          top:           -(mainSize / 2),
          left:          -(mainSize / 2),
          borderRadius:  '50%',
          border:        `${ringW}px solid ${ringColor}`,
          background:    fillColor,
          transition:    mainTrans,
          pointerEvents: 'none',
          mixBlendMode:  'multiply', /* 在浅色页面墨色自然融合 */
        }}
      />
    </div>
  );
}
