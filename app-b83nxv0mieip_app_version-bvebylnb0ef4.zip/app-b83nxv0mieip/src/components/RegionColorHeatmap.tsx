import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { Skeleton } from '@/components/ui/skeleton';
import { useLang } from '@/contexts/LangContext';
import { getColorDisplayName } from '@/lib/dataLabels';

interface RegionColorData {
  region: string;
  colors: Array<{ id: string; name: string; hex: string; count: number }>;
}

export function RegionColorHeatmap() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [data, setData] = useState<RegionColorData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: dbData } = await supabase
      .from('poems')
      .select('region, colors:color_id(id, name, hex_value)')
      .not('region', 'is', null);

    if (!dbData) { setLoading(false); return; }

    const regionMap = new Map<string, Map<string, { id: string; name: string; hex: string; count: number }>>();

    for (const row of dbData) {
      const region = row.region;
      const color = row.colors as unknown as { id: string; name: string; hex_value: string } | null;
      if (!region || !color) continue;

      if (!regionMap.has(region)) regionMap.set(region, new Map());
      const colorsMap = regionMap.get(region)!;
      
      if (!colorsMap.has(color.id)) {
        colorsMap.set(color.id, { id: color.id, name: color.name, hex: color.hex_value, count: 0 });
      }
      colorsMap.get(color.id)!.count++;
    }

    const result = Array.from(regionMap.entries()).map(([region, colorsMap]) => ({
      region,
      colors: Array.from(colorsMap.values()).sort((a, b) => b.count - a.count).slice(0, 10)
    }));

    setData(result);
    setLoading(false);
  };

  if (loading) return <Skeleton className="h-[400px] w-full rounded-xl bg-muted" />;

  return (
    <div className="card-rice-paper p-5 md:p-8 min-h-[500px]">
      <div className="mb-6 flex flex-col gap-2">
        <h2 className="text-xl font-kai font-semibold text-foreground">地域色彩分布热力图</h2>
        <p className="text-sm text-muted-foreground font-song">
          展示不同地域空间（江南、边塞、中原、巴蜀等）诗词中的色彩偏好分布，反映地域文化特征。
        </p>
      </div>

      {data.length === 0 ? (
        <p className="text-muted-foreground font-song text-sm text-center py-10">暂无包含地域数据的诗句</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.map((regionData, i) => (
            <div key={i} className="bg-muted/20 rounded-lg p-4 border border-border/50">
              <h3 className="text-base font-kai font-semibold mb-3 text-foreground">{regionData.region}</h3>
              <div className="space-y-2">
                {regionData.colors.map((c, j) => {
                  const maxCount = regionData.colors[0].count;
                  const widthPercent = (c.count / maxCount) * 100;
                  return (
                    <div key={j} className="flex items-center gap-2">
                      <div
                        className="h-6 rounded transition-all cursor-pointer hover:opacity-80"
                        style={{
                          backgroundColor: c.hex,
                          width: `${widthPercent}%`,
                          minWidth: '60px'
                        }}
                        onClick={() => navigate(`/color/${c.id}`)}
                        title={`${getColorDisplayName(c.name, isChinese)} (${c.count}首)`}
                      />
                      <span className="text-xs font-song text-muted-foreground whitespace-nowrap">
                        {getColorDisplayName(c.name, isChinese)} ({c.count})
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
