import type { ReactNode } from 'react';
import { Header } from './Header';
import { ScrollToTop } from '@/components/ScrollToTop';
import { useLang } from '@/contexts/LangContext';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const { t } = useLang();
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <footer className="border-t border-border py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8 text-center">
          <p className="font-kai text-muted-foreground text-sm tracking-widest">
            {t('siteName')}·{t('siteSubtitle')}
          </p>
          <p className="text-xs text-muted-foreground/60 mt-2 font-song">
            {t('footerSlogan')}
          </p>
          <div className="flex items-center justify-center gap-4 mt-4 text-xs text-muted-foreground/50">
            <span>{t('footerSource')}</span>
            <span>·</span>
            <span>{t('footerReference')}</span>
          </div>
        </div>
      </footer>
      {/* 全局一键回到顶端按钮 */}
      <ScrollToTop />
    </div>
  );
}
