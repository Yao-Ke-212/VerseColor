import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { Menu, Search, BarChart2, Heart, LogIn, LogOut, User, Users, X, Globe } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LangContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { SiteLogo } from '@/components/SiteLogo';

const NAV_GUIDE_KEY = 'shise_nav_guide_shown_v2';

export function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, signOut } = useAuth();
  const { lang, setLang, t, languages } = useLang();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const navLinks = [
    { href: '/search', labelKey: 'navSearch' as const, icon: Search },
    { href: '/poets',  labelKey: 'navPoets' as const,  icon: Users },
    { href: '/visualization', labelKey: 'navVisualization' as const, icon: BarChart2 },
    { href: '/my-collection',  labelKey: 'navMyCollection' as const, icon: Heart, requireAuth: true },
  ];

  useEffect(() => {
    const shown = localStorage.getItem(NAV_GUIDE_KEY);
    if (!shown) {
      const timer = setTimeout(() => setShowGuide(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const dismissGuide = () => {
    setShowGuide(false);
    localStorage.setItem(NAV_GUIDE_KEY, '1');
  };

  const handleSignOut = async () => {
    await signOut();
    toast.success(t('logoutSuccess'));
    navigate('/');
  };

  const isActive = (href: string) =>
    location.pathname === href || location.pathname.startsWith(href + '/');

  return (
    <header className="sticky top-0 z-50 bg-background/90 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-14 md:h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group shrink-0">
            <SiteLogo size={36} />
            <span className="hidden md:block text-xs text-muted-foreground font-song tracking-widest">
              {t('siteSubtitle')}
            </span>
          </Link>

          {/* 桌面导航 */}
          <nav className="hidden lg:flex items-center gap-1 relative">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-2 rounded text-sm transition-colors',
                  isActive(link.href)
                    ? 'text-primary font-medium bg-primary/8'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
                )}
              >
                <link.icon className="w-3.5 h-3.5" />
                {t(link.labelKey)}
              </Link>
            ))}

            {/* 首次访问引导 */}
            {showGuide && (
              <div className="absolute top-full left-0 mt-2 z-50 w-72 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="bg-background border border-primary/30 rounded-lg shadow-lg p-3 relative">
                  <button
                    type="button"
                    onClick={dismissGuide}
                    className="absolute top-2 right-2 p-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <div className="flex items-start gap-2 pr-4">
                    <span className="text-lg leading-none mt-0.5">🎋</span>
                    <div>
                      <p className="text-xs font-kai text-foreground font-medium mb-1">{t('guideWelcome')}</p>
                      <p className="text-[11px] text-muted-foreground font-song leading-relaxed">
                        {t('guideContent')}<br />
                        <span className="text-foreground">{t('guideSearch')}</span><br />
                        <span className="text-foreground">{t('guidePoets')}</span><br />
                        <span className="text-foreground">{t('guideViz')}</span><br />
                        <span className="text-foreground">{t('guideMobile')}</span>
                      </p>
                      <button
                        type="button"
                        onClick={dismissGuide}
                        className="mt-2 text-[10px] font-song text-primary/80 hover:text-primary underline transition-colors"
                      >
                        {t('guideDismiss')}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </nav>

          {/* 桌面右侧：语言切换 + 用户区 */}
          <div className="hidden lg:flex items-center gap-2">
            {/* 语言切换 */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-1.5 font-song text-muted-foreground hover:text-foreground">
                  <Globe className="w-3.5 h-3.5" />
                  <span className="text-xs">{languages.find(l => l.code === lang)?.shortLabel}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-36">
                {languages.map((l) => (
                  <DropdownMenuItem
                    key={l.code}
                    onClick={() => setLang(l.code)}
                    className={cn('font-song text-sm', lang === l.code && 'text-primary font-medium')}
                  >
                    {l.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* 用户菜单 */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <User className="w-4 h-4" />
                    <span className="font-song">{profile?.username || t('navMyCollection')}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40">
                  <DropdownMenuItem onClick={() => navigate('/my-collection')}>
                    <Heart className="w-4 h-4 mr-2" />
                    {t('navMyCollection')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                    <LogOut className="w-4 h-4 mr-2" />
                    {t('navLogout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="outline" size="sm" onClick={() => navigate('/login')} className="gap-2">
                <LogIn className="w-4 h-4" />
                {t('navLogin')}
              </Button>
            )}
          </div>

          {/* 移动端菜单 */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="lg:hidden p-2">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64 bg-background">
              <div className="flex flex-col gap-1 mt-6">
                <div className="px-2 pb-4 border-b border-border mb-2">
                  <p className="text-lg font-kai font-bold text-primary">{t('siteName')}·{t('siteSubtitle')}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{t('siteSlogan')}</p>
                </div>

                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    to={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors',
                      isActive(link.href)
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
                    )}
                  >
                    <link.icon className="w-4 h-4" />
                    {t(link.labelKey)}
                  </Link>
                ))}

                {/* 移动端语言切换 */}
                <div className="mt-3 px-3">
                  <p className="text-[11px] text-muted-foreground mb-2 font-song flex items-center gap-1">
                    <Globe className="w-3 h-3" /> {t('langSwitch')}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {languages.map((l) => (
                      <button
                        key={l.code}
                        type="button"
                        onClick={() => { setLang(l.code); setMobileOpen(false); }}
                        className={cn(
                          'px-2 py-1 rounded text-xs font-song transition-colors border',
                          lang === l.code
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'border-border text-muted-foreground hover:border-primary/50 hover:text-foreground'
                        )}
                      >
                        {l.shortLabel}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-border">
                  {user ? (
                    <>
                      <div className="px-3 py-2 text-sm text-muted-foreground">
                        <User className="w-4 h-4 inline mr-2" />
                        {profile?.username || t('navMyCollection')}
                      </div>
                      <button
                        type="button"
                        onClick={() => { handleSignOut(); setMobileOpen(false); }}
                        className="flex items-center gap-3 px-3 py-2.5 w-full rounded-md text-sm text-destructive hover:bg-destructive/10 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        {t('navLogout')}
                      </button>
                    </>
                  ) : (
                    <Link
                      to="/login"
                      onClick={() => setMobileOpen(false)}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-foreground hover:bg-muted/60 transition-colors"
                    >
                      <LogIn className="w-4 h-4" />
                      {t('navRegister')}
                    </Link>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
