import { useNavigate } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { InkClickWrapper } from './InkClickWrapper';
import { useLang } from '@/contexts/LangContext';
import { getColorFamilyLabel, getDynastyLabel, getColorDisplayName, getPoetDisplayName } from '@/lib/dataLabels';
import { cn } from '@/lib/utils';

// 仅需要展示所需的最小字段，避免强依赖完整 Color 类型
interface ColorCardColor {
  id: string;
  name: string;
  hex_value: string;
  color_family: string;
}

interface ColorCardProps {
  color: ColorCardColor;
  firstPoem?: {
    poet: string;
    dynasty: string;
    color_sentence: string;
  };
  isFavorited?: boolean;
  onFavorite?: (colorId: string) => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

/**
 * 传统色彩卡片组件
 * 含水墨点击动画、色彩信息展示
 */
export function ColorCard({
  color,
  firstPoem,
  isFavorited = false,
  onFavorite,
  className = '',
  size = 'md',
}: ColorCardProps) {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';

  const sizeConfig = {
    sm: { cardH: 'h-28', infoP: 'p-3', nameSize: 'text-base', hexSize: 'text-xs' },
    md: { cardH: 'h-40', infoP: 'p-4', nameSize: 'text-lg', hexSize: 'text-xs' },
    lg: { cardH: 'h-52', infoP: 'p-5', nameSize: 'text-xl', hexSize: 'text-sm' },
  }[size];

  return (
    <div
      className={cn(
        'card-rice-paper color-card-hover cursor-pointer group flex flex-col overflow-hidden h-full',
        className
      )}
      onClick={() => navigate(`/color/${color.id}`)}
    >
      {/* 色块区域 - 水墨动画 */}
      <InkClickWrapper
        className={cn('relative flex-shrink-0', sizeConfig.cardH)}
        onInkClick={() => navigate(`/color/${color.id}`)}
      >
        <div
          className="w-full h-full"
          style={{ backgroundColor: color.hex_value }}
        />
        {/* 收藏按钮 */}
        {onFavorite && (
          <button
            type="button"
            className={cn(
              'absolute top-2 right-2 p-1.5 rounded-full transition-all duration-200',
              'bg-background/60 hover:bg-background/90 backdrop-blur-sm',
              'opacity-0 group-hover:opacity-100',
            )}
            onClick={(e) => {
              e.stopPropagation();
              onFavorite(color.id);
            }}
          >
            <Heart
              className={cn('w-3.5 h-3.5 transition-colors', isFavorited ? 'fill-zheshi text-zheshi' : 'text-foreground/60')}
            />
          </button>
        )}
        {/* 色彩家族标签 */}
        <div className="absolute bottom-2 left-2">
          <span className="text-xs px-1.5 py-0.5 rounded bg-background/60 backdrop-blur-sm text-foreground/70 font-kai">
            {getColorFamilyLabel(color.color_family, t)}
          </span>
        </div>
      </InkClickWrapper>

      {/* 信息区域 — flex-1确保不同卡片等高对齐 */}
      <div className={cn('flex flex-col flex-1 bg-background/40', sizeConfig.infoP)}>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className={cn('font-kai text-foreground font-semibold leading-snug truncate', sizeConfig.nameSize)}>
              {getColorDisplayName(color.name, isChinese)}
            </h3>
            <p className={cn('font-mono text-muted-foreground mt-0.5', sizeConfig.hexSize)}>
              {color.hex_value.toUpperCase()}
            </p>
          </div>
          {/* 小色点 */}
          <div
            className="w-5 h-5 rounded-full flex-shrink-0 mt-0.5 ring-1 ring-border"
            style={{ backgroundColor: color.hex_value }}
          />
        </div>

        {/* 诗句 — 撑满剩余高度，固定2行截断，确保底部对齐 */}
        {size !== 'sm' && (
          <p className="mt-auto pt-2 text-[13px] md:text-sm text-muted-foreground leading-relaxed line-clamp-2 poem-quote min-h-[2.5rem]">
            {firstPoem ? (
              <>
                {firstPoem.color_sentence}
                <span className="ml-1 text-muted-foreground/60">
                  —{getDynastyLabel(firstPoem.dynasty, t)}·{getPoetDisplayName(firstPoem.poet, isChinese)}
                </span>
              </>
            ) : (
              <span className="invisible select-none">placeholder</span>
            )}
          </p>
        )}
      </div>
    </div>
  );
}
