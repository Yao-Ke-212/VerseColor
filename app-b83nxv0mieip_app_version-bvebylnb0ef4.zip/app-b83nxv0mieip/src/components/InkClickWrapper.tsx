import { useCallback, useRef, type MouseEvent, type ReactNode } from 'react';

interface InkClickWrapperProps {
  children: ReactNode;
  className?: string;
  onInkClick?: () => void;
}

/**
 * 水墨晕染扩散动画组件
 * 点击时在点击位置产生水墨扩散效果
 */
export function InkClickWrapper({ children, className = '', onInkClick }: InkClickWrapperProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  const handleClick = useCallback((e: MouseEvent<HTMLDivElement>) => {
    const container = containerRef.current;
    if (!container) return;

    // 移除旧的水墨元素
    const oldInk = container.querySelectorAll('.ink-drop');
    oldInk.forEach(el => el.remove());

    // 创建水墨扩散元素
    const ink = document.createElement('span');
    const rect = container.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    ink.className = 'ink-drop';
    ink.style.cssText = `
      position: absolute;
      width: ${size}px;
      height: ${size}px;
      left: ${x}px;
      top: ${y}px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(61,74,92,0.25) 0%, rgba(61,74,92,0.08) 40%, transparent 70%);
      transform: scale(0);
      animation: ink-spread 0.9s ease-out forwards;
      pointer-events: none;
      z-index: 10;
    `;

    container.style.position = 'relative';
    container.style.overflow = 'hidden';
    container.appendChild(ink);

    // 动画结束后移除
    setTimeout(() => ink.remove(), 900);

    onInkClick?.();
  }, [onInkClick]);

  return (
    <div ref={containerRef} className={className} onClick={handleClick}>
      {children}
    </div>
  );
}
