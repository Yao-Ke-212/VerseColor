import { useEffect, useState } from 'react';
import { ChevronUp } from 'lucide-react';

/**
 * 全局回到页面顶端按钮
 * 页面滚动超过300px时显示，点击平滑滚动至顶部
 */
export function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 300);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!visible) return null;

  return (
    <button
      type="button"
      onClick={scrollToTop}
      aria-label="回到顶部"
      className="fixed bottom-8 right-6 z-50 w-10 h-10 rounded-full
        bg-primary/90 text-primary-foreground shadow-lg
        flex items-center justify-center
        hover:bg-primary hover:scale-110 active:scale-95
        transition-all duration-200 backdrop-blur-sm
        border border-primary/20 group"
    >
      <ChevronUp className="w-5 h-5 transition-transform group-hover:-translate-y-0.5" />
      {/* 悬停提示标签 */}
      <span className="absolute right-12 whitespace-nowrap text-xs font-song
        bg-background/90 text-foreground border border-border rounded px-2 py-1 shadow
        opacity-0 group-hover:opacity-100 transition-opacity duration-150 pointer-events-none">
        回到顶部
      </span>
    </button>
  );
}
