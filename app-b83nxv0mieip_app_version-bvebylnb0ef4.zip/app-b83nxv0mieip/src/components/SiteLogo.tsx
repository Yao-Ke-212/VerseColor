/**
 * 诗色·VerseColor 网站 Logo 组件
 * 设计语言：五彩竖纹（传统色谱）+ 水墨圆印 + 楷书题字
 * 造型：圆形剪裁 · 上半：五色竖纹色彩调色板 · 下半：米白底「诗色」楷书
 */

interface SiteLogoProps {
  /** 整体缩放尺寸（px），默认 40 */
  size?: number;
  /** 是否只显示图标（不含文字区） */
  iconOnly?: boolean;
  className?: string;
}

/* 五个传统色（左→右：胭脂→朱砂→赭黄→天水碧→黛青） */
const STRIPE_COLORS = ['#B5495B', '#C0392B', '#C9943F', '#5BAAB2', '#3D4A5C'];

export function SiteLogo({ size = 40, iconOnly = false, className = '' }: SiteLogoProps) {
  const r = size / 2;

  return (
    <span className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* ── SVG 图标 ── */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        style={{ flexShrink: 0 }}
      >
        <defs>
          {/* 图标内容区剪裁 */}
          <clipPath id="logo-clip">
            <circle cx="50" cy="50" r="45" />
          </clipPath>
          {/* 下半米白背景渐变 */}
          <linearGradient id="cream-bg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#fdf6ed" />
            <stop offset="100%" stopColor="#f7ede0" />
          </linearGradient>
          {/* 横向分割线的柔和阴影 */}
          <filter id="divider-shadow" x="0" y="-50%" width="100%" height="200%">
            <feDropShadow dx="0" dy="1" stdDeviation="1" floodColor="#9E4F2C" floodOpacity="0.18" />
          </filter>
        </defs>

        {/* ── 底圆：整圆米白填充 ── */}
        <circle cx="50" cy="50" r="47" fill="url(#cream-bg)" />

        {/* ── 上半色彩竖纹（剪裁到圆形内） ── */}
        <g clipPath="url(#logo-clip)">
          {/* 半圆色块背景（只覆盖上半） */}
          {STRIPE_COLORS.map((color, i) => (
            <rect
              key={color}
              x={i * 20}
              y={0}
              width={19.5}
              height={52}
              fill={color}
              opacity={0.92}
            />
          ))}
          {/* 竖纹间微小间隔（1px白线，增强分层感） */}
          {[20, 40, 60, 80].map(x => (
            <line
              key={x}
              x1={x}
              y1={0}
              x2={x}
              y2={52}
              stroke="#fdf6ed"
              strokeWidth={1}
              opacity={0.6}
            />
          ))}
        </g>

        {/* ── 横向分割线（水墨感）── */}
        <line
          x1="5"
          y1="51"
          x2="95"
          y2="51"
          stroke="#8B3A2A"
          strokeWidth="1.2"
          filter="url(#divider-shadow)"
          opacity="0.55"
        />

        {/* ── 下半：「诗色」楷书题字 ── */}
        <text
          x="50"
          y="76"
          textAnchor="middle"
          dominantBaseline="middle"
          fontFamily="'KaiTi', 'STKaiti', 'FangSong', 'Noto Serif SC', serif"
          fontSize="26"
          fontWeight="700"
          fill="#4A2215"
          letterSpacing="5"
        >
          诗色
        </text>

        {/* ── 外圈双圆框（传统印章感）── */}
        <circle
          cx="50" cy="50" r="47"
          fill="none"
          stroke="#8B3A2A"
          strokeWidth="2.2"
        />
        <circle
          cx="50" cy="50" r="44"
          fill="none"
          stroke="#8B3A2A"
          strokeWidth="0.7"
          opacity="0.4"
        />
      </svg>

      {/* ── 右侧文字区（可选） ── */}
      {!iconOnly && (
        <span className="flex flex-col leading-none gap-0.5">
          <span
            style={{
              fontSize: Math.max(r * 0.58, 14),
              fontFamily: "'KaiTi','STKaiti','FangSong','Noto Serif SC',serif",
              color: 'hsl(var(--primary))',
              fontWeight: 700,
              lineHeight: 1,
              letterSpacing: '0.06em',
            }}
          >
            诗色
          </span>
          <span
            style={{
              fontSize: Math.max(r * 0.26, 9),
              fontFamily: "'Georgia','Times New Roman',serif",
              color: 'hsl(var(--muted-foreground))',
              letterSpacing: '0.14em',
              lineHeight: 1,
              textTransform: 'uppercase' as const,
            }}
          >
            VerseColor
          </span>
        </span>
      )}
    </span>
  );
}
