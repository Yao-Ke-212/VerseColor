import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import { LangProvider } from '@/contexts/LangContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import { CustomCursor } from '@/components/CustomCursor';
import { routes } from './routes';

const App: React.FC = () => {
  return (
    <Router>
      <LangProvider>
      <AuthProvider>
        <RouteGuard>
          <IntersectObserver />
          <div className="flex flex-col min-h-screen">
            <main className="flex-grow">
              <Routes>
                {routes.map((route, index) => (
                  <Route
                    key={index}
                    path={route.path}
                    element={route.element}
                  />
                ))}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
          </div>
          <Toaster />
          <CustomCursor />
        </RouteGuard>
      </AuthProvider>
      </LangProvider>
    </Router>
  );
};

export default App;
