import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Heart, Copy, ChevronLeft, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LangContext';
import { MainLayout } from '@/components/layouts/MainLayout';
import { InkClickWrapper } from '@/components/InkClickWrapper';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getColorFamilyLabel, getDynastyLabel, getEmotionLabel, getColorDisplayName } from '@/lib/dataLabels';
import type { Color, Poem, Favorite } from '@/types/types';
import { cn } from '@/lib/utils';

// 朝代排序权重（从古至今）
const DYNASTY_ORDER_MAP: Record<string, number> = {
  '先秦': 0, '周': 1, '春秋': 2, '战国': 3,
  '汉': 10, '西汉': 11, '东汉': 12,
  '魏晋': 20, '魏': 21, '晋': 22, '三国': 23,
  '南北朝': 30, '南朝': 31, '北朝': 32,
  '隋': 40, '唐': 50, '五代': 60,
  '宋': 70, '北宋': 71, '南宋': 72,
  '元': 80, '金': 82,
  '明': 90, '清': 100,
  '近代': 105, '近现代': 108, '现代': 110,
};

function getDynastyOrder(dynasty: string): number {
  if (DYNASTY_ORDER_MAP[dynasty] !== undefined) return DYNASTY_ORDER_MAP[dynasty];
  for (const [key, val] of Object.entries(DYNASTY_ORDER_MAP)) {
    if (dynasty.includes(key) || key.includes(dynasty)) return val;
  }
  return 999;
}

/**
 * 判断诗句与色彩词的关联类型。
 * 优先级：
 *   1. 数据库显式字段 mention_type（'direct'/'indirect'）— 经人工严格审核
 *   2. 自动检测：仅当 color_sentence 或 full_text 原文中完整包含色彩名称才算 direct
 * 后人注解、笺释、引申解读一律归为「文化解读」。
 */
function getColorMentionType(
  colorName: string,
  colorSentence: string | null,
  fullText: string | null,
  explicitType?: string | null,
): 'direct' | 'indirect' {
  // 数据库已有人工审核结果，直接采用
  if (explicitType === 'direct') return 'direct';
  if (explicitType === 'indirect') return 'indirect';
  // 无显式覆盖时，做严格文本匹配
  const text = `${colorSentence || ''}${fullText || ''}`;
  if (!text.trim() || !colorName.trim()) return 'indirect';
  return text.includes(colorName) ? 'direct' : 'indirect';
}
const TRADITIONAL_PALETTES: Record<string, string[]> = {
  '红色系': ['黛', '墨', '月白', '金', '朱'],
  '蓝色系': ['朱砂', '金', '月白', '赭石', '竹青'],
  '绿色系': ['月白', '赭石', '金', '朱', '黛'],
  '黄色系': ['黛', '朱', '竹青', '月白', '石青'],
  '白色系': ['黛', '鸦青', '赭石', '墨', '朱砂'],
  '黑色系': ['月白', '金', '朱砂', '赭石', '竹青'],
  '青色系': ['朱砂', '金', '月白', '赭石', '胭脂'],
  '紫色系': ['金', '月白', '黛', '赭石', '墨'],
};

export default function ColorDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, lang } = useLang();
  const isChineseLang = lang === 'zh-CN' || lang === 'zh-TW';

  const [color, setColor] = useState<Color | null>(null);
  const [poems, setPoems] = useState<Poem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<'all' | 'direct' | 'indirect'>('all');
  const [mentionFilter, setMentionFilter] = useState<'direct' | 'indirect' | null>(null);
  const [isFavorited, setIsFavorited] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [paletteColors, setPaletteColors] = useState<Color[]>([]);

  const loadColor = useCallback(async () => {
    if (!id) return;
    setLoading(true);

    // 解码 URL 参数（支持中文名称如 /color/胭脂）
    const decoded = decodeURIComponent(id);
    // 判断是 UUID 还是色彩名称
    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(decoded);

    // 先通过 id 或 name 查到色彩记录
    const { data: colorData } = isUUID
      ? await supabase.from('colors').select('*').eq('id', decoded).maybeSingle()
      : await supabase.from('colors').select('*').eq('name', decoded).maybeSingle();

    // 如果通过名称查到了，将 URL 替换为标准 UUID 路径（避免书签保存名称路径）
    if (!isUUID && colorData?.id) {
      window.history.replaceState(null, '', `/color/${colorData.id}`);
    }

    // 用实际 UUID 加载关联诗词
    const colorUUID = colorData?.id ?? (isUUID ? decoded : null);
    const { data: poemData } = colorUUID
      ? await supabase.from('poems').select('*').eq('color_id', colorUUID).order('created_at', { ascending: true })
      : { data: null };

    if (colorData) {
      setColor(colorData);
      // 加载推荐配色（用真实 UUID 排除自身）
      const palette = TRADITIONAL_PALETTES[colorData.color_family] || [];
      if (palette.length > 0) {
        const { data: paletteData } = await supabase
          .from('colors')
          .select('*')
          .in('name', palette)
          .neq('id', colorData.id)
          .limit(5);
        setPaletteColors(Array.isArray(paletteData) ? paletteData : []);
      }
    }

    if (poemData) {
      const allPoems = Array.isArray(poemData) ? poemData : [];
      // 诗词锦集展示优先级：
      // 1. 文本直接提及（按朝代从古至今）
      // 2. 文化解读（按朝代从古至今）
      const colorName = colorData?.name || '';
      const direct = allPoems
        .filter(p => getColorMentionType(colorName, p.color_sentence as string | null, p.full_text as string | null, p.mention_type as string | null) === 'direct')
        .sort((a, b) => getDynastyOrder(a.dynasty) - getDynastyOrder(b.dynasty));
      const indirect = allPoems
        .filter(p => getColorMentionType(colorName, p.color_sentence as string | null, p.full_text as string | null, p.mention_type as string | null) === 'indirect')
        .sort((a, b) => getDynastyOrder(a.dynasty) - getDynastyOrder(b.dynasty));
      setPoems([...direct, ...indirect]);
    }

    // 检查收藏状态（使用真实 UUID）
    if (user && colorUUID) {
      const { data: favData } = await supabase
        .from('favorites')
        .select('id')
        .eq('user_id', user.id)
        .eq('color_id', colorUUID)
        .eq('favorite_type', 'color')
        .maybeSingle();
      if (favData) {
        setIsFavorited(true);
        setFavoriteId(favData.id);
      }
    }

    setLoading(false);
  }, [id, user]);

  useEffect(() => {
    loadColor();
  }, [loadColor]);

  const toggleFavorite = async () => {
    if (!user) {
      toast.error(t('loginRequired'), {
        action: { label: t('navLogin'), onClick: () => navigate('/login') }
      });
      return;
    }
    if (!color) return;

    if (isFavorited && favoriteId) {
      const { error } = await supabase.from('favorites').delete().eq('id', favoriteId);
      if (!error) {
        setIsFavorited(false);
        setFavoriteId(null);
        toast.success(t('removeBtn'));
      }
    } else {
      const { data, error } = await supabase
        .from('favorites')
        .insert({ user_id: user.id, color_id: color.id, favorite_type: 'color' })
        .select('id')
        .maybeSingle();
      if (!error && data) {
        setIsFavorited(true);
        setFavoriteId(data.id);
        toast.success(t('favoriteSuccess'));
      }
    }
  };

  const copyHex = () => {
    if (color) {
      navigator.clipboard.writeText(color.hex_value.toUpperCase());
      toast.success(`${t('copyBtn')} ${color.hex_value.toUpperCase()}`);
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
          <Skeleton className="bg-muted h-6 w-24 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="bg-muted h-64 rounded-xl" />
            <div className="space-y-4">
              <Skeleton className="bg-muted h-8 w-32" />
              <Skeleton className="bg-muted h-4 w-full" />
              <Skeleton className="bg-muted h-4 w-full" />
              <Skeleton className="bg-muted h-4 w-3/4" />
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!color) {
    return (
      <MainLayout>
        <div className="max-w-5xl mx-auto px-4 md:px-8 py-16 text-center">
          <p className="text-muted-foreground font-song">{t('colorNotFound')}</p>
          <Button variant="outline" onClick={() => navigate('/search')} className="mt-4 font-song">
            {t('backToSearch')}
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* 返回按钮 */}
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 font-song"
        >
          <ChevronLeft className="w-4 h-4" />
          {t('back')}
        </button>

        {/* 色彩主信息 */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-10">
          {/* 色块 */}
          <div className="md:col-span-2">
            <InkClickWrapper className="rounded-xl overflow-hidden shadow-ink">
              <div
                className="w-full aspect-square"
                style={{ backgroundColor: color.hex_value }}
              />
            </InkClickWrapper>
          </div>

          {/* 色彩信息 */}
          <div className="md:col-span-3 flex flex-col">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <h1 className="text-4xl md:text-5xl font-kai font-bold text-foreground">{getColorDisplayName(color.name, isChineseLang)}</h1>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="secondary" className="font-song text-xs">{getColorFamilyLabel(color.color_family, t)}</Badge>
                  {color.emotion_tags.slice(0, 3).map(tag => (
                    <Badge key={tag} variant="outline" className="font-song text-xs">{getEmotionLabel(tag, t)}</Badge>
                  ))}
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={toggleFavorite}
                className={cn('gap-2 font-song flex-shrink-0', isFavorited && 'border-zheshi text-zheshi')}
              >
                <Heart className={cn('w-4 h-4', isFavorited && 'fill-zheshi')} />
                {isFavorited ? t('favorited') : t('favorite')}
              </Button>
            </div>

            {/* RGB & HEX */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="p-3 rounded-lg bg-muted/40 border border-border">
                <p className="text-xs text-muted-foreground font-song mb-1">{t('hexLabel')}</p>
                <div className="flex items-center gap-2">
                  <code className="text-sm font-mono text-foreground font-semibold">
                    {color.hex_value.toUpperCase()}
                  </code>
                  <button type="button" onClick={copyHex}>
                    <Copy className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground transition-colors" />
                  </button>
                </div>
              </div>
              <div className="p-3 rounded-lg bg-muted/40 border border-border">
                <p className="text-xs text-muted-foreground font-song mb-1">RGB</p>
                <code className="text-sm font-mono text-foreground font-semibold">
                  {color.rgb_r}, {color.rgb_g}, {color.rgb_b}
                </code>
              </div>
            </div>

            {/* 文化解读摘要 */}
            {color.cultural_interpretation && (
              <p className="text-sm text-muted-foreground font-song leading-relaxed line-clamp-4">
                {color.cultural_interpretation}
              </p>
            )}
          </div>
        </div>

        {/* 详细信息标签页 */}
        <Tabs defaultValue="poems" className="mt-8">
          <TabsList className="bg-muted/40 mb-6">
            <TabsTrigger value="poems" className="font-song">
              {t('poemsCollection')} ({poems.length})
            </TabsTrigger>
            <TabsTrigger value="academic" className="font-song">{t('academicTab')}</TabsTrigger>
            <TabsTrigger value="culture" className="font-song">{t('cultureTab')}</TabsTrigger>
            <TabsTrigger value="palette" className="font-song">{t('paletteTab')}</TabsTrigger>
          </TabsList>

          {/* 诗词集锦 */}
          <TabsContent value="poems" className="space-y-5">
            {poems.length === 0 ? (
              <p className="text-muted-foreground font-song text-sm py-8 text-center">{t('noPoems')}</p>
            ) : (
              <>
                {/* 筛选器行：说明 + 互斥勾选框 */}
                <div className="flex flex-col sm:flex-row sm:items-start gap-3 border border-primary/20 bg-primary/[0.03] rounded-lg p-4">
                  <div className="flex items-start gap-2.5 flex-1">
                    <span className="text-base mt-0.5 shrink-0">📜</span>
                    <div className="text-xs font-song text-muted-foreground leading-relaxed">
                      <p className="font-semibold text-foreground/80 mb-1">{t('mentionTypeDesc')}</p>
                      <p>
                        <span className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 px-1.5 rounded text-[10px] font-kai mr-1">{t('directMention')}</span>
                        {t('directMentionDesc')}
                      </p>
                      <p className="mt-0.5">
                        <span className="bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30 px-1.5 rounded text-[10px] font-kai mr-1">{t('culturalInterp')}</span>
                        {t('culturalInterpDesc')}
                      </p>
                    </div>
                  </div>
                  {/* 互斥筛选勾选框 */}
                  <div className="flex flex-row sm:flex-col gap-3 sm:gap-2 sm:min-w-[130px] shrink-0">
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        className="w-3.5 h-3.5 accent-emerald-600 cursor-pointer"
                        checked={filterType === 'direct'}
                        onChange={(e) => {
                          if (e.target.checked) setFilterType('direct');
                          else setFilterType('all');
                        }}
                      />
                      <span className="text-sm font-song text-foreground group-hover:text-emerald-600 transition-colors">
                        {t('directMention')}
                      </span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        className="w-3.5 h-3.5 accent-amber-600 cursor-pointer"
                        checked={filterType === 'indirect'}
                        onChange={(e) => {
                          if (e.target.checked) setFilterType('indirect');
                          else setFilterType('all');
                        }}
                      />
                      <span className="text-sm font-song text-foreground group-hover:text-amber-600 transition-colors">
                        {t('culturalInterp')}
                      </span>
                    </label>
                  </div>
                </div>

                {poems.filter(poem => {
                  const mentionType = getColorMentionType(
                    color.name,
                    poem.color_sentence as string | null,
                    poem.full_text as string | null,
                    poem.mention_type as string | null,
                  );
                  if (filterType === 'all') return true;
                  return filterType === mentionType;
                }).map((poem) => {
                  const mentionType = getColorMentionType(
                    color.name,
                    poem.color_sentence as string | null,
                    poem.full_text as string | null,
                    poem.mention_type as string | null,
                  );
                  return (
                <div key={poem.id} className="card-rice-paper p-5 md:p-6 animate-fade-in relative overflow-hidden bg-seal-text" data-seal={poem.dynasty}>
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <Link
                        to={`/poem/${poem.id}`}
                        className="font-kai text-base md:text-lg font-semibold text-primary hover:underline"
                      >
                        《{poem.poem_title}》
                      </Link>
                      <p className="text-sm text-muted-foreground font-song mt-0.5">
                        {getDynastyLabel(poem.dynasty, t)} ·{' '}
                        <Link
                          to={`/poet/${encodeURIComponent(poem.poet)}`}
                          className="hover:text-primary hover:underline transition-colors"
                        >
                          {poem.poet}
                        </Link>
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap justify-end">
                      {/* 色彩关联类型标注 */}
                      {mentionType === 'direct' ? (
                        <span className="bg-emerald-500/12 text-emerald-700 dark:text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded text-[10px] font-kai whitespace-nowrap">
                          {t('directMention')}
                        </span>
                      ) : (
                        <span className="bg-amber-500/12 text-amber-700 dark:text-amber-400 border border-amber-500/25 px-2 py-0.5 rounded text-[10px] font-kai whitespace-nowrap">
                          {t('culturalInterp')}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* 含色彩的单句 — 可点击进入诗词详情 */}
                  <Link
                    to={`/poem/${poem.id}`}
                    className="flex items-start gap-2 mb-3 group"
                  >
                    <div
                      className="w-3 h-3 rounded-full flex-shrink-0 mt-1 ring-1 ring-border/80 shrink-0"
                      style={{ backgroundColor: color.hex_value }}
                    />
                    <p className="text-sm md:text-base font-kai text-primary font-medium leading-relaxed group-hover:underline underline-offset-2">
                      「{poem.color_sentence}」
                    </p>
                  </Link>
                  <p className="text-[10px] text-muted-foreground/60 font-song mb-2 ml-5">
                    {isChineseLang ? '点击诗句查看全诗注释与赏析 →' : 'Click to read full poem & analysis →'}
                  </p>
                  {/* 文化解读免责说明 */}
                  {mentionType === 'indirect' && (
                    <p className="text-[10px] text-amber-700/70 dark:text-amber-400/70 font-song mb-2 ml-5 italic">
                      {t('culturalWarning')}
                    </p>
                  )}

                  {/* 详细信息 */}
                  <div className="space-y-2 mt-4 pt-4 border-t border-border/60">
                    {poem.annotation && (
                      <div>
                        <p className="text-xs text-muted-foreground font-song font-semibold mb-1">{t('annotation')}</p>
                        <p className="text-xs text-muted-foreground font-song leading-relaxed">{poem.annotation}</p>
                      </div>
                    )}
                    {poem.color_meaning && (
                      <div>
                        <p className="text-xs text-muted-foreground font-song font-semibold mb-1">{t('colorMeaning')}</p>
                        <p className="text-xs text-muted-foreground font-song leading-relaxed">{poem.color_meaning}</p>
                      </div>
                    )}
                    {poem.creation_background && (
                      <div>
                        <p className="text-xs text-muted-foreground font-song font-semibold mb-1">{t('creationBackground')}</p>
                        <p className="text-xs text-muted-foreground font-song leading-relaxed">{poem.creation_background}</p>
                      </div>
                    )}
                    {poem.imagery_category && (
                      <div className="flex items-center gap-1.5 pt-1">
                        <span className="text-xs text-muted-foreground font-song">色彩分类归纳：</span>
                        <Badge variant="outline" className="text-xs font-song py-0 bg-primary/5 text-primary">{poem.imagery_category}</Badge>
                      </div>
                    )}
                    {poem.emotion_tags && poem.emotion_tags.length > 0 && (
                      <div className="flex items-center gap-1.5 pt-1">
                        <span className="text-xs text-muted-foreground font-song">{t('emotion')}：</span>
                        {poem.emotion_tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs font-song py-0">{getEmotionLabel(tag, t)}</Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                  );
                })}
                {/* 筛选后无结果提示 */}
                {filterType !== 'all' && !poems.some(p =>
                  getColorMentionType(color.name, p.color_sentence as string | null, p.full_text as string | null, p.mention_type as string | null) === filterType
                ) && (
                  <div className="py-8 text-center">
                    <p className="text-muted-foreground font-song text-sm">
                      {t('noFilterResult')}「{filterType === 'direct' ? t('directMention') : t('culturalInterp')}」
                    </p>
                    <button type="button" onClick={() => setFilterType('all')}
                      className="mt-2 text-xs text-primary font-song underline">
                      {t('showAll')}
                    </button>
                  </div>
                )}
              </>
            )}
          </TabsContent>

          {/* 学术考据 */}
          <TabsContent value="academic" className="space-y-5">
            {color.ancient_source && (
              <div className="card-rice-paper p-5 md:p-6">
                <h3 className="font-kai text-base font-semibold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-4 bg-primary rounded-full inline-block" />
                  {t('ancientSource')}
                </h3>
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{color.ancient_source}</p>
              </div>
            )}

            {color.dye_craft && (
              <div className="card-rice-paper p-5 md:p-6">
                <h3 className="font-kai text-base font-semibold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-4 bg-zheshi rounded-full inline-block" />
                  {t('dyeCraft')}
                </h3>
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{color.dye_craft}</p>
              </div>
            )}

            {color.modern_evidence && (
              <div className="card-rice-paper p-5 md:p-6">
                <h3 className="font-kai text-base font-semibold text-foreground mb-3 flex items-center gap-2">
                  <span className="w-1 h-4 bg-chart-2 rounded-full inline-block" />
                  {t('modernEvidence')}
                </h3>
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{color.modern_evidence}</p>
              </div>
            )}

            {!color.ancient_source && !color.dye_craft && !color.modern_evidence && (
              <p className="text-muted-foreground font-song text-sm py-8 text-center">{t('noAcademicData')}</p>
            )}
          </TabsContent>

          {/* 文化解读 */}
          <TabsContent value="culture" className="space-y-5">
            {color.cultural_interpretation && (
              <div className="card-rice-paper p-5 md:p-6">
                <h3 className="font-kai text-base font-semibold text-foreground mb-3">{t('cultureTab')}</h3>
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{color.cultural_interpretation}</p>
              </div>
            )}

            {color.historical_story && (
              <div className="card-rice-paper p-5 md:p-6">
                <h3 className="font-kai text-base font-semibold text-foreground mb-3">{t('historicalStory')}</h3>
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{color.historical_story}</p>
              </div>
            )}

            {!color.cultural_interpretation && !color.historical_story && (
              <p className="text-muted-foreground font-song text-sm py-8 text-center">{t('noCultureData')}</p>
            )}
          </TabsContent>

          {/* 配色推荐 */}
          <TabsContent value="palette" className="space-y-5">
            <div className="card-rice-paper p-5 md:p-6">
              <h3 className="font-kai text-base font-semibold text-foreground mb-4">
                {t('paletteRecommend')}
                <span className="text-sm font-normal text-muted-foreground font-song ml-2">
                  {t('paletteDesc')}
                </span>
              </h3>

              {/* 主色 + 配色 */}
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex flex-col items-center gap-1.5">
                  <InkClickWrapper>
                    <div
                      className="w-16 h-16 rounded-lg ring-2 ring-primary/30 ring-offset-2"
                      style={{ backgroundColor: color.hex_value }}
                    />
                  </InkClickWrapper>
                  <span className="text-xs font-kai text-foreground font-medium">{getColorDisplayName(color.name, isChineseLang)}</span>
                  <span className="text-[10px] font-mono text-muted-foreground">{color.hex_value}</span>
                </div>

                <div className="text-muted-foreground text-lg font-song">+</div>

                {paletteColors.map((pc) => (
                  <button
                    key={pc.id}
                    type="button"
                    onClick={() => navigate(`/color/${pc.id}`)}
                    className="flex flex-col items-center gap-1.5 group"
                  >
                    <InkClickWrapper>
                      <div
                        className="w-16 h-16 rounded-lg ring-1 ring-border group-hover:ring-primary/50 transition-all"
                        style={{ backgroundColor: pc.hex_value }}
                      />
                    </InkClickWrapper>
                    <span className="text-xs font-kai text-muted-foreground group-hover:text-foreground transition-colors">{getColorDisplayName(pc.name, isChineseLang)}</span>
                    <span className="text-[10px] font-mono text-muted-foreground/70">{pc.hex_value}</span>
                  </button>
                ))}
              </div>

              {paletteColors.length === 0 && (
                <p className="text-muted-foreground font-song text-sm">{t('noPaletteData')}</p>
              )}
            </div>

            {/* 完整配色条 */}
            {paletteColors.length > 0 && (
              <div className="card-rice-paper p-5 md:p-6">
                <h4 className="font-kai text-sm font-semibold text-foreground mb-3">{t('palettePreview')}</h4>
                <div className="h-12 rounded-lg overflow-hidden flex">
                  <div
                    className="flex-[2]"
                    style={{ backgroundColor: color.hex_value }}
                  />
                  {paletteColors.map((pc) => (
                    <div
                      key={pc.id}
                      className="flex-1"
                      style={{ backgroundColor: pc.hex_value }}
                    />
                  ))}
                </div>
                <div className="flex gap-1 mt-2">
                  <span className="flex-[2] text-center text-xs font-kai text-muted-foreground truncate">{getColorDisplayName(color.name, isChineseLang)}</span>
                  {paletteColors.map((pc) => (
                    <span key={pc.id} className="flex-1 text-center text-xs font-kai text-muted-foreground truncate">{getColorDisplayName(pc.name, isChineseLang)}</span>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
