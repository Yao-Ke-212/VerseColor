import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ChevronLeft, Heart, BookOpen } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LangContext';
import { MainLayout } from '@/components/layouts/MainLayout';
import { InkClickWrapper } from '@/components/InkClickWrapper';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { getDynastyLabel, getEmotionLabel, getColorDisplayName, getPoetDisplayName } from '@/lib/dataLabels';
import type { Poem, Color } from '@/types/types';

interface PoemDetail extends Poem {
  colors: Color;
}

export default function PoemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t, lang } = useLang();
  const isChineseLang = lang === 'zh-CN' || lang === 'zh-TW';

  const [poem, setPoem] = useState<PoemDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFavorited, setIsFavorited] = useState(false);
  const [favoriteId, setFavoriteId] = useState<string | null>(null);
  const [noteContent, setNoteContent] = useState('');

  const loadPoem = useCallback(async () => {
    if (!id) return;
    setLoading(true);

    const { data } = await supabase
      .from('poems')
      .select('*, colors:color_id(*)')
      .eq('id', id)
      .maybeSingle();

    if (data) setPoem(data as unknown as PoemDetail);

    if (user) {
      const { data: favData } = await supabase
        .from('favorites')
        .select('id')
        .eq('user_id', user.id)
        .eq('poem_id', id)
        .eq('favorite_type', 'poem')
        .maybeSingle();
      if (favData) { setIsFavorited(true); setFavoriteId(favData.id); }

      // 尝试加载用户的个人笔记
      const { data: noteData } = await supabase
        .from('user_notes')
        .select('content')
        .eq('user_id', user.id)
        .eq('poem_id', id)
        .maybeSingle();
      if (noteData) {
        setNoteContent(noteData.content || '');
      }
    }
    setLoading(false);
  }, [id, user]);

  useEffect(() => { loadPoem(); }, [loadPoem]);

  const saveNote = async () => {
    if (!user) {
      toast.error('请先登录');
      navigate('/login');
      return;
    }
    if (!poem) return;
    
    if (!noteContent.trim()) {
      toast.error('批注内容不能为空');
      return;
    }

    const { error } = await supabase
      .from('user_notes')
      .insert({
        user_id: user.id,
        poem_id: poem.id,
        content: noteContent
      });

    if (error) {
      toast.error('保存失败');
    } else {
      toast.success('批注保存成功');
      setNoteContent('');
    }
  };

  const submitFeedback = async (type: string, content: string) => {
    if (!poem) return;
    const { error } = await supabase
      .from('user_feedbacks')
      .insert({
        user_id: user?.id || null,
        poem_id: poem.id,
        color_id: poem.colors?.id || null,
        feedback_type: type,
        content
      });

    if (error) {
      toast.error('提交失败');
    } else {
      toast.success('感谢您的纠错反馈，我们将尽快审核处理！');
    }
  };

  const toggleFavorite = async () => {
    if (!user) {
      toast.error(t('loginRequired'), { action: { label: t('navLogin'), onClick: () => navigate('/login') } });
      return;
    }
    if (!poem) return;
    if (isFavorited && favoriteId) {
      const { error } = await supabase.from('favorites').delete().eq('id', favoriteId);
      if (!error) { setIsFavorited(false); setFavoriteId(null); toast.success(t('removeBtn')); }
    } else {
      const { data, error } = await supabase
        .from('favorites')
        .insert({ user_id: user.id, poem_id: poem.id, favorite_type: 'poem' })
        .select('id').maybeSingle();
      if (!error && data) { setIsFavorited(true); setFavoriteId(data.id); toast.success(t('favoriteSuccess')); }
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-3xl mx-auto px-4 md:px-8 py-8">
          <Skeleton className="bg-muted h-5 w-20 mb-8" />
          <Skeleton className="bg-muted h-8 w-48 mb-4" />
          <Skeleton className="bg-muted h-4 w-32 mb-8" />
          <div className="space-y-3">
            {[...Array(6)].map((_, i) => <Skeleton key={i} className="bg-muted h-4 w-full" />)}
          </div>
        </div>
      </MainLayout>
    );
  }

  if (!poem) {
    return (
      <MainLayout>
        <div className="max-w-3xl mx-auto px-4 md:px-8 py-16 text-center">
          <p className="text-muted-foreground font-song">{t('poemNotFound')}</p>
          <Button variant="outline" onClick={() => navigate(-1)} className="mt-4 font-song">{t('back')}</Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* 返回 */}
        <button
          type="button" onClick={() => navigate(-1)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 font-song transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />{t('back')}
        </button>

        {/* 页头信息 */}
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground mb-2">
                《{poem.poem_title}》
              </h1>
              <div className="flex items-center gap-2 flex-wrap">
                <Link
                  to={`/poet/${encodeURIComponent(poem.poet)}`}
                  className="text-sm font-kai text-primary hover:underline transition-colors"
                >
                  {getDynastyLabel(poem.dynasty, t)} · {getPoetDisplayName(poem.poet, isChineseLang)}
                </Link>
                {poem.emotion_tags?.map(tag => (
                  <Badge key={tag} variant="secondary" className="font-song text-xs">{getEmotionLabel(tag, t)}</Badge>
                ))}
              </div>
            </div>
            <Button
              variant="outline" size="sm" onClick={toggleFavorite}
              className={`gap-2 font-song flex-shrink-0 ${isFavorited ? 'border-zheshi text-zheshi' : ''}`}
            >
              <Heart className={`w-4 h-4 ${isFavorited ? 'fill-zheshi' : ''}`} />
              {isFavorited ? t('favorited') : t('favorite')}
            </Button>
          </div>
        </div>

        {/* 完整诗文 */}
        <div className="card-rice-paper p-6 md:p-8 mb-8">
          {!isChineseLang && t('originalPoetryLabel') && (
            <div className="mb-3 pb-3 border-b border-border/40 flex items-center gap-2">
              <span className="text-[10px] px-1.5 py-0.5 rounded border border-border/60 text-muted-foreground/70 font-song bg-muted/30 select-none">
                {t('originalPoetryLabel')}
              </span>
              <span className="text-xs text-muted-foreground/50 font-song">
                {getDynastyLabel(poem.dynasty, t)} · {getPoetDisplayName(poem.poet, isChineseLang)}
              </span>
            </div>
          )}
          <pre className="font-kai text-base md:text-lg text-foreground leading-[2.4] whitespace-pre-wrap tracking-wider text-center">
            {poem.full_text?.replace(/\\n/g, '\n')}
          </pre>
        </div>

        {/* 诗中色彩 */}
        {poem.colors && (
          <div className="mb-6">
            <h2 className="font-kai text-base font-semibold text-foreground mb-3 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-zheshi" />{t('poemColor')}
            </h2>
            <div className="card-rice-paper p-4 flex items-center gap-4">
              <InkClickWrapper>
                <div
                  className="w-16 h-16 rounded-lg cursor-pointer ring-1 ring-border flex-shrink-0"
                  style={{ backgroundColor: poem.colors.hex_value }}
                  onClick={() => navigate(`/color/${poem.colors.id}`)}
                />
              </InkClickWrapper>
              <div className="flex-1 min-w-0">
                <Link
                  to={`/color/${poem.colors.id}`}
                  className="font-kai text-lg font-semibold text-primary hover:underline"
                >
                  {getColorDisplayName(poem.colors.name, isChineseLang)}
                </Link>
                <p className="text-xs font-mono text-muted-foreground">{poem.colors.hex_value.toUpperCase()}</p>
                {poem.color_meaning && (
                  <p className="text-sm text-muted-foreground font-song mt-1 leading-relaxed">{poem.color_meaning}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 色彩意象诗句 */}
        <div className="mb-6">
          <h2 className="font-kai text-base font-semibold text-foreground mb-3">{t('colorImageryLine')}</h2>
          <div className="card-rice-paper p-5">
            <p className="poem-quote font-kai text-foreground/90">
              「{poem.color_sentence?.replace(/\\n/g, '\n')}」
            </p>
          </div>
        </div>

        {/* 注释与翻译 */}
        {(poem.annotation || poem.poem_annotation || poem.translation || poem.poem_translation) && (
          <div className="mb-6 space-y-4">
            {(poem.poem_translation || poem.translation) && (
              <div>
                <h2 className="font-kai text-base font-semibold text-foreground mb-3">全文翻译</h2>
                <div className="card-rice-paper p-5">
                  <p className="text-sm font-song text-foreground/80 leading-relaxed whitespace-pre-wrap">{(poem.poem_translation || poem.translation)?.replace(/\\n/g, '\n')}</p>
                </div>
              </div>
            )}
            {(poem.annotation || poem.poem_annotation) && (
              <div>
                <h2 className="font-kai text-base font-semibold text-foreground mb-3">逐句注释</h2>
                <div className="card-rice-paper p-5">
                  <p className="text-sm font-song text-foreground/80 leading-relaxed whitespace-pre-wrap">{(poem.poem_annotation || poem.annotation)?.replace(/\\n/g, '\n')}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 创作背景与赏析 */}
        {(poem.creation_background || poem.background || poem.poetry_appreciation) && (
          <div className="mb-6 space-y-4">
            {(poem.creation_background || poem.background) && (
              <div>
                <h2 className="font-kai text-base font-semibold text-foreground mb-3">{t('creationBackground')}</h2>
                <div className="card-rice-paper p-5">
                  <p className="text-sm font-song text-foreground/80 leading-relaxed whitespace-pre-wrap">{(poem.creation_background || poem.background)?.replace(/\\n/g, '\n')}</p>
                </div>
              </div>
            )}
            {poem.poetry_appreciation && (
              <div>
                <h2 className="font-kai text-base font-semibold text-foreground mb-3">诗词赏析</h2>
                <div className="card-rice-paper p-5">
                  <p className="text-sm font-song text-foreground/80 leading-relaxed whitespace-pre-wrap">{poem.poetry_appreciation?.replace(/\\n/g, '\n')}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 个人笔记 */}
        <div className="mb-8 mt-10">
          <h2 className="font-kai text-base font-semibold text-foreground mb-3 flex items-center gap-2">
            <span>📝</span> 个人批注
          </h2>
          <div className="card-rice-paper p-5">
            {!user ? (
              <div className="text-center py-6">
                <p className="text-sm text-muted-foreground font-song mb-3">登录后可在此写下您的研究备注与个人赏析</p>
                <Button variant="outline" size="sm" onClick={() => navigate('/login')} className="font-song">前往登录</Button>
              </div>
            ) : (
              <div>
                 <textarea
                   value={noteContent}
                   onChange={(e) => setNoteContent(e.target.value)}
                   className="w-full h-24 p-3 bg-background border border-border rounded-md font-song text-sm resize-none focus:outline-none focus:ring-1 focus:ring-primary/30"
                   placeholder="写下关于这首诗的色彩意象研究或赏析感悟..."
                 />
                 <div className="flex justify-end mt-3">
                   <Button size="sm" onClick={saveNote} className="font-song">保存批注</Button>
                 </div>
              </div>
            )}
          </div>
        </div>

        {/* 纠错反馈入口 */}
        <div className="mb-6 border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground font-song">如果您发现本诗的色彩分类、含义解读或全诗内容有误，欢迎向我们反馈。</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="font-song text-xs h-8" onClick={() => submitFeedback('error_category', '色彩分类可能有误')}>分类纠错</Button>
            <Button variant="outline" size="sm" className="font-song text-xs h-8" onClick={() => submitFeedback('forced_interpretation', '解读存在过度引申')}>解读建议</Button>
          </div>
        </div>

        {/* 底部导航 */}
        <div className="flex gap-3 mt-8 pt-6 border-t border-border">
          {poem.colors && (
            <Button variant="outline" onClick={() => navigate(`/color/${poem.colors.id}`)} className="font-song">
              {t('viewColorDetail').replace('{name}', getColorDisplayName(poem.colors.name, isChineseLang))}
            </Button>
          )}
          <Button variant="ghost" onClick={() => navigate(`/poet/${encodeURIComponent(poem.poet)}`)} className="font-song">
            {t('viewPoet').replace('{name}', getPoetDisplayName(poem.poet, isChineseLang))}
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}
