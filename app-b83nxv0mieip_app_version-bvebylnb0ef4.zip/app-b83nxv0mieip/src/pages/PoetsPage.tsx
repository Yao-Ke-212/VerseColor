import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DYNASTIES } from '@/types/types';
import { cn } from '@/lib/utils';
import { useLang } from '@/contexts/LangContext';
import { getDynastyLabel, getPoetDisplayName } from '@/lib/dataLabels';
import {
  POET_PORTRAITS,
  BOOK_COVERS,
  BOOK_ENTRIES,
  POET_DOMINANT_COLORS,
  DYNASTY_COLOR_MAP,
  getPoetBgColor,
} from '@/data/poetData';

/* 朝代时间顺序映射（越小越早）*/
const DYNASTY_ORDER: Record<string, number> = {
  '先秦': 1, '秦': 2, '汉': 3, '魏晋': 4, '南北朝': 5,
  '隋': 6, '唐': 7, '五代': 8, '宋': 9, '元': 10,
  '明': 11, '清': 12, '近现代': 13,
};

interface Poet {
  id: string;
  name: string;
  dynasty: string;
  bio: string | null;
  birth_year: string | null;
  death_year: string | null;
  style_summary: string | null;
}

// 诗人/书籍图标组件
// 优先级：古籍封面照片 > 历史人像 > 书籍图标 > 姓氏文字图标
function PoetAvatar({ name, dynasty }: { name: string; dynasty: string }) {
  const [imgError, setImgError] = useState(false);
  const portraitUrl = POET_PORTRAITS[name];
  const bookCoverUrl = BOOK_COVERS[name];
  const dominantColor = POET_DOMINANT_COLORS[name];
  const dynastyColor = DYNASTY_COLOR_MAP[dynasty] || '#3D4A5C';
  const bgColor = dominantColor?.hex || dynastyColor;
  const isBook = BOOK_ENTRIES.has(name);
  const char = name.slice(0, 1);

  // 古籍条目：优先使用实物封面照片
  if (isBook && bookCoverUrl && !imgError) {
    return (
      <div className="w-14 h-14 rounded-full flex-shrink-0 overflow-hidden ring-2 ring-border/50">
        <img
          src={bookCoverUrl}
          alt={`${name}封面`}
          className="w-full h-full object-cover object-center"
          onError={() => setImgError(true)}
        />
      </div>
    );
  }

  // 古籍条目：无封面图时显示书籍图标
  if (isBook) {
    return (
      <div
        className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 relative overflow-hidden"
        style={{ backgroundColor: bgColor }}
      >
        <span className="text-2xl select-none">📖</span>
      </div>
    );
  }

  // 有历史画像且未加载失败
  if (portraitUrl && !imgError) {
    return (
      <div className="w-14 h-14 rounded-full flex-shrink-0 overflow-hidden ring-2 ring-border/50">
        <img
          src={portraitUrl}
          alt={`${name}画像`}
          className="w-full h-full object-cover object-top"
          onError={() => setImgError(true)}
        />
      </div>
    );
  }

  // 姓氏文字图标（无画像时后备）
  return (
    <div
      className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0 text-white font-kai text-xl font-bold ring-2 ring-white/20"
      style={{ backgroundColor: bgColor }}
    >
      {char}
    </div>
  );
}

/**
 * 诗人卡片背景色（使用代表色透明叠加）
 */
function getPoetCardAccent(name: string, dynasty: string): string {
  return getPoetBgColor(name, dynasty);
}

export default function PoetsPage() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [poets, setPoets] = useState<Poet[]>([]);
  const [loading, setLoading] = useState(true);
  const [dynasty, setDynasty] = useState('');

  useEffect(() => { loadPoets(); }, [dynasty]);

  const loadPoets = async () => {
    setLoading(true);
    let query = supabase.from('poets').select('*');
    if (dynasty) query = query.eq('dynasty', dynasty);
    const { data } = await query;
    const sorted = (Array.isArray(data) ? data : []).sort((a, b) => {
      // 先按朝代时间顺序，再按名字
      const da = DYNASTY_ORDER[a.dynasty] ?? 99;
      const db = DYNASTY_ORDER[b.dynasty] ?? 99;
      if (da !== db) return da - db;
      return a.name.localeCompare(b.name, 'zh');
    });
    setPoets(sorted);
    setLoading(false);
  };

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* 页头 */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground">{t('poetTitle')}</h1>
          <p className="text-sm text-muted-foreground font-song mt-1">{t('poetSubtitle')}</p>
        </div>

        {/* 朝代筛选 */}
        <div className="mb-6 flex items-center gap-3">
          <span className="text-sm text-muted-foreground font-song">{t('poetFilterDynasty')}：</span>
          <Select value={dynasty || 'all'} onValueChange={v => setDynasty(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-36 bg-background font-song text-sm">
              <SelectValue placeholder={t('allDynasties')} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('allDynasties')}</SelectItem>
              {DYNASTIES.map(d => <SelectItem key={d} value={d}>{getDynastyLabel(d, t)}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* 朝代分组说明 */}
        {!dynasty && !loading && poets.length > 0 && (
          <p className="text-xs text-muted-foreground font-song mb-4 flex items-center gap-1">
            <span className="inline-block w-3 h-px bg-border"></span>
            {t('dynastyTimeOrder')}
          </p>
        )}

        {/* 诗人卡片列表 */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card-rice-paper p-5 flex gap-4">
                <Skeleton className="bg-muted w-14 h-14 rounded-full flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="bg-muted h-5 w-24" />
                  <Skeleton className="bg-muted h-3 w-full" />
                  <Skeleton className="bg-muted h-3 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : poets.length === 0 ? (
          <p className="text-center text-muted-foreground font-song py-12">{t('noResults')}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {poets.map((poet, i) => {
              const accentHex = getPoetCardAccent(poet.name, poet.dynasty);
              return (
              <button
                key={poet.id}
                type="button"
                onClick={() => navigate(`/poet/${encodeURIComponent(poet.name)}`)}
                className={cn(
                  'card-rice-paper p-5 flex gap-4 text-left hover:border-primary/40 transition-all',
                  'opacity-0 intersect:opacity-100 intersect:translate-y-0 translate-y-4',
                  'duration-500 color-card-hover overflow-hidden relative'
                )}
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                {/* 代表色微渐变装饰条 */}
                <span
                  className="absolute top-0 left-0 right-0 h-0.5 opacity-60"
                  style={{ background: `linear-gradient(90deg, ${accentHex}88, ${accentHex}22, transparent)` }}
                  aria-hidden="true"
                />
                {/* 左侧极淡代表色晕染 */}
                <span
                  className="absolute left-0 top-0 bottom-0 w-24 pointer-events-none"
                  style={{ background: `linear-gradient(90deg, ${accentHex}12, transparent)` }}
                  aria-hidden="true"
                />
                <PoetAvatar name={poet.name} dynasty={poet.dynasty} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-kai text-lg font-semibold text-foreground">{getPoetDisplayName(poet.name, isChinese)}</span>
                    <Badge variant="secondary" className="font-song text-xs">{getDynastyLabel(poet.dynasty, t)}</Badge>
                    {poet.birth_year && poet.death_year && (
                      <span className="text-xs text-muted-foreground font-song">
                        {poet.birth_year}—{poet.death_year}
                      </span>
                    )}
                  </div>
                  {poet.bio && (
                    <p className="text-xs text-muted-foreground font-song leading-relaxed line-clamp-3">{poet.bio}</p>
                  )}
                  {poet.style_summary && (
                    <p className="text-xs font-kai mt-1.5 line-clamp-1 italic"
                      style={{ color: accentHex }}>
                      「{poet.style_summary.slice(0, 35)}…」
                    </p>
                  )}
                  {!isChinese && (poet.bio || poet.style_summary) && (
                    <p className="text-[10px] text-muted-foreground/60 font-song mt-1 italic">
                      {t('bioInChineseNote')}
                    </p>
                  )}
                </div>
              </button>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
