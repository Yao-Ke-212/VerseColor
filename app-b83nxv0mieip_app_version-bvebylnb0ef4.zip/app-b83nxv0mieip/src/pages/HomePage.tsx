import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, ChevronRight, BookOpen, BarChart2, Sparkles } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ColorCard } from '@/components/ColorCard';
import { InkClickWrapper } from '@/components/InkClickWrapper';
import { SiteLogo } from '@/components/SiteLogo';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import type { Color, Poem } from '@/types/types';
import { COLOR_FAMILIES, DYNASTIES } from '@/types/types';
import { useLang } from '@/contexts/LangContext';
import { getColorFamilyLabel, getDynastyLabel, getColorDisplayName } from '@/lib/dataLabels';

interface ColorWithPoem extends Color {
  poems?: Poem[];
}



export default function HomePage() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [keyword, setKeyword] = useState('');
  const [featuredColors, setFeaturedColors] = useState<ColorWithPoem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeaturedColors();
  }, []);

  const loadFeaturedColors = async () => {
    setLoading(true);
    // 优先展示诗词存量最丰富的色彩（按关联诗词数量降序）
    const { data: poemCounts } = await supabase
      .from('poems')
      .select('color_id')
      .not('color_id', 'is', null);

    if (!poemCounts) {
      setLoading(false);
      return;
    }

    // 统计每个 color_id 对应的诗词数量
    const countMap = new Map<string, number>();
    for (const row of poemCounts) {
      const cid = row.color_id as string;
      countMap.set(cid, (countMap.get(cid) || 0) + 1);
    }

    // 取诗词数量最多的前 12 个 color_id
    const topColorIds = Array.from(countMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 12)
      .map(([id]) => id);

    if (topColorIds.length === 0) {
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('colors')
      .select('*, poems(id, poet, dynasty, color_sentence)')
      .in('id', topColorIds);

    if (!error && data) {
      // 按诗词数量重新排序结果
      const sorted = (Array.isArray(data) ? data : []).sort(
        (a, b) => (countMap.get(b.id) || 0) - (countMap.get(a.id) || 0)
      );
      setFeaturedColors(sorted);
    }
    setLoading(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (keyword.trim()) {
      navigate(`/search?keyword=${encodeURIComponent(keyword.trim())}`);
    } else {
      navigate('/search');
    }
  };

  return (
    <MainLayout>
      {/* Hero 区域 */}
      <section className="relative overflow-hidden hero-ink-decor">
        {/* 竖排装饰文字 */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 hidden lg:flex flex-col gap-2 items-end pointer-events-none select-none z-0">
          <span className="text-vertical-decor opacity-30">詩　色</span>
          <span className="text-vertical-decor opacity-20">中華傳統色彩</span>
        </div>
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16 md:py-24 relative">
          <div className="max-w-2xl">
            {/* 标题 */}
            <div className="mb-6 opacity-0 intersect:opacity-100 transition-all duration-700 intersect:translate-y-0 translate-y-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="h-px w-8 bg-gradient-to-r from-primary/60 to-zheshi/40" />
                <span className="text-xs text-muted-foreground font-song tracking-[0.2em] uppercase">
                  {t('siteTagline')}
                </span>
              </div>
              <h1 className="text-4xl md:text-5xl font-kai font-bold text-primary leading-tight">
                <SiteLogo size={56} />
              </h1>
            </div>

            <p className="text-sm md:text-base text-muted-foreground font-song leading-relaxed mb-8 opacity-0 intersect:opacity-100 transition-all duration-700 delay-100 intersect:translate-y-0 translate-y-4">{t('siteDesc')}</p>

            {/* 检索框 */}
            <form onSubmit={handleSearch} className="flex gap-2 max-w-lg opacity-0 intersect:opacity-100 transition-all duration-700 delay-200">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder={t('heroSearchPlaceholder')}
                  className="pl-9 bg-background border-border font-song"
                />
              </div>
              <Button type="submit" className="font-song">{t('heroSearchBtn')}</Button>
            </form>

            {/* 快速标签 */}
            <div className="flex flex-wrap gap-2 mt-4 opacity-0 intersect:opacity-100 transition-all duration-700 delay-300 items-center">
              <span className="text-xs text-muted-foreground font-song mr-1">{t('quickSearch')}：</span>
              {['黛', '胭脂', '天水碧', '朱砂', '墨', '翠'].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => navigate(`/search?keyword=${tag}`)}
                  className="text-xs md:text-sm px-2.5 py-1 rounded-full border border-border/80 text-muted-foreground hover:text-foreground hover:border-primary/50 hover:bg-primary/4 transition-all font-kai"
                >
                  {getColorDisplayName(tag, isChinese)}
                </button>
              ))}
            </div>
          </div>

          {/* 装饰性色条 */}
          <div className="absolute right-0 top-0 bottom-0 w-1/3 hidden lg:flex items-center justify-end pr-8 gap-2 opacity-25">
            {['#3D4A5C', '#B5495B', '#62B5C9', '#9E4F2C', '#C9A84C', '#2E8B57', '#3B4C54'].map((hex, i) => (
              <div
                key={hex}
                className="w-4 rounded-full transition-all"
                style={{
                  backgroundColor: hex,
                  height: `${60 + i * 20}%`,
                  opacity: 0.5 + i * 0.06
                }}
              />
            ))}
          </div>
        </div>

        {/* 底部淡彩分隔线 */}
        <div className="divider-wash mx-4 md:mx-8" />
      </section>
      {/* 快速导航 */}
      <section className="border-y border-border/60 bg-muted/10">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              type="button"
              onClick={() => navigate('/search')}
              className="flex items-center gap-4 p-4 rounded-lg bg-card/70 border border-border/70 hover:border-primary/45 hover:bg-card transition-all group text-left ink-glow-hover"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/8 flex items-center justify-center group-hover:bg-primary/16 transition-colors">
                <Search className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-kai font-semibold text-foreground">{t('searchTitle')}</p>
                <p className="text-xs text-muted-foreground font-song mt-0.5">{t('searchDesc')}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
            </button>

            <button
              type="button"
              onClick={() => navigate('/visualization')}
              className="flex items-center gap-4 p-4 rounded-lg bg-card/70 border border-border/70 hover:border-primary/45 hover:bg-card transition-all group text-left ink-glow-hover"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/8 flex items-center justify-center group-hover:bg-primary/16 transition-colors">
                <BarChart2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-kai font-semibold text-foreground">{t('navVisualization')}</p>
                <p className="text-xs text-muted-foreground font-song mt-0.5">{t('vizSubtitle')}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
            </button>

            <button
              type="button"
              onClick={() => navigate('/my-collection')}
              className="flex items-center gap-4 p-4 rounded-lg bg-card/70 border border-border/70 hover:border-primary/45 hover:bg-card transition-all group text-left ink-glow-hover"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/8 flex items-center justify-center group-hover:bg-primary/16 transition-colors">
                <BookOpen className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-kai font-semibold text-foreground">{t('myCollectionTitle')}</p>
                <p className="text-xs text-muted-foreground font-song mt-0.5">{t('myCollectionDesc')}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto group-hover:text-primary transition-colors" />
            </button>
          </div>
        </div>
      </section>
      {/* 精选色彩展示 */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-zheshi" />
              <span className="text-xs text-muted-foreground font-song tracking-widest">{t('featuredColorsLabel')}</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-kai font-bold text-foreground section-title-decor">{t('featuredColors')}</h2>
            <p className="text-sm text-muted-foreground font-song mt-2">{t('featuredColorHint')}</p>
          </div>
          <Button
            variant="ghost"
            onClick={() => navigate('/search')}
            className="hidden md:flex items-center gap-1 text-muted-foreground hover:text-foreground font-song"
          >
            {t('viewAll')} <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex flex-col rounded-lg overflow-hidden border border-border">
                <Skeleton className="bg-muted h-40" />
                <div className="p-4 space-y-2">
                  <Skeleton className="bg-muted h-4 w-16" />
                  <Skeleton className="bg-muted h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {featuredColors.map((color, i) => (
              <div
                key={color.id}
                className="h-full opacity-0 intersect:opacity-100 transition-all duration-500 intersect:translate-y-0 translate-y-4"
                style={{ transitionDelay: `${i * 50}ms` }}
              >
                <ColorCard
                  color={color}
                  firstPoem={color.poems?.[0]}
                />
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 flex justify-center md:hidden">
          <Button
            variant="outline"
            onClick={() => navigate('/search')}
            className="font-song"
          >
            {t('viewAllColors')} <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </section>
      {/* 按色系快速导航 */}
      <section className="bg-muted/15 border-t border-border/50 py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-xl md:text-2xl font-kai font-bold text-foreground mb-6 section-title-decor">{t('exploreByFamily')}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {COLOR_FAMILIES.map((family) => (
              <button
                key={family}
                type="button"
                onClick={() => navigate(`/search?colorFamily=${encodeURIComponent(family)}`)}
                className="p-4 text-center rounded-lg bg-card/60 border border-border/60 hover:border-primary/45 hover:bg-card/90 transition-all font-kai text-sm text-foreground ink-glow-hover"
              >
                {getColorFamilyLabel(family, t)}
              </button>
            ))}
          </div>

          {/* 水墨分隔线 */}
          <div className="divider-wash my-10 mx-auto max-w-xs" />

          <h2 className="text-xl md:text-2xl font-kai font-bold text-foreground mt-4 mb-6 section-title-decor">{t('exploreByDynasty')}</h2>
          <div className="flex flex-wrap gap-2">
            {DYNASTIES.map((dynasty) => (
              <button
                key={dynasty}
                type="button"
                onClick={() => navigate(`/search?dynasty=${encodeURIComponent(dynasty)}`)}
                className="px-4 py-2 rounded-full border border-border/70 text-sm text-muted-foreground hover:text-foreground hover:border-primary/50 hover:bg-primary/4 transition-all font-kai"
              >
                {getDynastyLabel(dynasty, t)}
              </button>
            ))}
          </div>
        </div>
      </section>
      {/* 学术说明 */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-16">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-xl md:text-2xl font-kai font-bold text-foreground mb-4">{t('academicTitle')}</h2>
          <p className="text-sm text-muted-foreground font-song leading-relaxed">
            {t('academicDesc')}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 mt-8 text-xs text-muted-foreground">
            {['《说文解字》', '《释名》', '《天工开物》', '《本草纲目》', '《芥子园画谱》'].map((book) => (
              <span key={book} className="font-kai">{book}</span>
            ))}
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
