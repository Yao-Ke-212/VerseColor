import { useEffect, useState, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ColorCard } from '@/components/ColorCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { Color } from '@/types/types';
import { COLOR_FAMILIES, DYNASTIES, EMOTION_TAGS, SEASONS, REGIONS, IMAGERY_CATEGORIES } from '@/types/types';
import { useDebounce } from '@/hooks/use-debounce';
import { useLang } from '@/contexts/LangContext';
import { getColorFamilyLabel, getDynastyLabel, getEmotionLabel, getSeasonLabel, getRegionLabel, getImageryCategoryLabel } from '@/lib/dataLabels';

interface PoemPreview {
  id: string;
  color_id: string;
  color_sentence: string;
  poet: string;
  dynasty: string;
}

// 搜索页色彩卡片只需要展示字段+诗句预览，不依赖完整 Color 类型
interface ColorWithPoem {
  id: string;
  name: string;
  hex_value: string;
  color_family: string;
  sort_order: number;
  poems?: PoemPreview[];
}

const PAGE_SIZE = 16;
const ALL_SIZE = 200; // 无筛选时一次性加载全部

const POETS = ['李白', '杜甫', '苏轼', '李清照', '王维', '白居易', '辛弃疾', '陆游', '杜牧', '李商隐'];

export default function SearchPage() {
  const navigate = useNavigate();
  const { t } = useLang();
  const [searchParams, setSearchParams] = useSearchParams();

  const [keyword, setKeyword] = useState(searchParams.get('keyword') || '');
  const [colorFamily, setColorFamily] = useState(searchParams.get('colorFamily') || '');
  const [dynasty, setDynasty] = useState(searchParams.get('dynasty') || '');
  const [poet, setPoet] = useState(searchParams.get('poet') || '');
  const [emotion, setEmotion] = useState(searchParams.get('emotion') || '');
  const [season, setSeason] = useState(searchParams.get('season') || '');
  const [region, setRegion] = useState(searchParams.get('region') || '');
  const [imageryCategory, setImageryCategory] = useState(searchParams.get('imageryCategory') || '');

  const [colors, setColors] = useState<ColorWithPoem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const debouncedKeyword = useDebounce(keyword, 400);

  const buildQuery = useCallback(() => {
    return {
      keyword: debouncedKeyword,
      colorFamily,
      dynasty,
      poet,
      emotion,
      season,
      region,
      imageryCategory,
    };
  }, [debouncedKeyword, colorFamily, dynasty, poet, emotion, season, region, imageryCategory]);

  const fetchColors = useCallback(async (currentPage: number, reset = false) => {
    if (reset) setLoading(true);
    else setLoadingMore(true);

    const params = buildQuery();
    const hasPoemFilter = !!(params.keyword || params.dynasty || params.poet || params.emotion || params.season || params.region || params.imageryCategory);
    // 无任何筛选时一次性加载全量，有筛选时分页
    const pageSize = (!hasPoemFilter && !params.colorFamily) ? ALL_SIZE : PAGE_SIZE;
    const offset = currentPage * pageSize;

    try {
      type RpcColorRow = { id: string; name: string; hex_value: string; color_family: string; sort_order: number; total_count: number };

      let rows: RpcColorRow[] = [];
      let totalCount = 0;

      if (hasPoemFilter) {
        // 诗词维度有筛选：服务端合并过滤+分页，彻底避免前端 .in() 超长 URL
        const rpcArgs: Record<string, string | number> = {
          p_offset: offset,
          p_limit: pageSize,
        };
        if (params.dynasty) rpcArgs.p_dynasty = params.dynasty;
        if (params.poet) rpcArgs.p_poet = params.poet;
        if (params.emotion) rpcArgs.p_emotion = params.emotion;
        if (params.season) rpcArgs.p_season = params.season;
        if (params.region) rpcArgs.p_region = params.region;
        if (params.imageryCategory) rpcArgs.p_imagery_category = params.imageryCategory;
        if (params.keyword) rpcArgs.p_keyword = params.keyword;
        if (params.colorFamily) rpcArgs.p_color_family = params.colorFamily;

        const { data, error } = await supabase.rpc('search_colors_by_poem_filter', rpcArgs);
        if (error) console.error('search_colors_by_poem_filter error:', error);
        rows = Array.isArray(data) ? data : [];
        totalCount = rows[0]?.total_count ?? 0;
      } else {
        // 无诗词维度筛选：走纯色彩分页 RPC
        const rpcArgs: Record<string, string | number> = {
          p_offset: offset,
          p_limit: pageSize,
        };
        if (params.colorFamily) rpcArgs.p_color_family = params.colorFamily;

        const { data, error } = await supabase.rpc('search_colors_no_filter', rpcArgs);
        if (error) console.error('search_colors_no_filter error:', error);
        rows = Array.isArray(data) ? data : [];
        totalCount = rows[0]?.total_count ?? 0;
      }

      if (rows.length === 0 && currentPage === 0) {
        if (reset) setColors([]);
        setTotal(0);
        setHasMore(false);
        setLoading(false);
        setLoadingMore(false);
        return;
      }

      // 补充 poems 预览字段：批量拉取本页色彩的代表诗句（最多 1 首）
      const ids = rows.map(r => r.id);
      const poemsMap: Record<string, PoemPreview[]> = {};
      if (ids.length > 0) {
        // 分批拉取避免 URL 超长，每批最多 20 个 id
        const BATCH = 20;
        for (let i = 0; i < ids.length; i += BATCH) {
          const batch = ids.slice(i, i + BATCH);
          const { data: pData } = await supabase
            .from('poems')
            .select('id, poet, dynasty, color_sentence, color_id')
            .in('color_id', batch)
            .order('id', { ascending: true });
          if (pData) {
            (pData as PoemPreview[]).forEach(p => {
              if (!poemsMap[p.color_id]) poemsMap[p.color_id] = [];
              if (poemsMap[p.color_id].length < 2) poemsMap[p.color_id].push(p);
            });
          }
        }
      }

      const newColors: ColorWithPoem[] = rows.map(r => ({
        id: r.id,
        name: r.name,
        hex_value: r.hex_value,
        color_family: r.color_family,
        sort_order: r.sort_order,
        poems: poemsMap[r.id] || [],
      }));

      if (reset) {
        setColors(newColors);
      } else {
        setColors(prev => [...prev, ...newColors]);
      }
      setTotal(totalCount);
      setHasMore(rows.length === pageSize && offset + rows.length < totalCount);
    } catch (e) {
      console.error(e);
    }

    setLoading(false);
    setLoadingMore(false);
  }, [buildQuery]);

  useEffect(() => {
    setPage(0);
    fetchColors(0, true);
    // 同步URL参数
    const params: Record<string, string> = {};
    if (debouncedKeyword) params.keyword = debouncedKeyword;
    if (colorFamily) params.colorFamily = colorFamily;
    if (dynasty) params.dynasty = dynasty;
    if (poet) params.poet = poet;
    if (emotion) params.emotion = emotion;
    if (season) params.season = season;
    if (region) params.region = region;
    if (imageryCategory) params.imageryCategory = imageryCategory;
    setSearchParams(params);
  }, [debouncedKeyword, colorFamily, dynasty, poet, emotion, season, region, imageryCategory]);

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchColors(nextPage, false);
  };

  const clearFilters = () => {
    setKeyword('');
    setColorFamily('');
    setDynasty('');
    setPoet('');
    setEmotion('');
    setSeason('');
    setRegion('');
    setImageryCategory('');
  };

  const hasActiveFilters = colorFamily || dynasty || poet || emotion || season || region || imageryCategory;

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* 页头 */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground">{t('searchTitle')}</h1>
          <p className="text-sm text-muted-foreground font-song mt-1">
            {t('filterHint')}
          </p>
        </div>

        {/* 检索栏 - 吸顶 */}
        <div className="space-y-4 mb-8 sticky top-14 md:top-16 z-30 bg-background/95 backdrop-blur py-4 border-b border-border/40 shadow-sm -mx-4 px-4 md:-mx-8 md:px-8">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="pl-9 bg-background font-song"
              />
              {keyword && (
                <button
                  type="button"
                  onClick={() => setKeyword('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className={showFilters ? 'border-primary text-primary' : ''}
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              {t('sortBy')}
              {hasActiveFilters && (
                <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-zheshi inline-block" />
              )}
            </Button>
          </div>
          {/* 筛选提示 */}
          <p className="text-xs text-muted-foreground font-song -mt-1">
            {t('filterHint')}
          </p>

          {/* 展开的筛选面板 */}
          {showFilters && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-muted/20 rounded-lg border border-border animate-fade-in">
              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('colorFamily')}</label>
                <Select value={colorFamily || 'all'} onValueChange={(v) => setColorFamily(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('allFamilies')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('allFamilies')}</SelectItem>
                    {COLOR_FAMILIES.map(f => (
                      <SelectItem key={f} value={f}>{getColorFamilyLabel(f, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('dynasty')}</label>
                <Select value={dynasty || 'all'} onValueChange={(v) => setDynasty(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('allDynasties')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('allDynasties')}</SelectItem>
                    {DYNASTIES.map(d => (
                      <SelectItem key={d} value={d}>{getDynastyLabel(d, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('poet')}</label>
                <Select value={poet || 'all'} onValueChange={(v) => setPoet(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('allPoets')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('allPoets')}</SelectItem>
                    {POETS.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('filterByEmotion')}</label>
                <Select value={emotion || 'all'} onValueChange={(v) => setEmotion(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('filterByEmotion')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('all')}</SelectItem>
                    {EMOTION_TAGS.map(e => (
                      <SelectItem key={e} value={e}>{getEmotionLabel(e, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('filterLabelSeason' as Parameters<typeof t>[0])}</label>
                <Select value={season || 'all'} onValueChange={(v) => setSeason(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('filterAllSeason' as Parameters<typeof t>[0])} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('filterAllSeason' as Parameters<typeof t>[0])}</SelectItem>
                    {SEASONS.map(s => (
                      <SelectItem key={s} value={s}>{getSeasonLabel(s, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('filterLabelRegion' as Parameters<typeof t>[0])}</label>
                <Select value={region || 'all'} onValueChange={(v) => setRegion(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('filterAllRegion' as Parameters<typeof t>[0])} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('filterAllRegion' as Parameters<typeof t>[0])}</SelectItem>
                    {REGIONS.map(r => (
                      <SelectItem key={r} value={r}>{getRegionLabel(r, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground font-song mb-1.5 block">{t('filterLabelImagery' as Parameters<typeof t>[0])}</label>
                <Select value={imageryCategory || 'all'} onValueChange={(v) => setImageryCategory(v === 'all' ? '' : v)}>
                  <SelectTrigger className="bg-background text-sm font-song">
                    <SelectValue placeholder={t('filterAllImagery' as Parameters<typeof t>[0])} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('filterAllImagery' as Parameters<typeof t>[0])}</SelectItem>
                    {IMAGERY_CATEGORIES.map(c => (
                      <SelectItem key={c} value={c}>{getImageryCategoryLabel(c, t)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* 活跃筛选标签 */}
          {hasActiveFilters && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-muted-foreground font-song">{t('filterSelectedCond' as Parameters<typeof t>[0])}</span>
              {colorFamily && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getColorFamilyLabel(colorFamily, t)}
                  <button type="button" onClick={() => setColorFamily('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {dynasty && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getDynastyLabel(dynasty, t)}
                  <button type="button" onClick={() => setDynasty('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {poet && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {poet}
                  <button type="button" onClick={() => setPoet('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {emotion && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getEmotionLabel(emotion, t)}
                  <button type="button" onClick={() => setEmotion('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {season && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getSeasonLabel(season, t)}
                  <button type="button" onClick={() => setSeason('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {region && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getRegionLabel(region, t)}
                  <button type="button" onClick={() => setRegion('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              {imageryCategory && (
                <Badge variant="secondary" className="gap-1 font-song">
                  {getImageryCategoryLabel(imageryCategory, t)}
                  <button type="button" onClick={() => setImageryCategory('')}><X className="w-3 h-3" /></button>
                </Badge>
              )}
              <button
                type="button"
                onClick={clearFilters}
                className="text-xs text-muted-foreground hover:text-foreground underline font-song"
              >
                {t('clearAll')}
              </button>
            </div>
          )}
        </div>

        {/* 结果统计 */}
        {!loading && (
          <p className="text-sm text-muted-foreground font-song mb-6">
            {t('total')} <span className="font-semibold text-foreground">{total}</span> {t('colorUnit')}
          </p>
        )}

        {/* 色彩网格 */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex flex-col rounded-lg overflow-hidden border border-border">
                <Skeleton className="bg-muted h-40" />
                <div className="p-4 space-y-2">
                  <Skeleton className="bg-muted h-4 w-16" />
                  <Skeleton className="bg-muted h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : colors.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground font-song text-sm">
              {t('noResults')}
            </p>
            <Button variant="outline" onClick={clearFilters} className="mt-4 font-song">
              {t('clearAll')}
            </Button>
          </div>
        ) : !hasActiveFilters && !debouncedKeyword ? (
          /* ─── 无筛选：按色系分组展示 ─── */
          <div className="space-y-10">
            {COLOR_FAMILIES.map(family => {
              const familyColors = colors.filter(c => c.color_family === family);
              if (familyColors.length === 0) return null;
              return (
                <div key={family}>
                  {/* 色系标题 */}
                  <div className="flex items-center gap-3 mb-4">
                    <h2 className="font-kai font-semibold text-base text-foreground">{getColorFamilyLabel(family, t)}</h2>
                    <span className="text-xs text-muted-foreground font-song">
                      {familyColors.length} {t('colorUnit')}
                    </span>
                    <div className="flex-1 h-px bg-gradient-to-r from-border to-transparent" />
                    {/* 色系色板速览 */}
                    <div className="flex gap-0.5">
                      {familyColors.slice(0, 8).map(c => (
                        <span key={c.id} className="w-3 h-3 rounded-sm ring-1 ring-border/50"
                          style={{ backgroundColor: c.hex_value }} title={c.name} />
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {familyColors.map((color, i) => (
                      <div key={color.id}
                        className="h-full opacity-0 intersect:opacity-100 transition-all duration-500 intersect:translate-y-0 translate-y-4"
                        style={{ transitionDelay: `${(i % 8) * 40}ms` }}>
                        <ColorCard color={color} firstPoem={color.poems?.[0]} />
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
            {hasMore && (
              <div className="mt-4 text-center">
                <Button variant="outline" onClick={loadMore} disabled={loadingMore} className="font-song">
                  {loadingMore ? t('loading') : t('loadMore')}
                </Button>
              </div>
            )}
          </div>
        ) : (
          /* ─── 有筛选：平铺展示 ─── */
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {colors.map((color, i) => {
                const matchedPoem = dynasty
                  ? (color.poems?.find(p => p.dynasty === dynasty) ?? color.poems?.[0])
                  : color.poems?.[0];
                return (
                  <div key={color.id}
                    className="h-full opacity-0 intersect:opacity-100 transition-all duration-500 intersect:translate-y-0 translate-y-4"
                    style={{ transitionDelay: `${(i % PAGE_SIZE) * 40}ms` }}>
                    <ColorCard color={color} firstPoem={matchedPoem} />
                  </div>
                );
              })}
            </div>
            {hasMore && (
              <div className="mt-8 text-center">
                <Button variant="outline" onClick={loadMore} disabled={loadingMore} className="font-song">
                  {loadingMore ? t('loading') : t('loadMore')}
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </MainLayout>
  );
}
