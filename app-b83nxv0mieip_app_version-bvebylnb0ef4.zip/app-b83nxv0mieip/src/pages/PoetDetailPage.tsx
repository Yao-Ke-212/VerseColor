import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { MainLayout } from '@/components/layouts/MainLayout';
import { InkClickWrapper } from '@/components/InkClickWrapper';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useLang } from '@/contexts/LangContext';
import { getDynastyLabel, getColorDisplayName, getPoetDisplayName } from '@/lib/dataLabels';
import {
  POET_PORTRAITS,
  BOOK_COVERS,
  BOOK_ENTRIES,
  getPoetBgColor,
} from '@/data/poetData';

interface Poet {
  id: string;
  name: string;
  dynasty: string;
  bio: string | null;
  birth_year: string | null;
  death_year: string | null;
  style_summary: string | null;
}

interface PoemWithColor {
  id: string;
  poem_title: string;
  color_sentence: string;
  full_text: string;
  annotation: string | null;
  dynasty: string;
  color_id: string;
  colors: {
    id: string;
    name: string;
    hex_value: string;
  };
}

/**
 * 诗人详情页头像组件 — 与诗人栏目保持完全一致的图像来源
 * 优先级：古籍封面 > 历史画像 > 姓氏文字图标
 */
function PoetDetailAvatar({ name, dynasty }: { name: string; dynasty: string }) {
  const [imgError, setImgError] = useState(false);
  const bookCoverUrl = BOOK_COVERS[name];
  const portraitUrl = POET_PORTRAITS[name];
  const isBook = BOOK_ENTRIES.has(name);
  const bgColor = getPoetBgColor(name, dynasty);

  if (isBook && bookCoverUrl && !imgError) {
    return (
      <div className="w-16 h-16 md:w-20 md:h-20 rounded-full flex-shrink-0 overflow-hidden ring-2 ring-border/50">
        <img
          src={bookCoverUrl}
          alt={`${name}封面`}
          className="w-full h-full object-cover object-center"
          onError={() => setImgError(true)}
        />
      </div>
    );
  }

  if (isBook) {
    return (
      <div
        className="w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: bgColor }}
      >
        <span className="text-2xl md:text-3xl select-none">📖</span>
      </div>
    );
  }

  if (portraitUrl && !imgError) {
    return (
      <div className="w-16 h-16 md:w-20 md:h-20 rounded-full flex-shrink-0 overflow-hidden ring-2 ring-border/50">
        <img
          src={portraitUrl}
          alt={`${name}画像`}
          className="w-full h-full object-cover object-top"
          onError={() => setImgError(true)}
        />
      </div>
    );
  }

  return (
    <div
      className="w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center text-2xl md:text-3xl font-kai font-bold text-white flex-shrink-0"
      style={{ backgroundColor: bgColor }}
    >
      {name.slice(0, 1)}
    </div>
  );
}

export default function PoetDetailPage() {
  const { name } = useParams<{ name: string }>();
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const decodedName = name ? decodeURIComponent(name) : '';

  const [poet, setPoet] = useState<Poet | null>(null);
  const [poems, setPoems] = useState<PoemWithColor[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!decodedName) return;
    setLoading(true);

    const [{ data: poetData }, { data: poemData }] = await Promise.all([
      supabase.from('poets').select('*').eq('name', decodedName).maybeSingle(),
      supabase
        .from('poems')
        .select('id, poem_title, color_sentence, full_text, annotation, dynasty, color_id, colors:color_id(id, name, hex_value)')
        .eq('poet', decodedName)
        .order('created_at', { ascending: true }),
    ]);

    if (poetData) setPoet(poetData);
    if (poemData) setPoems(Array.isArray(poemData) ? poemData as unknown as PoemWithColor[] : []);
    setLoading(false);
  }, [decodedName]);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-8">
          <Skeleton className="bg-muted h-5 w-20 mb-8" />
          <div className="flex gap-5 mb-8">
            <Skeleton className="bg-muted w-20 h-20 rounded-full flex-shrink-0" />
            <div className="flex-1 space-y-3">
              <Skeleton className="bg-muted h-7 w-32" />
              <Skeleton className="bg-muted h-4 w-full" />
              <Skeleton className="bg-muted h-4 w-3/4" />
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* 返回 */}
        <button
          type="button" onClick={() => navigate(-1)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 font-song transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />{t('backToPoets')}
        </button>

        {/* 诗人信息 */}
        <div className="card-rice-paper p-6 md:p-8 mb-8">
          <div className="flex items-start gap-5">
            <PoetDetailAvatar name={decodedName} dynasty={poet?.dynasty || ''} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-2">
                <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground">{getPoetDisplayName(decodedName, isChinese)}</h1>
                {poet?.dynasty && (
                  <Badge variant="secondary" className="font-song">{getDynastyLabel(poet.dynasty, t)}</Badge>
                )}
                {poet?.birth_year && poet?.death_year && (
                  <span className="text-sm text-muted-foreground font-song">
                    {t('poetBirthApprox')}{poet.birth_year}{t('poetYearSuffix')}—{t('poetBirthApprox')}{poet.death_year}{t('poetYearSuffix')}
                  </span>
                )}
              </div>
              {poet?.bio ? (
                <p className="text-sm text-foreground/80 font-song leading-relaxed">{poet.bio}</p>
              ) : (
                <p className="text-sm text-muted-foreground font-song">{t('noData')}</p>
              )}
              {poet?.style_summary && (
                <div className="mt-3 pt-3 border-t border-border/60">
                  <p className="text-xs text-muted-foreground font-song font-semibold mb-1">{t('poetStyle')}</p>
                  <p className="text-sm text-foreground/75 font-kai leading-relaxed">{poet.style_summary}</p>
                </div>
              )}
              {!isChinese && (poet?.bio || poet?.style_summary) && (
                <p className="text-xs text-muted-foreground/60 font-song mt-2 italic">
                  {t('bioInChineseNote')}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* 诗词与色彩意象 */}
        <div>
          <h2 className="text-lg md:text-xl font-kai font-bold text-foreground mb-4">
            {t('poetPoemsTitle')}
            <span className="text-sm font-normal text-muted-foreground font-song ml-2">
              {t('collectionCount')} {poems.length} {t('collectionCountUnit')}
            </span>
          </h2>

          {poems.length === 0 ? (
            <div className="card-rice-paper p-8 text-center">
              <p className="text-muted-foreground font-song text-sm">{t('noPoetPoems')}</p>
              <Button variant="outline" onClick={() => navigate('/search')} className="mt-3 font-song">
                {t('viewAllColors')}
              </Button>
            </div>
          ) : (
            <div className="space-y-5">
              {poems.map((poem, i) => (
                <div
                  key={poem.id}
                  className="card-rice-paper p-5 md:p-6 opacity-0 intersect:opacity-100 transition-all duration-500 intersect:translate-y-0 translate-y-3"
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <Link
                        to={`/poem/${poem.id}`}
                        className="font-kai text-base md:text-lg font-semibold text-primary hover:underline"
                      >
                        《{poem.poem_title}》
                      </Link>
                      <p className="text-xs text-muted-foreground font-song mt-0.5">{getDynastyLabel(poem.dynasty, t)}</p>
                    </div>
                    {/* 色彩色块 */}
                    {poem.colors && (
                      <InkClickWrapper>
                        <button
                          type="button"
                          onClick={() => navigate(`/color/${poem.colors.id}`)}
                          className="flex flex-col items-center gap-1 flex-shrink-0"
                        >
                          <div
                            className="w-10 h-10 rounded-lg ring-1 ring-border hover:ring-primary/50 transition-all"
                            style={{ backgroundColor: poem.colors.hex_value }}
                          />
                          <span className="text-[10px] font-kai text-muted-foreground">{getColorDisplayName(poem.colors.name, isChinese)}</span>
                        </button>
                      </InkClickWrapper>
                    )}
                  </div>

                  {/* 色彩意象诗句 */}
                  <p className="poem-quote text-sm md:text-base font-kai text-foreground/85 mb-3">
                    「{poem.color_sentence}」
                  </p>

                  {/* 注释 */}
                  {poem.annotation && (
                    <p className="text-xs text-muted-foreground font-song leading-relaxed">{poem.annotation}</p>
                  )}

                  {/* 底部链接 */}
                  <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border/50">
                    <Link
                      to={`/poem/${poem.id}`}
                      className="text-xs text-primary font-song hover:underline"
                    >
                      {t('readFullPoem')} →
                    </Link>
                    {poem.colors && (
                      <Link
                        to={`/color/${poem.colors.id}`}
                        className="text-xs text-muted-foreground font-song hover:text-foreground transition-colors"
                      >
                        「{getColorDisplayName(poem.colors.name, isChinese)}」{t('colorDetailLink')}
                      </Link>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
