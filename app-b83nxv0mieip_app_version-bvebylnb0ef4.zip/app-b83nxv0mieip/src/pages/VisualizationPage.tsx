import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  LineChart, Line, Tooltip as RechartsTooltip,
} from 'recharts';
import { Search } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { useLang } from '@/contexts/LangContext';
import { getDynastyLabel, getEmotionLabel, getColorDisplayName } from '@/lib/dataLabels';

interface DynastyColorStat {
  name: string;
  count: number;
  hex: string;
  id?: string;
}

interface DynastyTopData {
  dynasty: string;
  top: DynastyColorStat[];
}

const DYNASTY_COLORS: Record<string, string> = {
  '先秦': '#9E4F2C', '汉': '#C9A84C', '魏晋': '#5B8C5A',
  '南北朝': '#4B7893', '隋': '#B5495B', '唐': '#3D4A5C',
  '五代': '#6B3E8E', '宋': '#3A9D8B', '元': '#62B5C9',
  '明': '#CB3A56', '清': '#9E4F2C',
};

// 哨兵值：代表"全部"筛选，避免硬编码中文作为状态值
const ALL_FILTER = '__ALL__';

// 色系分类（色相范围）- key 用于 i18n 查找，test 用于过滤逻辑
const COLOR_FAMILY_DEFS = [
  { key: 'vizFamAll',         test: () => true },
  { key: 'vizFamRed',         test: (hex: string) => { const h = hexToHue(hex); return (h >= 330 || h < 30); } },
  { key: 'vizFamOrangeYellow',test: (hex: string) => { const h = hexToHue(hex); return h >= 30 && h < 80; } },
  { key: 'vizFamGreen',       test: (hex: string) => { const h = hexToHue(hex); return h >= 80 && h < 165; } },
  { key: 'vizFamBlueCyan',    test: (hex: string) => { const h = hexToHue(hex); return h >= 165 && h < 260; } },
  { key: 'vizFamPurple',      test: (hex: string) => { const h = hexToHue(hex); return h >= 260 && h < 330; } },
  { key: 'vizFamNeutral',     test: (hex: string) => { const s = hexToSat(hex); return s < 15; } },
] as const;

function hexToHue(hex: string): number {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  if (max === min) return 0;
  const d = max - min;
  let h = 0;
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
  else if (max === g) h = ((b - r) / d + 2) / 6;
  else h = ((r - g) / d + 4) / 6;
  return h * 360;
}

function hexToSat(hex: string): number {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return 0;
  const d = max - min;
  return (l > 0.5 ? d / (2 - max - min) : d / (max + min)) * 100;
}

const DYNASTY_ORDER = ['先秦', '汉', '魏晋', '南北朝', '隋', '唐', '五代', '宋', '金', '元', '明', '清', '近现代'];

// ============================================================
// 诗人各阶段个性化境遇分值（基于历史事实）
// 分值范围 0–100：越高越顺遂
// ============================================================
const POET_STAGE_SCORES: Record<string, Record<string, number>> = {
  '李白':   { '早年': 72, '中年': 38, '晚年': 28 },   // 漫游自在→赐金放还→流放夜郎
  '杜甫':   { '早年': 70, '中年': 28, '晚年': 20 },   // 裘马自如→安史之乱→漂泊西南贫病
  '苏轼':   { '早年': 84, '中年': 32, '晚年': 48 },   // 少年得志→乌台诗案贬谪→赦归有余
  '白居易': { '早年': 76, '中年': 44, '晚年': 70 },   // 及第春风→贬谪江州→洛阳闲适
  '李清照': { '早年': 88, '中年': 22, '晚年': 38 },   // 金石生涯→丧夫流亡→孤老江南
  '辛弃疾': { '早年': 82, '中年': 26, '晚年': 52 },   // 战场英雄→投闲置散20年→晚年起复
  '屈原':   { '早年': 80, '中年': 18, '晚年': 10 },   // 深受楚王信任→初放汉北→再放汨罗投江
  '陶渊明': { '早年': 48, '中年': 78, '晚年': 58 },   // 出仕不顺→归田安贫→晚年清贫
  '李煜':   { '早年': 90, '中年': 55, '晚年': 8 },    // 南唐繁华→国力日衰→囚宋中毒
  '王维':   { '早年': 78, '中年': 65, '晚年': 74 },   // 少年登第→辋川半隐→荣封受尊
  '李商隐': { '早年': 60, '中年': 26, '晚年': 20 },   // 进士及第→牛李夹缝→困顿早逝
  '杜牧':   { '早年': 80, '中年': 50, '晚年': 46 },   // 少年成名→历幕府→病重任职
  '刘禹锡': { '早年': 74, '中年': 30, '晚年': 60 },   // 永贞革新→23年贬谪→"沉舟侧畔千帆过"晚岁归
  '王昌龄': { '早年': 74, '中年': 35, '晚年': 28 },   // 进士→龙标贬谪→乱中被杀
  '李贺':   { '早年': 72, '中年': 30, '晚年': 18 },   // 鬼才少年→仕途受阻→27岁早逝
  '纳兰性德':{ '早年': 82, '中年': 48, '晚年': 35 },  // 御前侍卫→爱妻早逝→忧郁而终
  '陆游':   { '早年': 65, '中年': 30, '晚年': 40 },   // 抗金壮志→唐琬别离→放翁暮年
  '曹操':   { '早年': 55, '中年': 80, '晚年': 65 },   // 初出茅庐→挟天子令诸侯→一统北方
};

// 诗人生平详细档案 — 用于生命周期小结深化叙述
const POET_LIFE_PROFILES: Record<string, {
  earlyLife: string;
  midLife: string;
  lateLife: string;
  keyEvent: string;
  colorRule: string;
  earlyLifeEn: string;
  midLifeEn: string;
  lateLifeEn: string;
  keyEventEn: string;
  colorRuleEn: string;
}> = {
  '李白': {
    earlyLife: '少年漫游四方，25岁出川，才名远播，入翰林供奉，意气风发',
    midLife: '因遭权贵嫉恨，被唐玄宗"赐金放还"，离开长安，壮志未酬',
    lateLife: '安史之乱中因永王案被流放夜郎，赦还后不久病逝于安徽',
    keyEvent: '赐金放还（742年）是其人生转折——从政治核心到漫游天涯，失意与自由并存',
    colorRule: '早年月白、翠色等清冷仙气之色渐多，晚年漂泊中暗色与萧索意象增加，印证"得意时明，失意时暗"的色彩规律',
    earlyLifeEn: 'Traveled widely in youth, gained fame by 25, served in the Imperial Academy with high ambitions',
    midLifeEn: 'Dismissed from court ("given gold to leave") due to court intrigues, ambitions unfulfilled',
    lateLifeEn: 'Exiled to Yelang during the An Lushan Rebellion, pardoned but died soon after in Anhui',
    keyEventEn: 'Dismissal from court (742 CE) was the pivot — from political center to wandering exile',
    colorRuleEn: 'Early moon-white and jade hues give way to darker, bleaker tones in exile — illustrating how fortune shapes palette',
  },
  '杜甫': {
    earlyLife: '出身京兆望族，少年游历吴越与齐赵，裘马轻狂，科举失意后寓居长安十年',
    midLife: '安史之乱爆发（755年），被叛军所俘，脱逃后历任小官，饱经战乱之苦',
    lateLife: '辞官后携家入蜀依托严武，后漂泊荆湘，老病交加，770年病逝于湘江舟中',
    keyEvent: '安史之乱（755年）是杜甫人生的分水岭——由此"朱门酒肉臭，路有冻死骨"的现实主义成为其创作底色',
    colorRule: '早年偶有明丽之色，安史之乱后笔下多苍黑、萧索之色，与其以诗记史、悲天悯人的人生境遇高度吻合',
    earlyLifeEn: 'Born into an aristocratic family, wandered freely in youth, then spent a decade in Chang\'an after failing the imperial exam',
    midLifeEn: 'Captured then escaped during the An Lushan Rebellion, served in minor posts amid constant hardship',
    lateLifeEn: 'Resigned and wandered through Sichuan and Hunan, died of illness on a boat on the Xiang River in 770',
    keyEventEn: 'The An Lushan Rebellion (755 CE) was Du Fu\'s watershed — realism and social conscience became his defining voice',
    colorRuleEn: 'Early scattered bright hues give way post-rebellion to grey-black and desolate tones, mirroring his witness to empire\'s fall',
  },
  '苏轼': {
    earlyLife: '21岁高中进士，欧阳修赞其"此人他日文章必独步天下"，仕途初期顺遂',
    midLife: '因反对王安石变法遭排斥，后又因"乌台诗案"（1079年）下狱，贬谪黄州，此后历贬惠州、儋州',
    lateLife: '徽宗即位后获赦北归，途中病逝于常州（1101年），终未能回归政治中心',
    keyEvent: '乌台诗案（1079年）是苏轼人生最重要的转折——从此创作由豪迈进取转向超然旷达，《赤壁赋》《定风波》皆作于贬谪之后',
    colorRule: '早年明丽色彩较多，贬谪后青、苍、灰色增多，但苏轼旷达天性使其晚年色彩中仍保留竹绿、松色等清逸之色，体现逆境中的精神自守',
    earlyLifeEn: 'Passed the imperial exam at 21; praised by Ouyang Xiu as destined for literary greatness',
    midLifeEn: 'Opposed Wang Anshi\'s reforms; imprisoned in the Crow Terrace Incident (1079), exiled to Huangzhou then Huizhou and Danzhou',
    lateLifeEn: 'Pardoned by Emperor Huizong but died en route home in Changzhou (1101)',
    keyEventEn: 'Crow Terrace Incident (1079 CE): pivotal turn from bold ambition to magnanimous acceptance — Red Cliff Ode and Dingfengbo written in exile',
    colorRuleEn: 'Bright early colors give way to blue-grey after exile; yet his resilient spirit keeps clear bamboo-green amid hardship',
  },
  '李清照': {
    earlyLife: '出生书香门第，18岁嫁赵明诚，夫妻金石唱和，早期词作充满少女青春与闺阁欢愉',
    midLife: '靖康之变（1127年）北宋灭亡，赵明诚病逝，李清照独自带着文物南下流亡，所藏文物大多散失',
    lateLife: '流亡辗转杭州、金华等地，改嫁失败后孤苦伶仃，晚年潦倒于临安',
    keyEvent: '靖康之变（1127年）与丈夫赵明诚去世是李清照人生最大的转折——词风由清丽转向沉郁，"寻寻觅觅，冷冷清清"是其晚境写照',
    colorRule: '早期词中桃红、翠绿、金黄等鲜亮色彩，靖康后渐变为黄昏残照、秋风冷雨的冷色调，印证了词人以色彩书写身世飘零之痛',
    earlyLifeEn: 'Born into a literary family, married Zhao Mingcheng at 18; early lyrics full of girlish joy and domestic bliss',
    midLifeEn: 'Jingkang Catastrophe (1127): Northern Song fell, husband died, Li fled south alone losing most of her collections',
    lateLifeEn: 'Wandered between Hangzhou and Jinhua; a failed remarriage left her impoverished and alone in Lin\'an',
    keyEventEn: 'Jingkang (1127) and husband\'s death were the turning points — "seeking, seeking, cold and desolate" became her late-life tone',
    colorRuleEn: 'Early peach-pink, jade-green and gold give way to dusk-red and cold-rain hues — color as autobiography of displacement',
  },
  '辛弃疾': {
    earlyLife: '21岁率50骑劫营，投归南宋，英雄气概赫赫，初期受重用参与抗金谋划',
    midLife: '因主战立场与南宋主和派政治格格不入，42岁遭弹劾罢官，在江西带湖闲居长达20年',
    lateLife: '64岁再度起用，因年老多病心力俱衰，1207年含恨病逝，临终高呼"杀贼！杀贼！"',
    keyEvent: '长达20年的投闲置散（1181-1203年）是辛弃疾创作最丰产的时期，壮志难酬的悲怆化为词中烈火般的激情',
    colorRule: '金色、血红等战场激昂之色折射其英雄气概，苍茫暮色与落日余晖则寄托壮志难酬的悲壮——色彩随仕途起伏而明暗交替',
    earlyLifeEn: 'Led 50 cavalry in a daring raid at 21, joined Southern Song as a hero of anti-Jin resistance',
    midLifeEn: 'Forced out of office at 42 by pacifist factions; idle for 20 years in Jiangxi\'s Dailu estate',
    lateLifeEn: 'Recalled at 64 but aging and ill; died in 1207 reportedly crying "Kill the enemy!" on his deathbed',
    keyEventEn: 'Twenty years of enforced idleness (1181-1203) — his most prolific period, turning unfulfilled patriotism into blazing lyric fire',
    colorRuleEn: 'War-gold and blood-red for heroic fervor; dusk-grey and setting-sun tones for tragic unfulfillment — bright and dark alternating with fortune',
  },
  '屈原': {
    earlyLife: '楚国贵族，深受楚怀王信任，参与内政外交，力主联齐抗秦',
    midLife: '遭奸臣靳尚等诬陷，被怀王疏远，流放汉北，写下《离骚》以抒郁愤',
    lateLife: '楚国被秦所灭，屈原绝望投汨罗江，以身殉国，留下《九歌》《天问》等不朽篇章',
    keyEvent: '两度被放逐是屈原的人生转折——忠君报国之志与现实政治的残酷形成终身无法愈合的裂痕',
    colorRule: '香草美人的香泽之色与苍茫流放的暗色形成鲜明对比，高洁理想与现实幻灭在色彩中并峙',
    earlyLifeEn: 'Noble of the Chu state, trusted advisor to King Huai, advocating alliance with Qi against Qin',
    midLifeEn: 'Slandered by rivals, estranged by the king, exiled to the Han River north region; wrote Li Sao in anguish',
    lateLifeEn: 'When Chu was conquered by Qin, Qu Yuan drowned himself in the Miluo River, leaving Nine Songs and Questions to Heaven',
    keyEventEn: 'Twice exiled — the irreconcilable gap between his loyalty and political reality defined his tragic life and verse',
    colorRuleEn: 'Fragrant-herb luminous colors vs bleak exile tones — noble ideals and bitter disillusion rendered in chromatic contrast',
  },
  '陶渊明': {
    earlyLife: '出身没落贵族，29岁始仕，多次出仕又辞官，矛盾于仕隐之间',
    midLife: '41岁彻底归隐，自号"五柳先生"，"不为五斗米折腰"成其人生标志',
    lateLife: '归田躬耕，安贫乐道，晚年清贫却怡然自得，留下"采菊东篱下，悠然见南山"等千古名句',
    keyEvent: '41岁弃彭泽县令归隐是决定性转折——此后"晨兴理荒秽，带月荷锄归"的农耕生活成为其诗歌的永恒主题',
    colorRule: '归隐后草色、黄菊、白云等朴素自然之色大量出现，与其不慕荣利、回归本真的人生哲学完美呼应',
    earlyLifeEn: 'Descended from impoverished nobility; served and resigned from office multiple times, torn between career and reclusion',
    midLifeEn: 'Retired permanently at 41, calling himself "Mr. Five Willows"; "won\'t bow for five pecks of rice" became his motto',
    lateLifeEn: 'Farmed and lived simply, content in poverty; wrote "Picking chrysanthemums by the eastern fence, leisurely glimpsing South Mountain"',
    keyEventEn: 'Resigning his magistracy at 41 was decisive — farming life and pastoral simplicity became his eternal poetic subject',
    colorRuleEn: 'Post-retirement grass-green, chrysanthemum-yellow and white cloud imagery — colors perfectly matching his anti-materialist philosophy',
  },
  '李煜': {
    earlyLife: '南唐后主，宫廷生活奢靡，词风华美柔婉，"晓妆初过，沉檀轻注些儿个"极尽富贵风流',
    midLife: '宋兵逼近，国势日危，李煜在词中以醇酒美人掩盖亡国的恐惧',
    lateLife: '975年南唐亡国，被俘入宋，封"违命侯"，978年在生日宴上被宋太宗毒杀，"问君能有几多愁"成千古绝唱',
    keyEvent: '975年亡国被俘是李煜的彻底转折——由奢靡的一国之君变为阶下囚，词风从香艳转向深沉，成就了中国词史上最感人的亡国之音',
    colorRule: '亡国前金色、脂粉色等华贵色调，亡国后月白、冷雨、秋水等哀怨冷色大量涌现，色彩的骤变正是命运剧烈转折的直接投影',
    earlyLifeEn: 'Last ruler of Southern Tang; palace life luxurious and lyrics ornate, capturing the pinnacle of courtly splendor',
    midLifeEn: 'As Song troops advanced and the state crumbled, Li Yu used wine and beauty in verse to mask his dread',
    lateLifeEn: 'Captured after Southern Tang fell in 975, given the mocking title "Marquis Disobeying Orders," poisoned at his birthday feast in 978',
    keyEventEn: 'National fall and captivity (975 CE) — the absolute turn from splendor to sorrow, producing China\'s most moving laments of a lost kingdom',
    colorRuleEn: 'Pre-captivity gold and rouge give way to cold moon-white, rain and autumn-water hues — the chromatic rupture mirrors his catastrophic fate',
  },
  '王维': {
    earlyLife: '少年登第，诗书画乐皆精，21岁进士，入仕顺遂，以《九月九日忆山东兄弟》名世',
    midLife: '安史之乱中被迫接受伪职，乱后因"陷贼"险获死罪，因弟王缙求情得免，此后更深信佛教',
    lateLife: '晚年在辋川半官半隐，以"摩诘居士"自称，山水田园诗臻于化境，"诗佛"之名传世',
    keyEvent: '安史之乱陷贼受职是王维的精神转折——从此更深笃信佛教，辋川别业的隐居生涯成就了"行到水穷处，坐看云起时"的超然境界',
    colorRule: '空翠、松色、水碧等佛禅色彩贯穿其创作，与其以禅观世界、以画入诗的美学追求高度契合',
    earlyLifeEn: 'Brilliant from youth in poetry, painting and music; passed imperial exam at 21; known for nostalgic verse',
    midLifeEn: 'Forced to serve under rebel rule during An Lushan Rebellion; narrowly escaped death thanks to his brother\'s plea',
    lateLifeEn: 'Semi-retired at Wangchuan estate in old age; known as "the Poet-Buddha" for transcendent nature verse',
    keyEventEn: 'Serving the rebels became a spiritual pivot — deeper Buddhism and Wangchuan reclusion yielded his most transcendent nature poetry',
    colorRuleEn: 'Void-green, pine-color and water-blue throughout — Buddhist color-consciousness and painting-poetry fusion perfectly aligned',
  },
  '纳兰性德': {
    earlyLife: '明珠之子，22岁进士，任康熙御前侍卫，才华出众，与顾贞观、朱彝尊等文人唱和',
    midLife: '爱妻卢氏28岁难产去世（1674年），纳兰性德此后陷入长久的哀痛，词风由清丽转向凄婉',
    lateLife: '因长期忧思过度，31岁英年早逝（1685年），留下《饮水词》等凄美词作',
    keyEvent: '爱妻卢氏之死（1674年）是纳兰性德最深的伤口——"人生若只如初见，何事秋风悲画扇"道尽此后十年的至死不渝',
    colorRule: '雪白、霜色、月白等冷洁之色贯穿其词，是对亡妻洁白形象的永恒追念，也是其至死不渝深情的色彩化身',
    earlyLifeEn: 'Son of a powerful minister; imperial guard to Emperor Kangxi at 22; brilliant young scholar-poet',
    midLifeEn: 'Beloved wife Lu died in childbirth at 28 (1674); he fell into lasting grief, lyrics turning from bright to mournful',
    lateLifeEn: 'Died at just 31 (1685), leaving behind Yinshuici — some of the most heart-rending verse in Qing poetry',
    keyEventEn: 'Wife Lu\'s death (1674): "If only life were as it was at first meeting..." — a wound that shaped his final decade',
    colorRuleEn: 'Snow-white, frost-pale and moon-white — the chromatic embodiment of his eternal devotion to a lost wife',
  },
  '刘禹锡': {
    earlyLife: '贞元年间进士，参与王叔文"永贞革新"，意气风发，锐意政治改革',
    midLife: '革新失败后被贬朗州、连州等地长达23年，写下"沉舟侧畔千帆过，病树前头万木春"的旷达诗句',
    lateLife: '晚年回朝与白居易唱和，虽身历磨难却精神不衰，以"刘郎"自称，笑对人生',
    keyEvent: '永贞革新失败（805年）后23年贬谪，是刘禹锡最重要的磨砺——"千淘万漉虽辛苦，吹尽狂沙始到金"正是其人生写照',
    colorRule: '贬谪岁月中仍见金色、翠色等明丽之色，折射其屡遭打击却愈挫愈奋的乐观精神',
    earlyLifeEn: 'Passed the exam during Zhenyuan era; joined Wang Shuwen\'s Yongzhen Reform with reformist zeal',
    midLifeEn: 'After the reform\'s failure, exiled to remote posts for 23 years; wrote "Beside sunken ships a thousand sails pass"',
    lateLifeEn: 'Returned to court in old age, exchanging verse with Bai Juyi; known for indomitable wit and resilience',
    keyEventEn: '23-year exile after the 805 Yongzhen Reform failure — his greatest forge; "gold emerges only after all the sand is washed away"',
    colorRuleEn: 'Even in exile, gold and jade-green tones appear — reflecting his unbroken optimism against repeated adversity',
  },
  '欧阳修': {
    earlyLife: '少年孤苦，母以荻画地教字，23岁进士及第，文坛初露锋芒',
    midLife: '因支持范仲淹"庆历新政"被贬滁州，写下《醉翁亭记》，贬谪反成其文学高峰',
    lateLife: '晚年以"六一居士"自号，倡导诗文革新，提携苏轼、曾巩等后学，影响深远',
    keyEvent: '贬滁（1045年）是欧阳修的意外转机——远离朝堂的滁州岁月孕育出"醉翁之意不在酒"的千古名句，亦使其文学更加自由旷达',
    colorRule: '色彩偏向翠绿、明黄等清新典雅之色，折射其文人雅士的审美趣味与庆历年间相对开明的时代底色',
    earlyLifeEn: 'Raised in poverty; mother taught him writing with reeds; passed the imperial exam at 23',
    midLifeEn: 'Exiled to Chuzhou for supporting the Qingli Reform; there wrote the immortal Drunkard\'s Pavilion Record',
    lateLifeEn: 'Self-titled "The Six-One Recluse" in old age; mentored Su Shi and Zeng Gong, reshaping Northern Song literature',
    keyEventEn: 'Exile to Chuzhou (1045) unexpectedly became his creative peak — freedom from court yielded his most celebrated prose',
    colorRuleEn: 'Refined jade-green and warm yellow — the aesthetic palette of a cultured official in a relatively enlightened era',
  },
  '王昌龄': {
    earlyLife: '出身贫寒，耕读为生，27岁进士，以边塞诗名冠天下，"七绝圣手"之称由此而来',
    midLife: '因"不矜细行"被贬岭南，后再贬龙标，与李白相交，李白《闻王昌龄左迁龙标》为其抱屈',
    lateLife: '安史之乱中辗转还乡，途中被刺史闾丘晓所杀，一代诗才含冤陨落',
    keyEvent: '两度被贬（岭南、龙标）塑造了王昌龄旷达悲壮的诗风，边塞豪情与贬谪之痛在其七绝中并峙',
    colorRule: '金色、黄沙、碧血等边塞豪迈之色与萧索冷色并存，折射其在报国热情与个人际遇之间的张力',
    earlyLifeEn: 'Born poor, farmed and studied; passed the exam at 27; crowned "Master of Seven-Character Quatrains"',
    midLifeEn: 'Exiled to Lingnan and then Longbiao for misconduct; Li Bai wrote a famous poem lamenting his fate',
    lateLifeEn: 'Killed by a local official during the An Lushan Rebellion while trying to return home — a tragic end',
    keyEventEn: 'Two exiles shaped his bold, melancholic style; frontier ardor and personal suffering fused in his matchless quatrains',
    colorRuleEn: 'Gold, desert-sand and battlefield hues alongside cold bleakness — the chromatic tension between patriotism and misfortune',
  },
  '韩愈': {
    earlyLife: '三岁丧父，兄长抚养，19岁入京应试屡败，25岁方中进士，后任监察御史',
    midLife: '因上《论天旱人饥状》触怒权贵被贬阳山，后因谏迎佛骨被贬潮州，写下《左迁至蓝关示侄孙湘》',
    lateLife: '晚年官复原职，位至吏部侍郎，被尊为"文起八代之衰"，与柳宗元共倡古文运动',
    keyEvent: '谏迎佛骨被贬潮州（819年）是韩愈的至暗时刻——"一封朝奏九重天，夕贬潮州路八千"道尽忠直之士的悲凉',
    colorRule: '色彩苍劲有力，多见铁黑、深青等沉重色调，与其古文运动领袖的硬朗风格和忠直仕途高度呼应',
    earlyLifeEn: 'Orphaned at 3, raised by his elder brother; failed the exam three times before passing at 25',
    midLifeEn: 'Exiled to Yangshan for criticizing officials; later banished to Chaozhou for remonstrating against Buddhist relic worship',
    lateLifeEn: 'Rehabilitated to high office; revered as restorer of eight dynasties of literary decline, co-leading the Classical Prose Movement',
    keyEventEn: 'Banishment to Chaozhou (819 CE) — "memorialized the throne at dawn, exiled eight thousand li by dusk" epitomizes loyal remonstrance',
    colorRuleEn: 'Iron-black and deep indigo — bold, forceful tones mirroring his unyielding personality and Classical Prose mission',
  },
  '李贺': {
    earlyLife: '幼年即以诗才惊世，7岁赋诗令韩愈叹服，有"诗鬼"之称，然因父名"晋肃"被阻参加进士考试',
    midLife: '因避父讳不得应试，终身仕途受阻，仅任太常寺奉礼郎九品小官，郁郁寡欢',
    lateLife: '27岁因多病体衰而逝，英年早逝，一生留下240余首奇崛诡谲的诗作，以其独特的鬼魅意象震撼后世',
    keyEvent: '"避讳"制度的荒诞牢笼是李贺最大的人生悲剧——才华横溢却被"父名"之讳永久阻于功名门外，郁郁而终',
    colorRule: '多用鬼火绿、血红、漆黑等诡谲色彩，与其"诗鬼"称号及鬼魅浪漫主义诗风相互印证',
    earlyLifeEn: 'Astonished Han Yu with a poem at age 7; nicknamed "Demon Poet"; barred from imperial exams due to his father\'s name taboo',
    midLifeEn: 'Blocked from examinations for life by the name-taboo rule; served only as a minor ceremonial official',
    lateLifeEn: 'Died at just 27, leaving 240+ extraordinary poems of grotesque imagery and dazzling, haunted brilliance',
    keyEventEn: 'The cruel name-taboo rule permanently barred him from officialdom — trapped genius burning bright then extinguished at 27',
    colorRuleEn: 'Ghost-fire green, blood-red and pitch-black — the chromatic otherworld matching his "Demon Poet" visions',
  },
  '王之涣': {
    earlyLife: '出身太原王氏名门，少年豪侠，不拘小节，与高适、王昌龄为诗友，"旗亭画壁"的佳话主角',
    midLife: '因遭人诬陷被贬，离职家居十余年，以游历山水排遣抑郁，诗作虽少却篇篇传世',
    lateLife: '晚年复出为官，任文安县尉，55岁卒于任所，传世诗作仅六首，却有《凉州词》《登鹳雀楼》两首千古绝唱',
    keyEvent: '"旗亭画壁"（716年）是王之涣人生的浪漫注脚——与王昌龄、高适三人赌赛，伶人所唱之诗证明了"黄河远上白云间"天下第一',
    colorRule: '黄沙、白云、远天青色等壮阔苍茫之色，体现其以极简意象写就边塞豪情的独特美学',
    earlyLifeEn: 'Born into the noble Wang clan; a chivalrous youth famous for the "Poetry Flag Inn" episode with Wang Changling and Gao Shi',
    midLifeEn: 'Falsely accused and resigned; spent over a decade wandering mountains and rivers to ease his frustrations',
    lateLifeEn: 'Returned to minor official posts in old age; died at 55; only six poems survive — two are among China\'s most beloved',
    keyEventEn: 'The Flag Inn Poetry Contest (716 CE) — performers chose his "Yellow River to the White Cloud" first, vindicating his genius',
    colorRuleEn: 'Yellow sand, white cloud and vast sky-blue — minimalist grandeur conveying frontier heroism in just a few strokes',
  },
  '张若虚': {
    earlyLife: '扬州人，与贺知章、张旭、包融并称"吴中四士"，仕途平平，官至兖州兵曹',
    midLife: '生平事迹史书记载极少，以诗作流传，《春江花月夜》是其存世最重要的作品',
    lateLife: '生卒年不详，身后长期湮没无闻，直至明清方被重新发现，清人王闿运誉其"孤篇横绝，竟为大家"',
    keyEvent: '一首《春江花月夜》以孤篇之力问鼎唐诗巅峰——"江畔何人初见月，江月何年初照人"的宇宙之问令后世无数文人叹绝',
    colorRule: '银白月光、碧蓝春江、霜白汀洲等冷柔之色，构建出超越时空的诗意宇宙，色彩即哲思',
    earlyLifeEn: 'From Yangzhou; one of the "Four Gentlemen of Wu"; served as a minor military scribe',
    midLifeEn: 'Historical records are sparse; his legacy rests almost entirely on one poem — Spring River with Flowers and Moon on a Spring Night',
    lateLifeEn: 'Dates of birth and death unknown; obscure for centuries until Ming-Qing scholars rediscovered him as a transcendent master',
    keyEventEn: 'One poem crowning all of Tang poetry — "Who first saw the moon by the river? When did the river moon first shine on men?"',
    colorRuleEn: 'Silver moonlight, blue-jade river, frost-white sandbars — cool tender colors building a philosophical cosmos beyond time',
  },
  '曹操': {
    earlyLife: '出身宦官家族，少年机警，20岁举孝廉，黄巾起义后展露军事才能，迅速崛起',
    midLife: '挟天子以令诸侯，官渡之战大败袁绍，统一北方，建立曹魏政权的基础',
    lateLife: '晚年称魏王，赤壁之战后南征受挫，转向经营内政，65岁在洛阳病逝，其子曹丕称帝',
    keyEvent: '官渡之战（200年）以少胜多是曹操人生的决定性转折——从此奠定北方霸主地位，"老骥伏枥，志在千里"的豪情贯穿其后半生',
    colorRule: '苍茫大地、铁黑战场等雄浑色调映照其政治家与军事家的气魄，《观沧海》的碧波汪洋是其胸怀天下的色彩宣言',
    earlyLifeEn: 'Rose from an eunuch family; showed military talent during the Yellow Turban Rebellion',
    midLifeEn: 'Controlled the Han emperor as puppet; defeated Yuan Shao at Guandu, unifying northern China',
    lateLifeEn: 'Declared King of Wei; setback at Red Cliffs; focused on governance in later years; died at 65',
    keyEventEn: 'Battle of Guandu (200 CE) against the odds — established northern hegemony; "old stallion in stable, ambitions soar a thousand li"',
    colorRuleEn: 'Vast grey-green land and iron-black battlefield — the surging blue of Guan Sea poem declares his boundless ambition',
  },
  '曹植': {
    earlyLife: '曹操第三子，才情卓绝，幼而聪颖，深受曹操喜爱，与曹丕争嗣，一度最受钟爱',
    midLife: '曹丕称帝后受尽猜忌，屡遭贬谪，"七步成诗"传说道出兄弟相煎之苦',
    lateLife: '辗转迁封十一次，名为王侯实为囚徒，41岁郁郁而终，临终"利剑不在掌，结友何须多"道尽悲凉',
    keyEvent: '"七步诗"（220年）是曹植遭迫害的文学象征——兄弟相煎的政治阴谋化为"本是同根生，相煎何太急"的千古警句',
    colorRule: '芙蓉之色、兰草之绿、霜雪之白等清冷高洁之色，寄托了他才华横溢却身陷囹圄的悲剧命运',
    earlyLifeEn: 'Third son of Cao Cao; brilliantly gifted and once his father\'s favorite over elder brother Cao Pi',
    midLifeEn: 'After Cao Pi\'s enthronement, suffered constant suspicion; the "Seven-Step Poem" legend captures fraternal persecution',
    lateLifeEn: 'Moved between eleven fiefdoms as a captive prince in all but name; died at 41, lamenting "the sword is not in my hand"',
    keyEventEn: 'The Seven-Step Poem (220 CE) — persecution crystallized into "why must kindred roots scorch each other?"',
    colorRuleEn: 'Lotus-pink, orchid-green and frost-white — pure cool colors embody a genius imprisoned by fraternal politics',
  },
  '晏殊': {
    earlyLife: '5岁能诗被称"神童"，14岁以"神童"身份应试，宋真宗钦赐进士，仕途顺遂',
    midLife: '累官至枢密使、参知政事，身处宋代政治核心，门下培育欧阳修、范仲淹等人才',
    lateLife: '晚年因支持庆历新政受到牵连被贬颍州，不久获赦，64岁卒，以雍容华贵的词风留名词史',
    keyEvent: '一生整体顺遂，仕途达至高位，"无可奈何花落去，似曾相识燕归来"的感怀更多源于对时光流逝的哲思，而非命运打击',
    colorRule: '金色、暖红等富贵温雅之色，与其官居显位、词风雍容的人生底色相互映照',
    earlyLifeEn: 'Prodigy who passed the imperial examination at 14 with the emperor\'s personal endorsement',
    midLifeEn: 'Rose to senior court positions; his household became a cultural salon nurturing Ouyang Xiu and Fan Zhongyan',
    lateLifeEn: 'Briefly demoted for association with the Qingli Reform; died at 64, celebrated for his graceful lyric style',
    keyEventEn: 'Remarkably smooth life overall — his melancholy arises from the passage of time, not adversity',
    colorRuleEn: 'Gold and warm-red noble hues — matching the dignified, opulent tone of a lifelong high official and cultural patron',
  },
  '陈子昂': {
    earlyLife: '少年豪侠，家富豪纵，入京后以"毁琴扬名"一事传为佳话，24岁进士，以复古革新著称',
    midLife: '两次随军出塞，军中所见激发了其《登幽州台歌》的千古之叹，"前不见古人，后不见来者"撼动天地',
    lateLife: '因父冤案被迫弃官回乡，后遭县令段简构陷下狱，41岁含冤而死，一代诗人开辟盛唐之音却命薄如纸',
    keyEvent: '登幽州台（696年）是陈子昂精神世界的顶峰与绝境——孤独立于历史时间轴上的苍凉感，凝结成中国诗歌史上最震撼的孤独宣言',
    colorRule: '苍天、黄地、风尘等粗犷苍凉之色，折射其复古理想与现实际遇的深刻矛盾',
    earlyLifeEn: 'A wealthy chivalrous youth who smashed a lute to attract literary attention; passed the exam at 24',
    midLifeEn: 'Joined two frontier campaigns; the northern desolation inspired "None before me, none behind me" — his eternal cry of isolation',
    lateLifeEn: 'Resigned from office over a family injustice; framed by a local official; died in prison at 41',
    keyEventEn: 'Climbing Youzhou Terrace (696 CE) — standing alone in history\'s flow, distilling China\'s most resonant expression of cosmic solitude',
    colorRuleEn: 'Vast sky, yellow earth and wind-dust hues — the raw bleak palette of a reformist poet between ideal and bitter reality',
  },
  '孟浩然': {
    earlyLife: '隐居鹿门山苦学，40岁前坚持隐居，以山水田园诗享誉关中，与王维并称"王孟"',
    midLife: '40岁入京应试落第，传说觐见唐玄宗时吟出"不才明主弃，多病故人疏"触怒皇帝，仕途彻底绝望',
    lateLife: '晚年归隐故里襄阳，以渔樵耕读度日，52岁因背疽复发而逝，清淡本色始终如一',
    keyEvent: '40岁落第与御前失言是孟浩然与仕途的永诀——"当路谁相假，知音世所稀"道出文人在政治夹缝中的无奈',
    colorRule: '绿荷、碧水、白云等清淡自然之色，与其隐逸人生哲学完全一致，是盛唐田园诗色彩美学的典范',
    earlyLifeEn: 'Lived as a hermit studying until 40; celebrated for pastoral verse alongside Wang Wei as "Wang-Meng"',
    midLifeEn: 'Failed the imperial exam at 40; allegedly angered the emperor with an ill-chosen verse at an imperial audience',
    lateLifeEn: 'Returned to his Xiangyang hometown for fishing and farming; died at 52 from a relapsed illness',
    keyEventEn: 'Exam failure and imperial gaffe at 40 permanently closed officialdom — "who helps those on the path? rare is a true confidant"',
    colorRuleEn: 'Green lotus, blue water and white cloud — pristine natural colors perfectly embodying his unworldly hermit philosophy',
  },
  '柳永': {
    earlyLife: '少年才情出众，流连市井勾栏，长词慢词开一代新风，然屡试不中，"奉旨填词"自嘲传世',
    midLife: '47岁终于进士及第，官至屯田员外郎，然终生郁郁不得大用，仕途蹉跎',
    lateLife: '晚年潦倒，传说死后无钱下葬，歌女们凑钱"群妓合葬"，每年清明祭奠"吊柳七"成民间风俗',
    keyEvent: '"奉旨填词柳三变"是柳永的自我解脱——被仁宗批语"且去填词"后，他将世俗之苦化为市井词章，开豪放慢词之先',
    colorRule: '烟柳色、晓月白、霜色等柔婉清冷之色，折射其漂泊游历、钟情风月却终生不得志的情感底色',
    earlyLifeEn: 'Brilliant but dissolute in youth; frequented entertainment quarters; pioneered the long-form ci but repeatedly failed the exam',
    midLifeEn: 'Finally passed the exam at 47; served as a minor official; artistic glory far exceeded his official career',
    lateLifeEn: 'Died impoverished; legend says courtesans pooled funds for his burial and mourned him every Qingming Festival',
    keyEventEn: '"Commanded to compose lyrics" — dismissed by the emperor, he turned rejection into liberation and founded a new lyric style',
    colorRuleEn: 'Willow-mist, dawn-pale and frost-white — soft melancholic hues befitting a wandering romantic denied official fulfillment',
  },
  '贺知章': {
    earlyLife: '36岁进士，文采风流，盛唐官至太子宾客，与李白一见如故，誉之为"谪仙人"',
    midLife: '任职长安近三十年，与张旭、包融等相交，"饮中八仙"之一，豪饮纵情诗酒',
    lateLife: '86岁上疏致仕，唐玄宗亲送出城，"少小离家老大回，乡音无改鬓毛衰"是其还乡之感，一生通达圆满',
    keyEvent: '与李白相识（742年）是贺知章生命中最大的文学缘分——第一眼便称李白为"谪仙人"，彼此惺惺相惜，传为盛唐文坛佳话',
    colorRule: '绿柳、碧玉、春色等明媚生机之色，折射其一生顺遂、晚年归乡的圆满人生底色',
    earlyLifeEn: 'Passed the exam at 36; served at court for decades; famously recognized Li Bai as "an immortal banished to earth"',
    midLifeEn: 'Spent nearly 30 years in Chang\'an; one of the "Eight Immortals of the Wine Cup"',
    lateLifeEn: 'Retired at 86 with imperial honors; returned to Zhejiang; "young I left, old I return — accent unchanged, hair grown thin"',
    keyEventEn: 'Meeting Li Bai (742 CE) — recognizing the young genius at first sight, a defining moment of High Tang literary legend',
    colorRuleEn: 'Jade-green willow and spring-fresh colors — bright vital hues matching his remarkably fortunate and fulfilled long life',
  },
  '岑参': {
    earlyLife: '出身没落贵族，20岁进士，入仕后两度出塞西北边疆，以边塞诗冠绝一时',
    midLife: '两次奔赴安西、北庭，历经高原风雪，塞外奇景激发出"忽如一夜春风来，千树万树梨花开"等千古名句',
    lateLife: '安史之乱后几经辗转，晚年客死成都，未能归故里，一代边塞诗宗以漂泊作终',
    keyEvent: '两度出塞（749年、754年）是岑参诗风的决定性塑造——塞外奇异壮丽的地理景观激发其色彩想象，边塞诗派由此达至高峰',
    colorRule: '雪白、火红、金黄等极端对比色，模拟西域极端气候与壮丽景观，体现边塞诗派特有的色彩张力',
    earlyLifeEn: 'Born into faded nobility; passed the exam at 20; served twice on the northwestern frontier as a military aide',
    midLifeEn: 'Two tours in Anxi and Beiting; alien grandeur inspired "suddenly as if a spring wind came — ten thousand trees of plum blossoms"',
    lateLifeEn: 'Wandered after the An Lushan Rebellion; died in Chengdu far from home — the frontier poet\'s life ending in displacement',
    keyEventEn: 'Two frontier tours (749, 754 CE) decisively shaped his style — extreme western landscapes unleashed unprecedented chromatic imagination',
    colorRuleEn: 'Snow-white, fire-red, gold — extreme contrasts mirroring the frontier climate, defining the frontier poetry school\'s chromatic power',
  },
  '郑燮': {
    earlyLife: '"扬州八怪"之首，44岁进士，诗书画并绝，尤以兰竹著称，"难得糊涂"是其人生哲学',
    midLife: '任山东潍县知县，因为灾民请赈得罪豪绅，被罢官，"衙斋卧听萧萧竹，疑是民间疾苦声"道尽心迹',
    lateLife: '罢官后卖画扬州，以艺术维生，晚号"板桥道人"，书法自成"六分半书"，留下大量兰竹画作',
    keyEvent: '为民请赈被罢官（1753年）是郑燮人生的道德坐标——"些小吾曹州县吏，一枝一叶总关情"是其民本思想最真实的践行',
    colorRule: '墨绿竹色、雨润兰色等淡雅清逸之色，体现其"咬定青山不放松"的气节与清廉自守的人格',
    earlyLifeEn: 'Leading eccentric of the Eight Eccentrics of Yangzhou; passed the exam at 44; renowned poet, calligrapher and bamboo painter',
    midLifeEn: 'As magistrate of Weifang, petitioned for famine relief against the wishes of local gentry; dismissed from office',
    lateLifeEn: 'Sold paintings in Yangzhou after dismissal; developed the distinctive "Six-and-a-Half Script" calligraphy style',
    keyEventEn: 'Dismissed for petitioning famine relief (1753) — "we county officials, however small — every branch, every leaf, concerns the people"',
    colorRuleEn: 'Ink-deep bamboo-green and rain-fresh orchid hues — reflecting integrity and uprightness in the bamboo\'s unbroken spirit',
  },
  '毛泽东': {
    earlyLife: '湖南农家子弟，师范毕业，五四时期投身革命，接受马克思主义，1921年参与创建中国共产党',
    midLife: '领导秋收起义，创建井冈山根据地，历经长征，抗日战争与解放战争，1949年建立中华人民共和国',
    lateLife: '执政期间始终坚持诗词创作，晚年留下《沁园春·雪》《七律·长征》等豪迈史诗，以革命豪情贯穿一生',
    keyEvent: '长征（1934-1936年）是毛泽东诗词创作的重要熔炉——"红军不怕远征难，万水千山只等闲"将革命精神化为磅礴诗句',
    colorRule: '红旗之红、雪山之白、黄土之赭等宏观历史色彩，映照其诗词中开阔的历史视野与革命豪情',
    earlyLifeEn: 'Peasant-born Hunanese; graduated from normal school; joined the May Fourth Movement; co-founded the CCP in 1921',
    midLifeEn: 'Led the Autumn Harvest Uprising, founded the Jinggang Mountain base, survived the Long March, and established the PRC in 1949',
    lateLifeEn: 'Continued writing poetry throughout; Snow and Long March Verse rank among China\'s greatest modern poems',
    keyEventEn: 'The Long March (1934-36) as poetic forge — "the Red Army fears not the trials of the Long March; ten thousand crags are nothing to us"',
    colorRuleEn: 'Red-flag crimson, snowfield-white and loess-yellow — grand historical colors reflecting his sweeping revolutionary vision in verse',
  },
  '骆宾王': {
    earlyLife: '七岁以《咏鹅》名世，少年以神童著称，历任道王府属、武功主簿等职，仕途几经沉浮',
    midLife: '两度入狱，一度因事被免职，后随徐敬业起兵讨武则天，写下《代李敬业传檄天下文》',
    lateLife: '徐敬业兵败后下落不明，或战死，或削发为僧，一代才子以神秘结局成历史之谜',
    keyEvent: '随徐敬业起兵（684年）与《讨武曌檄》是骆宾王的历史高光——传说武则天读后也不禁赞叹，惋惜未能网罗此才',
    colorRule: '黑白对比强烈，兼有金色战场之色，折射其高亢激昂的政治檄文风格与仕途坎坷的人生轨迹',
    earlyLifeEn: 'Famous at 7 for "Ode to the Goose"; child prodigy; served in various court posts despite repeated setbacks',
    midLifeEn: 'Twice imprisoned; joined Xu Jingye\'s rebellion against Empress Wu; wrote the thundering anti-Wu manifesto',
    lateLifeEn: 'Disappeared after the rebellion\'s defeat — died in battle or became a monk; his end remains one of Tang poetry\'s great mysteries',
    keyEventEn: 'The anti-Wu manifesto (684 CE) — so brilliant that Empress Wu reportedly lamented not having recruited him',
    colorRuleEn: 'Strong black-white contrasts and battle-gold — mirroring his thundering rhetorical style and turbulent defiant life arc',
  },
  '陆游': {
    earlyLife: '出身名门，幼受母教，13岁能诗，20岁与唐琬成婚，后被迫离异，"钗头凤"之恨伴其终身',
    midLife: '因坚持抗金被投闲置散，中年出蜀从军，"铁马冰河"的壮志始终无法实现',
    lateLife: '晚年居山阴，以诗自慰，写诗万余首，"僵卧孤村不自哀，尚思为国戍轮台"，85岁离世时仍念念收复失土',
    keyEvent: '与唐琬被迫离婚（1144年）是最深的私痛，南宋偏安是最大的家国之痛——两重悲剧塑造了他万首诗作的情感底色',
    colorRule: '铁黑、血红等沉重之色寄托收复失地的家国情怀，偶有梅花之白透露其高洁情操与不屈志节',
    earlyLifeEn: 'Born into nobility; married Tang Wan at 20; forced to divorce her — the grief defined his entire emotional life',
    midLifeEn: 'Repeatedly sidelined for his pro-war stance; served briefly in Sichuan; military dreams forever unfulfilled',
    lateLifeEn: 'In old age at Shanyin, wrote over 10,000 poems; "lying stiff in a lone village I do not grieve — I still think of guarding the frontier"',
    keyEventEn: 'Forced divorce (1144) and Southern Song\'s pacifism — two lifelong sorrows shaping 10,000 poems',
    colorRuleEn: 'Heavy iron-black and blood-red for homeland grief; plum-blossom white for unbending integrity amid endless frustration',
  },
  '杜牧': {
    earlyLife: '出身京兆杜氏名门，23岁进士，初入官场即以才华著称，与李商隐并称"小李杜"',
    midLife: '因朝中党争（牛李之争）受波及，多在地方任职，转徙各地，以诗酒自娱，留下大量咏史诗',
    lateLife: '晚年官至中书舍人，50岁病逝于长安，留下"烟笼寒水月笼沙，夜泊秦淮近酒家"等千古名句',
    keyEvent: '晚唐藩镇割据与牛李党争是杜牧仕途的囚笼——怀才不遇的苦闷转化为咏史诗中对兴亡的深刻反思',
    colorRule: '深红、苍绿的繁华与萧瑟对比鲜明，折射晚唐"商女不知亡国恨"的盛衰之叹',
    earlyLifeEn: 'From the prestigious Du clan; passed the exam at 23; paired with Li Shangyin as the "Little Li and Du"',
    midLifeEn: 'Caught in the Niu-Li factional struggle; spent most of his career in provincial posts, channeling frustration into brilliant historical verse',
    lateLifeEn: 'Rose to senior court scribe in his final years; died at 50 in Chang\'an, leaving immortal lines on Qinhuai nights and fallen dynasties',
    keyEventEn: 'Factional strife and warlordism — unfulfilled ambition transformed into penetrating meditations on historical rise and fall',
    colorRuleEn: 'Vivid contrast of deep-red splendor and faded green bleakness — the chromatic emblem of Tang\'s glorious decline',
  },
  '李商隐': {
    earlyLife: '少年即有文名，受令狐楚赏识提携，却因娶王茂元之女被令狐绹视为背叛，深陷牛李党争',
    midLife: '因政治站队问题终身仕途不顺，辗转在各方幕府任职，与妻王氏伉俪情深，妻子早逝令其心碎',
    lateLife: '晚年困顿，多次寄人篱下，46岁病逝，"春蚕到死丝方尽，蜡炬成灰泪始干"成为其情感与命运的永恒象征',
    keyEvent: '夹在牛李两党之间（838年婚后）——婚姻让他彻底失去令狐家族庇护，此后政治上永无出头之日，锦瑟无端转为悲音',
    colorRule: '紫、黛、烟色等神秘朦胧之色，与其隐晦深情的无题诗完美契合，以色彩营造谜一般的诗意境界',
    earlyLifeEn: 'Gained literary fame in youth; patronized by Linghu Chu but seen as traitor for marrying into the rival Wang clan',
    midLifeEn: 'Permanently trapped between two political factions; beloved wife died young, devastating him',
    lateLifeEn: 'Lived in poverty; died at 46; "the silkworm spins until death, the candle weeps until ash" immortalizes his devotion and sorrow',
    keyEventEn: 'Marriage into the rival clan (838 CE) — cost him his primary patron and sealed a lifetime of political marginalization',
    colorRuleEn: 'Mysterious purple, indigo and misty haze — perfectly matching his cryptic emotional Untitled poems\' enigmatic beauty',
  },
};

function inferColorFamily(hex: string): string {
  const h = hexToHue(hex);
  const s = hexToSat(hex);
  if (s < 15) return '中性';
  if (h >= 330 || h < 25)   return '红';
  if (h >= 25  && h < 60)   return '橙黄';
  if (h >= 60  && h < 80)   return '黄绿';
  if (h >= 80  && h < 165)  return '绿';
  if (h >= 165 && h < 260)  return '青蓝';
  if (h >= 260 && h < 330)  return '紫';
  return '中性';
}

// 诗人网络：生成深度结论（单人 / 多人）
// 诗人性格与时代背景档案（用于生成具体归因分析）
const POET_PROFILES: Record<string, {
  personality: string;
  era: string;
  colorTendency: string;
  personalityEn: string;
  eraEn: string;
  colorTendencyEn: string;
}> = {
  '李白': {
    personality: '性格豪迈飘逸、崇尚自由，追求仙道与浪漫主义',
    era: '盛唐鼎盛期，政治开明、经济繁荣、文化自信',
    colorTendency: '偏爱月白、翠色等清冷明亮之色，映照其飘然出世的诗仙气质',
    personalityEn: 'free-spirited and romantic, pursuing Daoist ideals',
    eraEn: 'High Tang prosperity with open politics and vibrant culture',
    colorTendencyEn: 'favoring cool, luminous hues like moon-white and jade-green',
  },
  '杜甫': {
    personality: '忧国忧民、沉郁顿挫，以诗记史的现实主义精神',
    era: '安史之乱前后，盛唐由盛转衰、百姓流离颠沛',
    colorTendency: '多用苍、暗、黑等沉郁之色，与其漂泊困苦的晚年境遇高度契合',
    personalityEn: 'deeply patriotic and socially conscious, with a somber realist spirit',
    eraEn: 'during the An Lushan Rebellion, witnessing Tang\'s decline and mass suffering',
    colorTendencyEn: 'drawn to dark, muted tones reflecting his turbulent exile years',
  },
  '苏轼': {
    personality: '旷达豪迈、随缘自适，屡经贬谪仍保持乐观旷达',
    era: '北宋党争激烈，仕途三起三落，乌台诗案后长期被贬',
    colorTendency: '色彩多元而兼具明暗，既有竹绿、碧翠的清旷，亦有苍黄的萧瑟，体现其跌宕人生',
    personalityEn: 'magnanimous and adaptable, maintaining optimism despite repeated exile',
    eraEn: 'Northern Song factional strife, imprisoned in the Crow Terrace Incident then repeatedly banished',
    colorTendencyEn: 'diverse palette spanning bright greens and muted ochres, mirroring his turbulent but resilient life',
  },
  '李清照': {
    personality: '才情婉约、细腻敏感，国破家亡后愁思深重',
    era: '北宋末至南宋初，靖康之变致国破家亡、颠沛流离',
    colorTendency: '早年多用明媚暖色，靖康之变后转向黄昏冷色，以色彩折射身世飘零之痛',
    personalityEn: 'graceful and deeply sensitive, increasingly melancholic after national catastrophe',
    eraEn: 'from late Northern Song through the Jingkang Catastrophe and Southern Song exile',
    colorTendencyEn: 'shifting from bright warm tones in youth to dusk-cold hues after losing home and country',
  },
  '王维': {
    personality: '禅心淡泊、以诗入画，崇尚山水田园的超然境界',
    era: '盛唐中期，晚年隐居辋川，以佛禅思想消解政治失意',
    colorTendency: '偏爱松绿、水碧、空翠等冷静淡远之色，折射禅宗色空观与山林隐逸之志',
    personalityEn: 'contemplative and Buddhist, renowned for painting-like imagery in verse',
    eraEn: 'mid-High Tang, retiring to Wangchuan estate after political setbacks',
    colorTendencyEn: 'cool, muted greens and water-blues reflecting Zen philosophy and hermit ideals',
  },
  '白居易': {
    personality: '平易近人、关怀民瘼，力主诗歌平实通俗',
    era: '中唐藩镇割据，多次遭贬，长期任地方官体察民情',
    colorTendency: '色彩朴素明朗，以红白为主，贴近日常生活与民间审美',
    personalityEn: 'accessible and socially concerned, championing plain and direct verse',
    eraEn: 'mid-Tang regional fragmentation, frequently demoted to provincial posts',
    colorTendencyEn: 'plain, bright colors — reds and whites — close to everyday life and folk aesthetics',
  },
  '辛弃疾': {
    personality: '壮志未酬、慷慨豪迈，一生渴望恢复中原却抱憾终身',
    era: '南宋偏安，主战派受压制，辛弃疾长期闲置不得重用',
    colorTendency: '好用金色、烈红等激昂之色彰显报国热忱，亦有苍茫暮色寄托壮志难酬之悲',
    personalityEn: 'passionate and patriotic warrior-poet, yearning to reclaim the north',
    eraEn: 'Southern Song retreat south, pacifist factions suppressed and Xin marginalized for decades',
    colorTendencyEn: 'bold golds and burning reds for patriotic fervor, shadowed by dusk-grey for unfulfilled ambition',
  },
  '陆游': {
    personality: '爱国情怀深厚、壮志难酬，晚年以诗自慰',
    era: '南宋主战主和之争，陆游屡遭排斥、壮志难伸',
    colorTendency: '多用铁黑、血红等沉重色调，寄托收复失地的家国情怀与终身遗憾',
    personalityEn: 'fiercely patriotic with unfulfilled ambitions, consoled by poetry in old age',
    eraEn: 'Southern Song war-peace factions, repeatedly sidelined from military endeavors',
    colorTendencyEn: 'heavy iron-black and blood-red conveying homeland grief and lifelong regret',
  },
  '杜牧': {
    personality: '才华横溢却怀才不遇，豪放与感伤并存',
    era: '晚唐藩镇与宦官专权，国势衰颓，才士难展抱负',
    colorTendency: '善用深红、苍绿等对比鲜明之色，以繁华与萧瑟的对比凸显晚唐盛衰之感',
    personalityEn: 'brilliant but frustrated, combining romantic boldness with melancholy',
    eraEn: 'late Tang decline amid eunuch dominance and regional warlords',
    colorTendencyEn: 'vivid contrasts of deep red and faded green evoking the glory-and-ruin mood of late Tang',
  },
  '李商隐': {
    personality: '情感细腻隐晦、朦胧深情，政治上两党夹缝中蹉跎一生',
    era: '晚唐牛李党争，李商隐因政治站队问题终身不得志',
    colorTendency: '偏爱紫、黛、烟色等神秘朦胧之色，以色彩营造深邃迷离的意境',
    personalityEn: 'emotionally intricate and politically trapped between two rival factions',
    eraEn: 'late Tang factional strife between the Niu and Li cliques, leaving him permanently marginalized',
    colorTendencyEn: 'mysterious purples, deep indigos and misty hues creating his signature obscure, sensuous atmosphere',
  },
  '陶渊明': {
    personality: '淡泊名利、崇尚自然，开创田园诗派',
    era: '东晋政治腐败，陶渊明主动归隐田园，远离仕途',
    colorTendency: '多用草绿、黄菊、白云等朴素自然之色，呈现归隐田园的恬淡生命哲学',
    personalityEn: 'unworldly and nature-loving, founder of pastoral poetry',
    eraEn: 'Eastern Jin political corruption, voluntarily retired to farm life',
    colorTendencyEn: 'plain greens, chrysanthemum-yellow and white cloud tones embodying pastoral simplicity',
  },
  '纳兰性德': {
    personality: '情深意重却多愁善感，对亡妻之思贯穿创作',
    era: '清朝康熙年间，虽身处权贵之家却难逃情感的苦楚',
    colorTendency: '多用雪白、霜色等清冷之色，寄托对逝去爱人的追念与人生如梦的感叹',
    personalityEn: 'deeply emotional and melancholic, defined by grief over his deceased wife',
    eraEn: 'Kangxi era Qing dynasty, privileged yet consumed by personal sorrow',
    colorTendencyEn: 'snow-white and frost-pale coolness enshrining his longing for lost love',
  },
  '温庭筠': {
    personality: '才高气傲、诗风浓艳，以词写闺情绮思',
    era: '晚唐宫廷文化繁盛，温庭筠开花间词派之先河',
    colorTendency: '善用胭脂、金色、绯红等华丽浓艳之色，营造奢靡精致的女性视角美学',
    personalityEn: 'flamboyant and arrogant, pioneering the ornate boudoir-verse style',
    eraEn: 'late Tang courtly culture, founding the Huajian school of ci poetry',
    colorTendencyEn: 'rich rouge, gold and crimson creating an opulent, feminized aesthetic',
  },
  '欧阳修': {
    personality: '豁达开朗、文风典雅，领导北宋诗文革新运动',
    era: '北宋仁宗庆历年间，政治相对开明，文坛欣欣向荣',
    colorTendency: '色彩雅正清新，多用翠绿、明黄，体现其典雅温润的文人气质',
    personalityEn: 'open-minded and elegant, leading the Northern Song literary reform',
    eraEn: 'Northern Song Renzong era, politically enlightened with flourishing literary culture',
    colorTendencyEn: 'refined and fresh — jade-green and warm yellow reflecting his cultured, genial temperament',
  },
  '秦观': {
    personality: '多情善感、命途多舛，苏门四学士之一屡遭贬谪',
    era: '北宋新旧党争，秦观因苏轼一党屡遭迫害',
    colorTendency: '多用黄昏、烟雨、月白等凄美哀婉之色，映照仕途坎坷与相思离别之苦',
    personalityEn: 'sentimental and ill-fated, one of the Four Scholars of Su Shi\'s circle',
    eraEn: 'Northern Song factional battles, persecuted as part of Su Shi\'s faction',
    colorTendencyEn: 'twilight dusk, misty rain and pale moonlight tones for parting grief and frustrated ambition',
  },
};

function buildNetworkConclusion(
  selected: Array<{ name: string; dynasty: string; count: number; colors: Array<{ name: string; hex: string }> }>,
  isChinese: boolean,
): string {
  if (selected.length === 0) return '';

  if (selected.length === 1) {
    const p = selected[0];
    const familyCount: Record<string, number> = {};
    for (const c of p.colors) {
      const f = inferColorFamily(c.hex);
      familyCount[f] = (familyCount[f] || 0) + 1;
    }
    const topFamilies = Object.entries(familyCount).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([f]) => f);
    const topColorNames = p.colors.slice(0, 4).map(c => c.name).join('、');
    const warmCount = Object.entries(familyCount).filter(([f]) => ['红','橙黄','黄绿'].includes(f)).reduce((s,[,v])=>s+v,0);
    const coolCount = Object.entries(familyCount).filter(([f]) => ['绿','青蓝','紫'].includes(f)).reduce((s,[,v])=>s+v,0);
    const temper = warmCount > coolCount * 1.5 ? '偏暖热' : coolCount > warmCount * 1.5 ? '偏冷峻' : '冷暖兼备';
    const profile = POET_PROFILES[p.name];

    if (isChinese) {
      const profileNote = profile
        ? `这与其${profile.personality}的性格特质密切相关——${profile.era}，${profile.colorTendency}。`
        : `这一色彩选择与其${p.dynasty}时代风貌及个人创作风格高度契合。`;
      return `${p.name}（${p.dynasty}）共用 ${p.count} 种色彩词，以${topColorNames}为代表。色调${temper}，主要集中在${topFamilies.join('与')}色系。${profileNote}`;
    } else {
      const profileNote = profile
        ? `This reflects ${p.name}'s ${profile.personalityEn}: ${profile.eraEn}, ${profile.colorTendencyEn}.`
        : `These choices align closely with the aesthetic climate of the ${p.dynasty} dynasty and ${p.name}'s personal style.`;
      return `${p.name} (${p.dynasty} dynasty) used ${p.count} color terms. Representative: ${topColorNames}. Tone leans ${coolCount > warmCount ? 'cool and austere' : warmCount > coolCount ? 'warm and vibrant' : 'balanced'}, primarily in ${topFamilies.join(' and ')} hues. ${profileNote}`;
    }
  }

  // 多人对比 — 逐诗人具体归因
  const poetSummaries = selected.map(p => {
    const familyCount: Record<string, number> = {};
    for (const c of p.colors) { const f = inferColorFamily(c.hex); familyCount[f] = (familyCount[f] || 0) + 1; }
    const topFam = Object.entries(familyCount).sort((a, b) => b[1] - a[1])[0]?.[0] || '中性';
    const warmCount = Object.entries(familyCount).filter(([f]) => ['红','橙黄','黄绿'].includes(f)).reduce((s,[,v])=>s+v,0);
    const coolCount = Object.entries(familyCount).filter(([f]) => ['绿','青蓝','紫'].includes(f)).reduce((s,[,v])=>s+v,0);
    const temper = warmCount > coolCount * 1.5 ? '暖色' : coolCount > warmCount * 1.5 ? '冷色' : '中性';
    const topColors = p.colors.slice(0, 3).map(c => c.name).join('、');
    const profile = POET_PROFILES[p.name];
    return { ...p, topFam, temper, topColors, profile, warmCount, coolCount };
  });

  // 查找共有色彩
  const colorSets = selected.map(p => new Set(p.colors.map(c => c.name)));
  const shared = [...colorSets[0]].filter(c => colorSets.every(s => s.has(c)));
  const sharedStr = shared.slice(0, 3).join('、');

  if (isChinese) {
    // 逐诗人具体分析
    const details = poetSummaries.map(s => {
      if (s.profile) {
        return `**${s.name}**（${s.dynasty}）${s.profile.personality}，处于${s.profile.era}，常用${s.topColors}等${s.temper}调，${s.profile.colorTendency}`;
      }
      return `**${s.name}**（${s.dynasty}）以${s.topColors}为主（${s.topFam}色系），共${s.count}种色彩`;
    }).join('；\n');

    const sharedNote = shared.length > 0
      ? `\n\n他们共同偏好「${sharedStr}」，体现出${selected.map(s=>s.dynasty).filter((v,i,a)=>a.indexOf(v)===i).join('与')}时代共有的审美传统。`
      : '';

    const divergePoets = poetSummaries.filter(s => s.temper === '冷色');
    const warmPoets = poetSummaries.filter(s => s.temper === '暖色');
    const tempoNote = divergePoets.length > 0 && warmPoets.length > 0
      ? `\n\n从色调对比看，${warmPoets.map(s=>s.name).join('、')}偏向暖明色系（多与顺遂岁月或豪迈性情相关），而${divergePoets.map(s=>s.name).join('、')}偏向冷暗色系（往往与困顿经历或沉郁风格相关）——印证了"诗人因人生境遇的高低而倾向明暗不同的色彩"这一规律。`
      : '';

    return `${details}。${sharedNote}${tempoNote}`;
  } else {
    const details = poetSummaries.map(s => {
      if (s.profile) {
        return `**${s.name}** (${s.dynasty}): ${s.profile.personalityEn}. ${s.profile.eraEn}. Key colors: ${s.topColors} — ${s.profile.colorTendencyEn}`;
      }
      return `**${s.name}** (${s.dynasty}): ${s.topColors} (${s.topFam}, ${s.count} colors)`;
    }).join('\n');

    const sharedNote = shared.length > 0
      ? `\nShared colors: "${sharedStr}" — a common cultural aesthetic across these dynasties.`
      : '';

    const divergePoets = poetSummaries.filter(s => s.temper === '冷色');
    const warmPoets = poetSummaries.filter(s => s.temper === '暖色');
    const tempoNote = divergePoets.length > 0 && warmPoets.length > 0
      ? `\n\nTonal contrast: ${warmPoets.map(s=>s.name).join(', ')} lean warm (linked to prosperity or bold temperament); ${divergePoets.map(s=>s.name).join(', ')} lean cool-dark (tied to hardship or somber styles) — confirming the pattern that a poet's life fortunes shape their chromatic palette.`
      : '';

    return `${details}${sharedNote}${tempoNote}`;
  }
}

// ===================== 诗人色彩关联 — 二分图布局，含筛选 =====================
function PoetColorNetwork() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  interface PoetEntry {
    name: string;
    dynasty: string;
    count: number;
    colors: Array<{ name: string; hex: string; id: string; poem?: string; dynasty?: string }>;
  }
  interface ColorEntry {
    name: string; hex: string; id: string; poetCount: number;
    poets: string[];
    samplePoem?: string; sampleDynasty?: string; samplePoet?: string;
  }

  const [allPoets, setAllPoets] = useState<PoetEntry[]>([]);
  const [allColors, setAllColors] = useState<ColorEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [dynastyFilter, setDynastyFilter] = useState(ALL_FILTER);
  const [colorFilter, setColorFilter] = useState('vizFamAll');
  const [hoveredPoet, setHoveredPoet] = useState<string | null>(null);
  const [hoveredColor, setHoveredColor] = useState<string | null>(null);
  // 诗人单独筛选
  const [selectedPoets, setSelectedPoets] = useState<Set<string>>(new Set());
  const [hideOthers, setHideOthers] = useState(false);
  const [tooltipInfo, setTooltipInfo] = useState<{
    type: 'poet' | 'color';
    x: number; y: number;
    data: PoetEntry | ColorEntry;
  } | null>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: rows } = await supabase
      .from('poems')
      .select('poet, dynasty, poem_title, color_sentence, colors:color_id(id, name, hex_value)')
      .not('poet', 'is', null);

    if (!rows) { setLoading(false); return; }

    const poetMap = new Map<string, {
      dynasty: string;
      colors: Map<string, { name: string; hex: string; id: string; poem?: string; dynasty?: string }>;
    }>();
    const colorMap = new Map<string, {
      hex: string; id: string; poets: Set<string>;
      samplePoem?: string; sampleDynasty?: string; samplePoet?: string;
    }>();

    // 「佚名」及匿名条目不纳入关联图
    const ANONYMOUS_SET = new Set(['佚名', '民间', '无名氏', '不详']);

    for (const row of rows) {
      const poet = row.poet as string;
      const dynasty = row.dynasty as string;
      const color = row.colors as unknown as { id: string; name: string; hex_value: string } | null;
      const sentence = row.color_sentence as string | null;
      const title = row.poem_title as string | null;
      // 跳过无名作者
      if (!poet || !color || ANONYMOUS_SET.has(poet)) continue;

      if (!poetMap.has(poet)) poetMap.set(poet, { dynasty, colors: new Map() });
      const pe = poetMap.get(poet)!;
      if (!pe.colors.has(color.name)) {
        pe.colors.set(color.name, { name: color.name, hex: color.hex_value, id: color.id, poem: sentence || title || '', dynasty });
      }

      if (!colorMap.has(color.name)) {
        colorMap.set(color.name, {
          hex: color.hex_value, id: color.id, poets: new Set(),
          samplePoem: sentence || undefined, sampleDynasty: dynasty, samplePoet: poet,
        });
      }
      colorMap.get(color.name)!.poets.add(poet);
    }

    const poets: PoetEntry[] = Array.from(poetMap.entries())
      .map(([name, { dynasty, colors }]) => ({
        name, dynasty, count: colors.size,
        colors: Array.from(colors.values()),
      }))
      .sort((a, b) => b.count - a.count)
      // 保留足量诗人用于各朝代筛选（最多60位）
      .slice(0, 60);

    const colors: ColorEntry[] = Array.from(colorMap.entries())
      .map(([name, { hex, id, poets: ps, samplePoem, sampleDynasty, samplePoet }]) => ({
        name, hex, id, poetCount: ps.size, poets: Array.from(ps),
        samplePoem, sampleDynasty, samplePoet,
      }))
      .sort((a, b) => b.poetCount - a.poetCount);

    setAllPoets(poets);
    setAllColors(colors);
    setLoading(false);
  };

  // 应用筛选：先按朝代过滤
  const dynastyPoets = allPoets
    .filter(p => dynastyFilter === ALL_FILTER || p.dynasty === dynastyFilter);

  /**
   * 「全部朝代」视图：仅展示色彩种类最多的前 10 位知名诗人（门槛高）
   * 「具体朝代」视图：降低门槛，展示该朝代前 25 位诗人
   */
  const poetDisplayLimit = dynastyFilter === ALL_FILTER ? 10 : 25;

  // 再按诗人单独筛选（hideOthers 模式下只保留选中的诗人）
  const filteredPoets = (hideOthers && selectedPoets.size > 0
    ? dynastyPoets.filter(p => selectedPoets.has(p.name))
    : dynastyPoets
  ).slice(0, poetDisplayLimit);

  const activePoetNames = new Set(filteredPoets.map(p => p.name));

  // 筛选色彩：只保留与当前诗人有关联，且符合色系筛选的
  const family = COLOR_FAMILY_DEFS.find(f => f.key === colorFilter) || COLOR_FAMILY_DEFS[0];
  const filteredColors = allColors
    .filter(c => {
      const isValidHex = /^#[0-9A-Fa-f]{6}$/.test(c.hex);
      const famMatch = isValidHex && family.test(c.hex);
      const poetMatch = c.poets.some(p => activePoetNames.has(p));
      return famMatch && poetMatch;
    })
    .slice(0, 20);

  const activeColorNames = new Set(filteredColors.map(c => c.name));

  // 连线数据：只在当前可见诗人与色彩之间
  const connections: Array<{ poet: string; color: string; hex: string }> = [];
  for (const poet of filteredPoets) {
    for (const c of poet.colors) {
      if (activeColorNames.has(c.name)) {
        connections.push({ poet: poet.name, color: c.name, hex: c.hex });
      }
    }
  }

  // SVG 尺寸与布局（二分图：诗人在左，色彩在右）
  const W = 720, H = Math.max(400, Math.max(filteredPoets.length, filteredColors.length) * 26 + 40);
  const LEFT_X = 160, RIGHT_X = 560;
  const POET_Y_START = 30, COLOR_Y_START = 30;
  const poetStep = filteredPoets.length > 1 ? (H - 60) / (filteredPoets.length - 1) : H / 2;
  const colorStep = filteredColors.length > 1 ? (H - 60) / (filteredColors.length - 1) : H / 2;

  const poetPos = filteredPoets.map((p, i) => ({
    ...p, x: LEFT_X, y: POET_Y_START + i * poetStep,
  }));
  const colorPos = filteredColors.map((c, i) => ({
    ...c, x: RIGHT_X, y: COLOR_Y_START + i * colorStep,
  }));

  const poetPosMap = new Map(poetPos.map(p => [p.name, p]));
  const colorPosMap = new Map(colorPos.map(c => [c.name, c]));

  const dynastyList = [ALL_FILTER, ...DYNASTY_ORDER.filter(d =>
    allPoets.some(p => p.dynasty === d))];

  // 切换朝代时重置诗人筛选
  const handleDynastyChange = useCallback((d: string) => {
    setDynastyFilter(d);
    setSelectedPoets(new Set());
    setHideOthers(false);
  }, []);

  const togglePoetSelect = useCallback((name: string) => {
    setSelectedPoets(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }, []);

  const handlePoetHover = useCallback((e: React.MouseEvent, poet: PoetEntry | null) => {
    if (!poet || !containerRef.current) { setHoveredPoet(null); setTooltipInfo(null); return; }
    const rect = containerRef.current.getBoundingClientRect();
    setHoveredPoet(poet.name);
    setTooltipInfo({ type: 'poet', x: e.clientX - rect.left, y: e.clientY - rect.top, data: poet });
  }, []);

  const handleColorHover = useCallback((e: React.MouseEvent, color: ColorEntry | null) => {
    if (!color || !containerRef.current) { setHoveredColor(null); setTooltipInfo(null); return; }
    const rect = containerRef.current.getBoundingClientRect();
    setHoveredColor(color.name);
    setTooltipInfo({ type: 'color', x: e.clientX - rect.left, y: e.clientY - rect.top, data: color });
  }, []);

  if (loading) return <Skeleton className="bg-muted w-full h-96 rounded-xl" />;

  return (
    <div className="card-rice-paper p-4 md:p-6">
      <h3 className="font-kai text-base font-semibold text-foreground mb-1">{t('vizNetworkTitle')}</h3>
      <p className="text-xs text-muted-foreground font-song mb-4">
        {t('vizNetworkDesc')}
      </p>

      {/* 筛选栏 */}
      <div className="space-y-2 mb-5">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-song text-muted-foreground shrink-0">{t('vizFilterDynasty')}</span>
          {dynastyList.map(d => (
            <button key={d} type="button"
              onClick={() => handleDynastyChange(d)}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-kai transition-all ${
                dynastyFilter === d
                  ? 'text-white'
                  : 'bg-muted/40 text-muted-foreground hover:text-foreground'
              }`}
              style={dynastyFilter === d
                ? { backgroundColor: d === ALL_FILTER ? 'hsl(var(--primary))' : (DYNASTY_COLORS[d] || 'hsl(var(--primary))') }
                : {}}
            >{d === ALL_FILTER ? t('all') : getDynastyLabel(d, t)}</button>
          ))}
        </div>

        {/* 诗人单独筛选（选定朝代后显示） */}
        {dynastyPoets.length > 0 && (
          <div className="bg-muted/20 rounded-lg p-2.5 border border-border/60">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-song text-muted-foreground">
                {t('vizFilterPoet')}（{dynastyFilter === ALL_FILTER
                  ? t('vizPoetFilterAll')
                  : `${getDynastyLabel(dynastyFilter, t)}，${t('vizPoetFilterCount').replace('{count}', String(dynastyPoets.slice(0, poetDisplayLimit).length))}`}）：
              </span>
              <label className="flex items-center gap-1.5 text-[10px] font-song text-muted-foreground cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={hideOthers}
                  onChange={e => setHideOthers(e.target.checked)}
                  className="w-3 h-3 accent-primary"
                  disabled={selectedPoets.size === 0}
                />
                {t('vizHideOthers')}
              </label>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {dynastyPoets.slice(0, poetDisplayLimit).map(p => {
                const isSelected = selectedPoets.has(p.name);
                return (
                  <button key={p.name} type="button"
                    onClick={() => togglePoetSelect(p.name)}
                    className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-kai transition-all border ${
                      isSelected
                        ? 'border-primary bg-primary/10 text-foreground font-semibold'
                        : 'border-border/40 text-muted-foreground hover:border-primary/40 hover:text-foreground'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: DYNASTY_COLORS[p.dynasty] || 'hsl(var(--primary))' }} />
                    {p.name}
                  </button>
                );
              })}
              {selectedPoets.size > 0 && (
                <button type="button"
                  onClick={() => { setSelectedPoets(new Set()); setHideOthers(false); }}
                  className="px-2 py-0.5 text-[10px] font-song text-muted-foreground hover:text-foreground border border-dashed border-border/60 rounded-full">
                  {t('vizClearSelect')}
                </button>
              )}
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-song text-muted-foreground shrink-0">{t('vizFilterColor')}</span>
          {COLOR_FAMILY_DEFS.map(f => (
            <button key={f.key} type="button"
              onClick={() => setColorFilter(f.key)}
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-kai transition-all ${
                colorFilter === f.key
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted/40 text-muted-foreground hover:text-foreground'
              }`}
            >{t(f.key as Parameters<typeof t>[0])}</button>
          ))}
        </div>
      </div>

      {/* 图表区域 */}
      <div ref={containerRef} className="relative overflow-x-auto">
        {filteredPoets.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground font-song text-sm">
            {t('vizNoData')}
          </div>
        ) : (
          <svg
            ref={svgRef}
            viewBox={`0 0 ${W} ${H}`}
            className="w-full"
            style={{ minWidth: 320, maxHeight: 600 }}
            onMouseLeave={() => { setHoveredPoet(null); setHoveredColor(null); setTooltipInfo(null); }}
          >
            {/* 列标题 */}
            <text x={LEFT_X} y={14} textAnchor="middle"
              fontSize="11" fill="hsl(var(--muted-foreground))" fontFamily="serif" fontWeight="600">
              {t('vizColPoet')}
            </text>
            <text x={RIGHT_X} y={14} textAnchor="middle"
              fontSize="11" fill="hsl(var(--muted-foreground))" fontFamily="serif" fontWeight="600">
              {t('vizColColor')}
            </text>

            {/* 连线层（最低层） */}
            {connections.map(({ poet, color, hex }) => {
              const pp = poetPosMap.get(poet);
              const cp = colorPosMap.get(color);
              if (!pp || !cp) return null;
              const isPoetHov = hoveredPoet === poet;
              const isColorHov = hoveredColor === color;
              const active = isPoetHov || isColorHov;
              const anyHov = hoveredPoet !== null || hoveredColor !== null;
              // 贝塞尔控制点
              const mx = (pp.x + cp.x) / 2;
              return (
                <path
                  key={`line-${poet}-${color}`}
                  d={`M${pp.x + 18},${pp.y} C${mx},${pp.y} ${mx},${cp.y} ${cp.x - 18},${cp.y}`}
                  fill="none"
                  stroke={active ? hex : hex}
                  strokeWidth={active ? 2 : 0.8}
                  opacity={anyHov ? (active ? 0.85 : 0.06) : 0.25}
                  className="transition-all duration-150"
                />
              );
            })}

            {/* 诗人节点（左列） */}
            {poetPos.map((p) => {
              const isHov = hoveredPoet === p.name;
              const isConnected = hoveredColor
                ? connections.some(c => c.poet === p.name && c.color === hoveredColor)
                : false;
              const anyHov = hoveredPoet !== null || hoveredColor !== null;
              const dim = anyHov && !isHov && !isConnected;
              const dynastyColor = DYNASTY_COLORS[p.dynasty] || 'hsl(var(--primary))';
              return (
                <g key={`poet-${p.name}`}
                  className="cursor-pointer"
                  onClick={() => navigate(`/poet/${encodeURIComponent(p.name)}`)}
                  onMouseEnter={(e) => handlePoetHover(e, p)}
                  onMouseLeave={() => { setHoveredPoet(null); setTooltipInfo(null); }}
                >
                  {/* 悬停高亮圈 */}
                  {isHov && (
                    <circle cx={p.x} cy={p.y} r={14}
                      fill={dynastyColor} opacity={0.15} />
                  )}
                  <circle cx={p.x} cy={p.y} r={10}
                    fill={dynastyColor}
                    opacity={dim ? 0.2 : (isHov ? 1 : 0.75)}
                    stroke={isHov ? 'hsl(var(--foreground))' : 'white'}
                    strokeWidth={isHov ? 1.5 : 1}
                    className="transition-all duration-150"
                  />
                  {/* 诗人名标签（节点左侧） */}
                  <text
                    x={p.x - 14} y={p.y + 4}
                    textAnchor="end"
                    fontSize="10"
                    fill="hsl(var(--foreground))"
                    fontFamily="serif"
                    fontWeight={isHov ? '700' : '400'}
                    opacity={dim ? 0.3 : 1}
                    className="pointer-events-none select-none transition-all duration-150"
                  >
                    {p.name.length > 5 ? p.name.slice(0, 5) + '…' : p.name}
                  </text>
                  {/* 色彩数量 */}
                  <text
                    x={p.x} y={p.y + 3.5}
                    textAnchor="middle"
                    fontSize="7"
                    fill="white"
                    fontFamily="serif"
                    opacity={dim ? 0.2 : 1}
                    className="pointer-events-none select-none"
                  >
                    {p.count}
                  </text>
                </g>
              );
            })}

            {/* 色彩节点（右列） */}
            {colorPos.map((c) => {
              const isHov = hoveredColor === c.name;
              const isConnected = hoveredPoet
                ? connections.some(conn => conn.color === c.name && conn.poet === hoveredPoet)
                : false;
              const anyHov = hoveredPoet !== null || hoveredColor !== null;
              const dim = anyHov && !isHov && !isConnected;
              const r = Math.max(7, Math.min(12, 7 + c.poetCount * 0.8));
              return (
                <g key={`color-${c.name}`}
                  className="cursor-pointer"
                  onClick={() => navigate(`/color/${c.id}`)}
                  onMouseEnter={(e) => handleColorHover(e, c)}
                  onMouseLeave={() => { setHoveredColor(null); setTooltipInfo(null); }}
                >
                  {isHov && (
                    <circle cx={c.x} cy={c.y} r={r + 5}
                      fill={c.hex} opacity={0.2} />
                  )}
                  <circle cx={c.x} cy={c.y} r={r}
                    fill={c.hex}
                    opacity={dim ? 0.2 : (isHov ? 1 : 0.85)}
                    stroke={isHov ? '#333' : 'white'}
                    strokeWidth={isHov ? 1.5 : 0.8}
                    className="transition-all duration-150"
                  />
                  {/* 色彩名标签（节点右侧） */}
                  <text
                    x={c.x + r + 5} y={c.y + 4}
                    textAnchor="start"
                    fontSize="10"
                    fill="hsl(var(--foreground))"
                    fontFamily="serif"
                    fontWeight={isHov ? '700' : '400'}
                    opacity={dim ? 0.3 : 1}
                    className="pointer-events-none select-none transition-all duration-150"
                  >
                    {getColorDisplayName(c.name, isChinese)}
                  </text>
                </g>
              );
            })}
          </svg>
        )}

        {/* 悬停 Tooltip */}
        {tooltipInfo && (() => {
          const contW = containerRef.current?.clientWidth || 720;
          const contH = containerRef.current?.clientHeight || 500;
          const tipW = 220, tipH = 140;
          const left = tooltipInfo.x + 16 + tipW > contW
            ? tooltipInfo.x - tipW - 8
            : tooltipInfo.x + 16;
          const top = tooltipInfo.y + tipH > contH
            ? tooltipInfo.y - tipH - 4
            : tooltipInfo.y + 8;

          if (tooltipInfo.type === 'poet') {
            const p = tooltipInfo.data as PoetEntry;
            return (
              <div className="absolute z-30 pointer-events-none"
                style={{ left, top }}>
                <div className="bg-background/97 border border-border rounded-lg shadow-lg p-3 w-52">
                  <p className="font-kai font-bold text-sm text-foreground mb-0.5">{p.name}</p>
                  <p className="text-[10px] text-muted-foreground font-song mb-2">
                    {getDynastyLabel(p.dynasty, t)} · {t('vizPoetColors').replace('{count}', String(p.count))}
                  </p>
                  <p className="text-[10px] text-muted-foreground font-song mb-1">{t('vizFavColors')}</p>
                  <div className="flex flex-wrap gap-1">
                    {p.colors.slice(0, 8).map(c => (
                      <span key={c.id} className="flex items-center gap-0.5 text-[10px] font-kai bg-muted/40 px-1 py-0.5 rounded">
                        <span className="w-2 h-2 rounded-full ring-1 ring-border inline-block shrink-0"
                          style={{ backgroundColor: c.hex }} />
                        {getColorDisplayName(c.name, isChinese)}
                      </span>
                    ))}
                    {p.colors.length > 8 && (
                      <span className="text-[9px] text-muted-foreground font-song self-center">
                        +{p.colors.length - 8}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          }

          const c = tooltipInfo.data as ColorEntry;
          return (
            <div className="absolute z-30 pointer-events-none"
              style={{ left, top }}>
              <div className="bg-background/97 border border-border rounded-lg shadow-lg p-3 w-52">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="w-5 h-5 rounded-full ring-1 ring-border shrink-0"
                    style={{ backgroundColor: c.hex }} />
                  <p className="font-kai font-bold text-sm text-foreground">{getColorDisplayName(c.name, isChinese)}</p>
                </div>
                <p className="text-[10px] text-muted-foreground font-song mb-2">
                  {t('vizPoetsUsed').replace('{count}', String(c.poetCount))}
                </p>
                {c.samplePoem && (
                  <div className="border-t border-border/40 pt-1.5">
                    <p className="text-[10px] text-foreground/75 font-kai italic line-clamp-2 leading-relaxed">
                      「{c.samplePoem}」
                    </p>
                    <p className="text-[9px] text-muted-foreground/60 font-song mt-0.5">
                      — {getDynastyLabel(c.sampleDynasty ?? '', t)} · {c.samplePoet}
                    </p>
                  </div>
                )}
                <div className="mt-2 flex flex-wrap gap-1">
                  {c.poets.slice(0, 6).map(name => (
                    <span key={name}
                      className="text-[9px] bg-muted/50 px-1.5 py-0.5 rounded font-kai text-muted-foreground">
                      {name}
                    </span>
                  ))}
                  {c.poets.length > 6 && (
                    <span className="text-[9px] text-muted-foreground/60 font-song self-center">
                      +{c.poets.length - 6}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* 图例 */}
      <div className="flex items-center gap-6 mt-3 text-[11px] text-muted-foreground font-song justify-center flex-wrap">
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-primary inline-block" />
          {t('vizLegendPoet')}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full inline-block" style={{ background: '#8B7355' }} />
          {t('vizLegendColor')}
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-5 border-t-2 border-dashed" style={{ borderColor: '#8B7355' }} />
          {t('vizLegendLine')}
        </span>
      </div>

      {/* 诗人网络——动态结论（数据驱动深度分析） */}
      {(() => {
        const selectedNames = Array.from(selectedPoets);
        const displayPoets = selectedNames.length > 0 ? filteredPoets.filter(p => selectedPoets.has(p.name)) : filteredPoets;
        const colorCount = new Set(displayPoets.flatMap(p => p.colors.map(c => c.name))).size;
        const topColors = displayPoets
          .flatMap(p => p.colors)
          .reduce((acc, c) => { acc[c.name] = (acc[c.name] || 0) + 1; return acc; }, {} as Record<string, number>);
        const sortedColors = Object.entries(topColors).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([n]) => n);

        // 使用 buildNetworkConclusion 生成深度结论
        const conclusionText = selectedNames.length > 0
          ? buildNetworkConclusion(
              filteredPoets.filter(p => selectedPoets.has(p.name)),
              isChinese,
            )
          : t('vizNetworkConclusionDefault' as Parameters<typeof t>[0]) as string;
        return (
          <div className="mt-5 p-4 rounded-lg bg-muted/25 border border-border/60">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60 shrink-0" />
              <span className="text-xs font-kai font-semibold text-foreground">
                {selectedNames.length > 0
                  ? (isChinese ? `已选诗人色彩分析` : 'Selected Poet Analysis')
                  : (isChinese ? '诗人色彩关联总体结论' : 'Overall Poet-Color Conclusion')}
              </span>
              {selectedNames.length > 0 && (
                <span className="text-[10px] text-muted-foreground font-song ml-1">
                  {isChinese ? `（${selectedNames.length}位诗人，共${colorCount}色）` : `(${selectedNames.length} poets, ${colorCount} colors)`}
                </span>
              )}
            </div>
            <p className="text-xs font-song text-muted-foreground leading-relaxed">{conclusionText}</p>
            {selectedNames.length > 0 && sortedColors.length > 0 && (
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className="text-[10px] text-muted-foreground font-song">{isChinese ? '高频色彩：' : 'Top colors: '}</span>
                {sortedColors.map(name => {
                  const c = allColors.find(ac => ac.name === name);
                  return c ? (
                    <span key={name} className="flex items-center gap-1 text-[10px] font-kai bg-background px-1.5 py-0.5 rounded border border-border/40">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: c.hex }} />
                      {getColorDisplayName(name, isChinese)}
                    </span>
                  ) : null;
                })}
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
}

// ===================== 朝代色彩流行度 =====================
function DynastyColorChart() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [allData, setAllData] = useState<DynastyTopData[]>([]);
  const [selectedDynasty, setSelectedDynasty] = useState<string>('唐');
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadDynastyData(); }, []);

  const loadDynastyData = async () => {
    const { data } = await supabase
      .from('poems')
      .select('dynasty, colors:color_id(id, name, hex_value)');

    if (!data) { setLoading(false); return; }

    const dynastyMap = new Map<string, Map<string, { count: number; hex: string; id: string }>>();

    for (const poem of data) {
      const dynasty = poem.dynasty as string;
      const color = poem.colors as unknown as { id: string; name: string; hex_value: string } | null;
      if (!dynasty || !color) continue;
      if (!dynastyMap.has(dynasty)) dynastyMap.set(dynasty, new Map());
      const colorMap = dynastyMap.get(dynasty)!;
      const cur = colorMap.get(color.name) || { count: 0, hex: color.hex_value, id: color.id };
      colorMap.set(color.name, { ...cur, count: cur.count + 1 });
    }

    const result: DynastyTopData[] = [];
    for (const [dynasty, colorMap] of dynastyMap) {
      const top = Array.from(colorMap.entries())
        .map(([name, { count, hex, id }]) => ({ name, count, hex, id }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);
      result.push({ dynasty, top });
    }

    setAllData(result.sort((a, b) => DYNASTY_ORDER.indexOf(a.dynasty) - DYNASTY_ORDER.indexOf(b.dynasty)));
    setLoading(false);
  };

  const currentData = allData.find(d => d.dynasty === selectedDynasty);
  const dynastyList = allData.map(d => d.dynasty);

  // 朝代专属结论
  const DYNASTY_CONCLUSIONS: Record<string, string> = {
    '先秦': '先秦诗歌以《诗经》和《楚辞》为代表，多用"绿"、"白"、"黑"等自然原色，色彩语言质朴而富有象征意味，奠定了中华诗词色彩美学的根基。',
    '汉': '汉代诗词以乐府为主，多用"红"、"绿"、"黄"等鲜明色彩，体现盛世气象与民间生命力，色彩表达直白而充满活力。',
    '魏晋': '魏晋时期玄学盛行，诗人崇尚自然，多用"青"、"白"、"素"等清淡之色，折射出名士风流与归隐田园的精神追求。',
    '南北朝': '南北朝诗风多样，南朝绮丽，多用"红"、"绿"浓艳之色；北朝苍劲，多见"苍"、"黄"朴实之色，两种风格并存，折射出特殊时代的文化张力。',
    '隋': '隋代诗歌短暂而华美，承接南朝绮丽传统，色彩词以"红"、"绿"为主，带有宫廷富丽色彩。',
    '唐': '唐代是中华诗词色彩最为丰富的巅峰时代。"红"象征盛世繁华，"白"与"青"彰显诗人的飘逸豪迈，"翠"与"碧"描绘大唐盛景。盛、中、晚唐的色彩偏好亦有显著差异，折射出王朝由兴到衰的历史脉络。',
    '五代': '五代诗词以花间词为代表，色彩浓艳，多见"红"、"翠"、"金"，带有脂粉气息，是宋词婉约风格的前奏。',
    '宋': '宋代理学影响下，诗词色彩整体转向清雅低调。"青"、"蓝"、"白"的使用增多，折射出文人对精神内省与清净意境的追求，与唐代的华彩形成鲜明对比。',
    '金': '金代诗词兼融汉文化与北方民族特色，色彩偏向"苍"、"黄"、"白"，展现出北方草原的壮阔与粗粝。',
    '元': '元代散曲与杂剧中，色彩鲜明而民俗气息浓厚，"红"、"绿"并用，带有鲜明的市井文化色彩，与文人雅趣形成有趣对照。',
    '明': '明代诗词承宋代清雅，又融入民俗浓彩，"红"与"绿"的对比运用频繁，折射出市民文化的兴起与审美的多元化。',
    '清': '清代诗词色彩细腻精致，纳兰性德偏爱"白"与"素"表达深情，龚自珍则以"红"抒发变革豪情。整体色彩风格呈现出由繁华向苍凉的转变，映照王朝的末世气象。',
    '近现代': '近现代诗词在传统色彩语言基础上融入时代精神，"红"象征革命热情，"白"与"苍"折射历史沧桑，色彩运用更具时代感与个人情感色彩。',
  };

  const dynastyConclusion = selectedDynasty && DYNASTY_CONCLUSIONS[selectedDynasty]
    ? DYNASTY_CONCLUSIONS[selectedDynasty]
    : t('vizDynastyConclusionDefault' as Parameters<typeof t>[0]);

  if (loading) return <Skeleton className="bg-muted w-full h-80 rounded-xl" />;

  return (
    <div className="card-rice-paper p-4 md:p-6">
      <h3 className="font-kai text-base font-semibold text-foreground mb-1">{t('vizDynastyTitle')}</h3>
      <p className="text-xs text-muted-foreground font-song mb-4">{t('vizDynastyDesc')}</p>

      <div className="flex flex-wrap gap-2 mb-6">
        {dynastyList.map(dynasty => (
          <button key={dynasty} type="button"
            onClick={() => setSelectedDynasty(dynasty)}
            className={`px-3 py-1 rounded-full text-xs font-kai transition-all ${
              selectedDynasty === dynasty
                ? 'text-primary-foreground'
                : 'bg-muted/50 text-muted-foreground hover:text-foreground'
            }`}
            style={selectedDynasty === dynasty
              ? { backgroundColor: DYNASTY_COLORS[dynasty] || 'hsl(var(--primary))' }
              : {}}
          >
            {getDynastyLabel(dynasty, t)}
          </button>
        ))}
      </div>

      {currentData && currentData.top.length > 0 ? (
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={currentData.top} layout="vertical"
            margin={{ top: 0, right: 30, left: 40, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
            <XAxis type="number" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
            <YAxis type="category" dataKey="name"
              tick={{ fontSize: 12, fill: 'hsl(var(--foreground))', fontFamily: 'serif' }}
              width={40} />
            <Tooltip
              formatter={(value) => [`${value} ${t('vizTimesUnit')}`, t('vizAppearCount')]}
              labelFormatter={(label) => `${t('vizColorLabel')}${label}`}
              contentStyle={{
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: 6, fontSize: 12, fontFamily: 'serif',
              }}
            />
            <Bar dataKey="count" radius={[0, 4, 4, 0]}
              onClick={(entry) => navigate(`/color/${entry.id}`)}>
              {currentData.top.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.hex} cursor="pointer" />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      ) : (
        <p className="text-muted-foreground font-song text-sm text-center py-10">{t('vizNoDataShort')}</p>
      )}

      {/* 朝代专属结论 */}
      <div className="mt-5 p-4 rounded-lg bg-muted/25 border border-border/60">
        <div className="flex items-center gap-2 mb-2">
          <span className="w-1.5 h-1.5 rounded-full shrink-0"
            style={{ backgroundColor: DYNASTY_COLORS[selectedDynasty] || 'hsl(var(--primary))' }} />
          <span className="text-xs font-kai font-semibold text-foreground">
            {getDynastyLabel(selectedDynasty, t)}{isChinese ? '代色彩小结' : ' Dynasty Analysis'}
          </span>
        </div>
        <p className="text-xs font-song text-muted-foreground leading-relaxed">{dynastyConclusion}</p>
      </div>
    </div>
  );
}

// ===================== 色彩与意象关联气泡图 =====================
function ColorImageryBubble() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [bubbles, setBubbles] = useState<Array<{
    tag: string;
    count: number;
    colors: Array<{ name: string; hex: string; id: string }>;
    dominantHex: string;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [hovered, setHovered] = useState<string | null>(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data } = await supabase
      .from('poems')
      .select('emotion_tags, colors:color_id(id, name, hex_value)')
      .not('emotion_tags', 'is', null);

    if (!data) { setLoading(false); return; }

    const tagMap = new Map<string, { count: number; colorSet: Map<string, { name: string; hex: string; id: string }> }>();

    for (const row of data) {
      const tags = row.emotion_tags as string[] | null;
      const color = row.colors as unknown as { id: string; name: string; hex_value: string } | null;
      if (!tags || !color) continue;
      for (const tag of tags) {
        if (!tag || tag === '其他') continue;
        if (!tagMap.has(tag)) tagMap.set(tag, { count: 0, colorSet: new Map() });
        const entry = tagMap.get(tag)!;
        entry.count++;
        entry.colorSet.set(color.name, { name: color.name, hex: color.hex_value, id: color.id });
      }
    }

    const result = Array.from(tagMap.entries())
      .filter(([, v]) => v.count >= 2)
      .map(([tag, { count, colorSet }]) => {
        const colors = Array.from(colorSet.values()).slice(0, 8);
        return { tag, count, colors, dominantHex: colors[0]?.hex || '#8B7355' };
      })
      .sort((a, b) => b.count - a.count);

    setBubbles(result);
    setLoading(false);
  };

  if (loading) return <Skeleton className="bg-muted w-full h-80 rounded-xl" />;

  if (bubbles.length === 0) {
    return (
      <div className="card-rice-paper p-6 text-center">
        <p className="text-muted-foreground font-song text-sm">{t('vizNoImageryData')}</p>
      </div>
    );
  }

  const W = 800, H = 500;
  const maxCount = Math.max(...bubbles.map(b => b.count));
  const minR = 24, maxR = 60;

  // 用改良的螺旋排布，避免重叠
  const positioned = bubbles.map((b, i) => {
    const r = minR + ((b.count / maxCount) * (maxR - minR));
    const angle = i * 2.3999;
    const dist = 50 + Math.pow(i, 0.7) * 32;
    const x = Math.max(r + 40, Math.min(W - r - 40, W / 2 + dist * Math.cos(angle)));
    const y = Math.max(r + 40, Math.min(H - r - 40, H / 2 + dist * Math.sin(angle) * 0.7));
    return { ...b, r, x, y };
  });

  const hovItem = hovered ? positioned.find(b => b.tag === hovered) : null;

  return (
    <div className="card-rice-paper p-4 md:p-6 relative">
      <h3 className="font-kai text-base font-semibold text-foreground mb-1">{t('vizImageryTitle')}</h3>
      <p className="text-sm text-muted-foreground font-song mb-6 leading-relaxed">
        {t('vizImageryDesc')}
      </p>

      <div className="relative overflow-x-auto overflow-y-visible pt-4 pb-12 px-6">
        <svg viewBox={`-20 -20 ${W + 40} ${H + 40}`} className="w-full" style={{ minWidth: 600, maxHeight: 600 }}
          onMouseLeave={() => setHovered(null)}>

          {/* 层1：悬停连接线（最底层） */}
          {hovItem && hovItem.colors.map((c, ci) => {
            const angle = (ci / hovItem.colors.length) * 2 * Math.PI - Math.PI / 2;
            const cx2 = hovItem.x + (hovItem.r + 52) * Math.cos(angle);
            const cy2 = hovItem.y + (hovItem.r + 52) * Math.sin(angle);
            return (
              <line key={`line-${ci}`}
                x1={hovItem.x} y1={hovItem.y}
                x2={cx2} y2={cy2}
                stroke={c.hex} strokeWidth="1.5" opacity="0.55" strokeDasharray="3 2"
                className="pointer-events-none"
              />
            );
          })}

          {/* 层2：主气泡（中间层，onMouseEnter 触发展开） */}
          {positioned.map((b) => {
            const isHov = hovered === b.tag;
            return (
              <g key={b.tag}
                className="cursor-pointer"
                onMouseEnter={() => setHovered(b.tag)}
                onClick={(e) => {
                  e.stopPropagation();
                  // 点击主气泡 → 跳转该意象主色彩详情页
                  if (b.colors[0]?.id) navigate(`/color/${b.colors[0].id}`);
                }}
              >
                {/* 外光晕 */}
                <circle cx={b.x} cy={b.y} r={b.r + 7}
                  fill={b.dominantHex} opacity={isHov ? 0.22 : 0.07} />
                <circle cx={b.x} cy={b.y} r={b.r}
                  fill={b.dominantHex}
                  opacity={isHov ? 0.92 : 0.68}
                  stroke={isHov ? 'hsl(var(--foreground))' : 'white'}
                  strokeWidth={isHov ? 1.8 : 0.8}
                  className="transition-all duration-200"
                />
                {/* 标签 */}
                <text x={b.x} y={b.r > 30 ? b.y - 3 : b.y + 4}
                  textAnchor="middle" fontSize={b.r > 30 ? '11' : '9'}
                  fill="white" fontFamily="serif" fontWeight="600"
                  className="pointer-events-none select-none"
                >
                  {getEmotionLabel(b.tag, t)}
                </text>
                {b.r > 28 && (
                  <text x={b.x} y={b.y + 13}
                    textAnchor="middle" fontSize="9"
                    fill="rgba(255,255,255,0.85)" fontFamily="serif"
                    className="pointer-events-none select-none"
                  >
                    {b.count}{t('vizPoemUnit')}
                  </text>
                )}
              </g>
            );
          })}

          {/* 层3：展开色彩圆点（最顶层，确保可点击，不被主气泡遮盖） */}
          {hovItem && hovItem.colors.map((c, ci) => {
            const angle = (ci / hovItem.colors.length) * 2 * Math.PI - Math.PI / 2;
            const cx2 = hovItem.x + (hovItem.r + 52) * Math.cos(angle);
            const cy2 = hovItem.y + (hovItem.r + 52) * Math.sin(angle);
            return (
              <g key={`dot-${ci}`}
                className="cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  // 点击关联色彩圆点 → 跳转对应色彩详情页
                  navigate(`/color/${c.id}`);
                }}
              >
                {/* 可点击命中区（透明扩大区域） */}
                <circle cx={cx2} cy={cy2} r={16} fill="transparent" />
                {/* 色彩圆 */}
                <circle cx={cx2} cy={cy2} r={10} fill={c.hex}
                  stroke="white" strokeWidth="1.8"
                  className="transition-transform duration-150 hover:scale-110"
                  style={{ transformOrigin: `${cx2}px ${cy2}px` }}
                />
                <text x={cx2} y={cy2 + 22}
                  textAnchor="middle" fontSize="8"
                  fill="hsl(var(--foreground))" fontFamily="serif"
                  fontWeight="500"
                  className="pointer-events-none select-none"
                >{getColorDisplayName(c.name, isChinese)}</text>
              </g>
            );
          })}
        </svg>
      </div>

      <p className="text-xs text-muted-foreground font-song mt-2 text-center">
        {t('vizImageryHint')}
      </p>
      {/* 意象结论 */}
      <div className="mt-4 p-4 rounded-lg bg-muted/25 border border-border/60">
        <div className="flex items-center gap-2 mb-2">
          <span className="w-1.5 h-1.5 rounded-full bg-primary/60 shrink-0" />
          <span className="text-xs font-kai font-semibold text-foreground">
            {lang === 'zh-CN' || lang === 'zh-TW' ? '意象与色彩关联小结' : 'Imagery–Color Analysis'}
          </span>
        </div>
        <p className="text-xs font-song text-muted-foreground leading-relaxed">
          {t('vizImageryConclusionDefault' as Parameters<typeof t>[0])}
        </p>
      </div>
    </div>
  );
}

// ===================== 诗人生命周期分析 =====================
function PoetLifeStageVisualization() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';

  // 阶段时序排序（DB 中仅存在 早年/中年/晚年 三档）
  const STAGE_ORDER = ['早年', '仕途得意', '中年', '仕途失意', '晚年/贬谪', '暮年'];
  const STAGE_LABEL_EN: Record<string, string> = {
    '早年': 'Early Years', '仕途得意': 'Official Peak', '中年': 'Middle Age',
    '仕途失意': 'Setbacks', '晚年/贬谪': 'Exile / Late', '暮年': 'Old Age',
  };

  // 计算诗人某阶段的境遇分值：优先读个性化表，其次按阶段通用默认值
  const DEFAULT_STAGE_BASE: Record<string, number> = {
    '早年': 65, '中年': 58, '晚年': 48, '仕途得意': 88, '仕途失意': 28, '晚年/贬谪': 35, '暮年': 50,
  };
  const getStageScore = (poet: string, stage: string): number =>
    POET_STAGE_SCORES[poet]?.[stage] ?? DEFAULT_STAGE_BASE[stage] ?? 55;

  interface PoetLifeData {
    poet: string;
    stages: Array<{
      stage: string;
      colors: Array<{ id: string; name: string; hex: string }>;
      score: number;
    }>;
  }

  const [allData, setAllData] = useState<PoetLifeData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPoet, setSelectedPoet] = useState<string>('');

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const { data: dbData } = await supabase
      .from('poems')
      .select('poet, life_stage, colors:color_id(id, name, hex_value)')
      .not('life_stage', 'is', null)
      .not('poet', 'is', null);

    if (!dbData) { setLoading(false); return; }

    const ANON = new Set([
      '佚名', '无名氏', '宫人', '民间',
      // 书籍/总集类——非个人诗人
      '《诗经》', '《古诗十九首》', '《汉乐府》', '《乐府诗集》',
      // 非诗人学者（史家/科学家/礼学家等）
      '刘昫', '宋应星', '戴圣', '贾思勰', '李时珍', '班固',
    ]);
    const poetMap = new Map<string, Map<string, Map<string, { id: string; name: string; hex: string }>>>();

    for (const row of dbData) {
      const poet = row.poet as string;
      const stage = row.life_stage as string;
      const color = row.colors as unknown as { id: string; name: string; hex_value: string } | null;
      if (!poet || !stage || !color || ANON.has(poet)) continue;

      if (!poetMap.has(poet)) poetMap.set(poet, new Map());
      const stagesMap = poetMap.get(poet)!;
      if (!stagesMap.has(stage)) stagesMap.set(stage, new Map());
      stagesMap.get(stage)!.set(color.id, { id: color.id, name: color.name, hex: color.hex_value });
    }

    const result: PoetLifeData[] = Array.from(poetMap.entries()).map(([poet, stagesMap]) => {
      const stages = Array.from(stagesMap.entries()).map(([stage, colorsMap]) => ({
        stage,
        colors: Array.from(colorsMap.values()),
        score: getStageScore(poet, stage),
      })).sort((a, b) => {
        const ia = STAGE_ORDER.indexOf(a.stage);
        const ib = STAGE_ORDER.indexOf(b.stage);
        return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
      });
      return { poet, stages };
    }).filter(p => p.stages.length >= 2)
      .sort((a, b) => b.stages.length - a.stages.length);

    setAllData(result);
    if (result.length > 0) setSelectedPoet(result[0].poet);
    setLoading(false);
  };

  // 搜索过滤
  const filteredPoets = searchQuery.trim()
    ? allData.filter(p => p.poet.includes(searchQuery.trim()))
    : allData;

  const currentPoetData = allData.find(p => p.poet === selectedPoet);

  if (loading) return <Skeleton className="h-[400px] w-full rounded-xl bg-muted" />;

  return (
    <div className="card-rice-paper p-4 md:p-6">
      <h3 className="font-kai text-base font-semibold text-foreground mb-1">
        {t('vizLifeTitle' as Parameters<typeof t>[0])}
      </h3>
      <p className="text-xs text-muted-foreground font-song mb-4">
        {t('vizLifeDesc' as Parameters<typeof t>[0])}
      </p>

      {/* 搜索 + 诗人选择 */}
      <div className="flex flex-col md:flex-row gap-3 mb-5">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('vizLifeSearch' as Parameters<typeof t>[0])}
            className="w-full pl-8 pr-3 py-1.5 text-xs font-song bg-muted/40 border border-border/60 rounded-lg focus:outline-none focus:border-primary/60 text-foreground placeholder:text-muted-foreground"
          />
          {searchQuery && (
            <button type="button" onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground text-xs">✕</button>
          )}
        </div>
        <div className="text-[11px] text-muted-foreground font-song self-center">
          {isChinese ? `共 ${filteredPoets.length} 位诗人` : `${filteredPoets.length} poets`}
        </div>
      </div>

      {/* 诗人标签列表 */}
      <div className="flex flex-wrap gap-1.5 mb-6 max-h-28 overflow-y-auto">
        {filteredPoets.length === 0 ? (
          <span className="text-xs text-muted-foreground font-song">
            {t('vizLifeNoResult' as Parameters<typeof t>[0])}
          </span>
        ) : filteredPoets.map(pd => (
          <button key={pd.poet} type="button"
            onClick={() => setSelectedPoet(pd.poet)}
            className={`px-2.5 py-0.5 rounded-full text-[11px] font-kai transition-all border ${
              selectedPoet === pd.poet
                ? 'bg-primary text-primary-foreground border-primary'
                : 'border-border/40 text-muted-foreground hover:border-primary/50 hover:text-foreground bg-muted/20'
            }`}
          >
            {pd.poet}
            <span className="ml-1 text-[9px] opacity-60">{pd.stages.length}</span>
          </button>
        ))}
      </div>

      {/* 当前诗人详情 */}
      {currentPoetData ? (
        <div className="space-y-6">
          <h4 className="font-kai text-lg font-bold text-foreground border-b border-border/40 pb-2">
            {currentPoetData.poet}
            <span className="ml-2 text-sm font-normal text-muted-foreground font-song">
              {isChinese ? `· ${currentPoetData.stages.length}个人生阶段` : `· ${currentPoetData.stages.length} life stages`}
            </span>
          </h4>

          {/* 人生起落曲线 */}
          <div>
            <p className="text-xs font-song text-muted-foreground mb-2">
              {t('vizLifeCurveTitle' as Parameters<typeof t>[0])} — {t('vizLifeCurveDesc' as Parameters<typeof t>[0])}
            </p>
            <div className="w-full min-w-0 overflow-hidden">
              <ResponsiveContainer width="100%" height={200}>
                <LineChart
                  data={currentPoetData.stages.map(s => ({
                    name: isChinese ? s.stage : (STAGE_LABEL_EN[s.stage] || s.stage),
                    score: s.score,
                    hex: s.colors[0]?.hex || '#8B7355',
                    stage: s.stage,
                  }))}
                  margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name"
                    tick={{ fontSize: 11, fill: 'hsl(var(--foreground))', fontFamily: 'serif' }}
                    interval={0}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <RechartsTooltip
                    formatter={(value: number) => [
                      `${value} / 100`,
                      isChinese ? '人生境遇指数' : 'Fortune Index',
                    ]}
                    contentStyle={{
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 6, fontSize: 11, fontFamily: 'serif',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    dot={(props) => {
                      const { cx, cy, payload } = props;
                      return (
                        <circle
                          key={`dot-${payload.stage}`}
                          cx={cx} cy={cy} r={7}
                          fill={payload.hex}
                          stroke="hsl(var(--background))"
                          strokeWidth={2}
                        />
                      );
                    }}
                    activeDot={{ r: 9, stroke: 'hsl(var(--primary))', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[10px] text-muted-foreground font-song text-center mt-1">
              {isChinese ? '曲线节点颜色 = 该阶段最常用色彩' : 'Dot color = most-used color in that stage'}
            </p>
          </div>

          {/* 各阶段色彩色板 */}
          <div className="space-y-4">
            {currentPoetData.stages.map((stageData) => (
              <div key={stageData.stage} className="flex items-start gap-4 p-3 rounded-lg bg-muted/20 border border-border/40">
                {/* 阶段标签 */}
                <div className="shrink-0 w-20 text-center">
                  <div
                    className="text-[11px] font-kai font-semibold px-2 py-1 rounded-full text-white"
                    style={{ backgroundColor: stageData.colors[0]?.hex || 'hsl(var(--primary))' }}
                  >
                    {stageData.stage}
                  </div>
                  <div className="text-[9px] text-muted-foreground font-song mt-1">
                    {isChinese ? `境遇指数 ${stageData.score}` : `Index ${stageData.score}`}
                  </div>
                </div>

                {/* 色彩圆点 */}
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-muted-foreground font-song mb-1.5">
                    {t('vizLifeColorPalette' as Parameters<typeof t>[0])}（{stageData.colors.length}种）
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {stageData.colors.map(c => (
                      <div
                        key={c.id}
                        className="group relative w-8 h-8 rounded-full cursor-pointer transition-transform hover:scale-125 ring-1 ring-border/40"
                        style={{ backgroundColor: c.hex }}
                        title={getColorDisplayName(c.name, isChinese)}
                        onClick={() => navigate(`/color/${c.id}`)}
                      >
                        <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[8px] font-kai text-muted-foreground opacity-0 group-hover:opacity-100 whitespace-nowrap pointer-events-none transition-opacity">
                          {getColorDisplayName(c.name, isChinese)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* 该诗人色彩结论——数据驱动深度分析 */}
          {(() => {
            const stages = currentPoetData.stages;
            const uniqueColors = new Set(stages.flatMap(s => s.colors.map(c => c.name)));

            // 每阶段主色系
            const stageFamilies = stages.map(s => {
              const fc: Record<string, number> = {};
              s.colors.forEach(c => { const f = inferColorFamily(c.hex); fc[f] = (fc[f] || 0) + 1; });
              const top = Object.entries(fc).sort((a, b) => b[1] - a[1]);
              return { stage: s.stage, score: s.score, topFamily: top[0]?.[0] || '中性', topColors: s.colors.slice(0, 3).map(c => c.name), colorCount: s.colors.length };
            });

            // 找最高/最低分阶段
            const maxStage = [...stages].sort((a, b) => b.score - a.score)[0];
            const minStage = [...stages].sort((a, b) => a.score - b.score)[0];
            const hasRange = maxStage && minStage && maxStage.stage !== minStage.stage;

            // 曲线走势：上升/下降/先降后升/先升后降
            const scores = stages.map(s => s.score);
            const trend = (() => {
              if (scores.length < 2) return 'flat';
              const first = scores[0], last = scores[scores.length - 1];
              const mid = scores[Math.floor(scores.length / 2)];
              if (scores.length >= 3) {
                if (mid > first && mid > last) return 'rise_fall';
                if (mid < first && mid < last) return 'fall_rise';
              }
              return last > first + 5 ? 'rise' : first > last + 5 ? 'fall' : 'flat';
            })();

            const trendLabel: Record<string, string> = {
              rise: '先抑后扬', fall: '由盛转衰', rise_fall: '先盛后衰', fall_rise: '历经低谷后重振', flat: '较为平稳',
            };
            const trendLabelEn: Record<string, string> = {
              rise: 'rising trajectory', fall: 'declining arc', rise_fall: 'peak then decline',
              fall_rise: 'adversity then resurgence', flat: 'relatively stable',
            };

            // 色调冷暖变化
            const warmFamilies = new Set(['红', '橙黄', '黄绿']);
            const firstStageWarm = stageFamilies[0] ? warmFamilies.has(stageFamilies[0].topFamily) : false;
            const lastStageWarm = stageFamilies[stageFamilies.length - 1] ? warmFamilies.has(stageFamilies[stageFamilies.length - 1].topFamily) : false;
            const colorShift = stageFamilies.length >= 2 && firstStageWarm !== lastStageWarm;
            const shiftDesc = colorShift
              ? (firstStageWarm ? '由早年的暖色调逐渐转向晚年的冷色调' : '由早年的冷色调在晚年渐现暖意')
              : '';
            const shiftDescEn = colorShift
              ? (firstStageWarm ? 'shifting from warm early tones to cooler later hues' : 'moving from cool early palette toward warmer late-life colors')
              : '';

            let conclusion = '';
            const lifeProfile = POET_LIFE_PROFILES[currentPoetData.poet];
            if (isChinese) {
              const stageDescs = stageFamilies.map(sf =>
                `${sf.stage}（境遇指数 ${sf.score}）以${sf.topColors.slice(0, 2).join('、')}为主色，偏${sf.topFamily}色系`
              ).join('；');
              // 基础阶段分析
              conclusion = `${currentPoetData.poet}人生轨迹${trendLabel[trend]}，共历经 ${stages.length} 个阶段、使用 ${uniqueColors.size} 种色彩词。${stageDescs}。`;
              // 最高/最低点具体色彩
              if (hasRange) conclusion += `人生最顺遂时（${maxStage.stage}，境遇指数 ${maxStage.score}）偏爱${maxStage.colors.slice(0, 2).map(c => c.name).join('、')}；处境最艰（${minStage.stage}，境遇指数 ${minStage.score}）则多见${minStage.colors.slice(0, 2).map(c => c.name).join('、')}。`;
              // 色温变化
              if (colorShift) conclusion += `${shiftDesc}，色彩温度的变迁与命运起伏高度吻合。`;
              // 具体历史事件叙述
              if (lifeProfile) {
                conclusion += `\n\n【生平详述】${currentPoetData.poet}${lifeProfile.earlyLife}；${lifeProfile.midLife}；${lifeProfile.lateLife}。${lifeProfile.keyEvent}。`;
                conclusion += `\n\n【规律总结】${lifeProfile.colorRule}。从这一规律可以认识到：诗人往往因人生境遇的高低而选择明暗度不同的色彩——得意时多用明亮暖色，困顿时转向冷暗色调，色彩不仅是审美偏好，更是内心世界与命运轨迹的真实投影。`;
              } else {
                conclusion += `\n\n【规律总结】从这一色彩序列可以看出，诗人往往因人生境遇的高低而选择明暗度不同的色彩——顺遂之年色调偏明偏暖，困顿之时则转向冷暗，色彩是心境与命运的直接镜像。`;
              }
            } else {
              const stageDescs = stageFamilies.map(sf =>
                `${sf.stage} (index ${sf.score}): ${sf.topColors.slice(0, 2).join(', ')} — ${sf.topFamily}`
              ).join('; ');
              conclusion = `${currentPoetData.poet}'s life follows a ${trendLabelEn[trend]}, spanning ${stages.length} stages with ${uniqueColors.size} distinct color terms. ${stageDescs}.`;
              if (hasRange) conclusion += ` At peak fortune (${maxStage.stage}, index ${maxStage.score}): ${maxStage.colors.slice(0, 2).map(c => c.name).join(', ')}; at lowest (${minStage.stage}, index ${minStage.score}): ${minStage.colors.slice(0, 2).map(c => c.name).join(', ')}.`;
              if (colorShift) conclusion += ` Color temperature ${shiftDescEn}, mirroring life's arc.`;
              if (lifeProfile) {
                conclusion += `\n\n[Biography] ${currentPoetData.poet}: ${lifeProfile.earlyLifeEn}. ${lifeProfile.midLifeEn}. ${lifeProfile.lateLifeEn}. Key turning point: ${lifeProfile.keyEventEn}.`;
                conclusion += `\n\n[Pattern] ${lifeProfile.colorRuleEn}. This reveals a broader principle: poets tend to gravitate toward bright, warm colors in times of prosperity and retreat toward dark, cool tones in hardship — color is not merely aesthetic preference but a faithful mirror of the soul and fate.`;
              } else {
                conclusion += `\n\n[Pattern] This color sequence reveals that poets tend to favor bright warm hues in prosperous years and shift to cool dark tones in hardship — color functions as a direct mirror of inner life and lived fortune.`;
              }
            }

            return (
              <div className="p-4 rounded-lg bg-muted/25 border border-border/60">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary/60 shrink-0" />
                  <span className="text-xs font-kai font-semibold text-foreground">
                    {isChinese ? '色彩人生小结' : 'Life-Color Summary'}
                  </span>
                </div>
                <p className="text-xs font-song text-muted-foreground leading-relaxed whitespace-pre-wrap">{conclusion}</p>
              </div>
            );
          })()}
        </div>
      ) : (
        <p className="text-center text-sm text-muted-foreground font-song py-10">
          {t('vizLifeNoResult' as Parameters<typeof t>[0])}
        </p>
      )}
    </div>
  );
}

// ===================== 主页面 =====================
export default function VisualizationPage() {
  const { t } = useLang();
  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground">{t('vizTitle')}</h1>
          <p className="text-sm text-muted-foreground font-song mt-1">
            {t('vizSubtitle')}
          </p>
        </div>

        <Tabs defaultValue="network">
          <TabsList className="bg-muted/40 mb-8 flex-wrap h-auto gap-1">
            <TabsTrigger value="network" className="font-song text-xs md:text-sm">{t('vizNetwork')}</TabsTrigger>
            <TabsTrigger value="dynasty" className="font-song text-xs md:text-sm">{t('vizDynasty')}</TabsTrigger>
            <TabsTrigger value="imagery" className="font-song text-xs md:text-sm">{t('vizImagery')}</TabsTrigger>
            <TabsTrigger value="lifestage" className="font-song text-xs md:text-sm">
              {t('vizLifeStage' as Parameters<typeof t>[0])}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="network">
            <PoetColorNetwork />
          </TabsContent>

          <TabsContent value="dynasty">
            <DynastyColorChart />
          </TabsContent>

          <TabsContent value="imagery">
            <ColorImageryBubble />
          </TabsContent>

          <TabsContent value="lifestage">
            <PoetLifeStageVisualization />
          </TabsContent>
        </Tabs>

        <div className="mt-8 p-4 md:p-6 rounded-lg bg-muted/20 border border-border">
          <h3 className="text-sm font-kai font-semibold text-foreground mb-2">深度结论分析</h3>
          <ul className="text-xs text-muted-foreground font-song leading-relaxed space-y-2 list-disc list-inside">
            <li><strong>色彩与时代氛围的映射：</strong>数据表明，唐代诗词多以高饱和度的“大红”、“明黄”等色彩表达盛世豪情；而宋代则转向低饱和度的“青蓝”、“茶白”，折射出理学影响下的内敛与清雅。</li>
            <li><strong>诗人生命周期的色彩流变：</strong>以苏轼为例，早年用色多“翠”、“碧”等鲜亮自然之色，中年仕途受挫后“灰”、“白”、“苍”等冷色调显著增加，晚年则趋向“墨”、“玄”等极简纯粹之色，体现了其心境从入世到出世的升华。</li>
            <li><strong>核心意象的色彩锚定：</strong>“梅花”与“雪”、“月”高度绑定“白”色系，而“离别”与“柳”则深度绑定“青绿”色系。这种固定搭配构成了中华古典诗词独特的审美基因与文化密码。</li>
          </ul>
        </div>
      </div>
    </MainLayout>
  );
}
