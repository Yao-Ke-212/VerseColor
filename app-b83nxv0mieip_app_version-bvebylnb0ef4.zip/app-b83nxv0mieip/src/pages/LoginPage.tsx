import { useState, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LangContext';
import type { TranslationKey } from '@/i18n';
import { Button } from '@/components/ui/button';
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { SiteLogo } from '@/components/SiteLogo';

const loginSchema = (t: (k: TranslationKey) => string) => z.object({
  username: z.string()
    .min(2, t('validUsernameMin'))
    .max(20, t('validUsernameMax'))
    .regex(/^[a-zA-Z0-9_]+$/, t('validUsernameChars')),
  password: z.string().min(6, t('validPasswordMin')),
});

const registerSchema = (t: (k: TranslationKey) => string) => z.object({
  username: z.string()
    .min(2, t('validUsernameMin'))
    .max(20, t('validUsernameMax'))
    .regex(/^[a-zA-Z0-9_]+$/, t('validUsernameRegChars')),
  password: z.string().min(6, t('validPasswordMin')),
  confirm: z.string(),
  agreement: z.boolean().refine(v => v, t('validAgreement')),
}).refine(d => d.password === d.confirm, {
  message: t('validPasswordMatch'),
  path: ['confirm'],
});

type LoginForm = z.infer<ReturnType<typeof loginSchema>>;
type RegisterForm = z.infer<ReturnType<typeof registerSchema>>;

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signInWithUsername, signUpWithUsername } = useAuth();
  const { t } = useLang();
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirmPwd, setShowConfirmPwd] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const from = (location.state as { from?: string })?.from || '/';

  // 根据当前语言动态生成 schema，确保验证错误信息随语言切换
  const resolvedLoginSchema = useMemo(() => loginSchema(t), [t]);
  const resolvedRegisterSchema = useMemo(() => registerSchema(t), [t]);

  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(resolvedLoginSchema),
    defaultValues: { username: '', password: '' },
  });

  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(resolvedRegisterSchema),
    defaultValues: { username: '', password: '', confirm: '', agreement: false },
  });

  const handleLogin = async (values: LoginForm) => {
    setSubmitting(true);
    const { error } = await signInWithUsername(values.username, values.password);
    setSubmitting(false);
    if (error) {
      toast.error(t('loginError'));
    } else {
      toast.success(t('loginSuccess'));
      navigate(from, { replace: true });
    }
  };

  const handleRegister = async (values: RegisterForm) => {
    setSubmitting(true);
    const { error } = await signUpWithUsername(values.username, values.password);
    setSubmitting(false);
    if (error) {
      toast.error(t('registerError'));
    } else {
      toast.success(t('loginSuccess'));
      navigate('/', { replace: true });
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* 左侧装饰区 - 仅桌面 */}
      <div className="hidden lg:flex flex-col justify-between w-80 xl:w-96 bg-muted/30 border-r border-border p-8 flex-shrink-0">
        <div>
          <Link to="/" className="block mb-12">
            <SiteLogo size={40} />
          </Link>
          <div className="space-y-4">
            <p className="font-kai text-xl text-foreground leading-relaxed">
              「山色空蒙雨亦奇」
            </p>
            <p className="text-sm text-muted-foreground font-song leading-relaxed">
              {t('siteDesc')}
            </p>
          </div>
        </div>
        {/* 色彩装饰条 */}
        <div className="flex gap-1 h-32">
          {['#3D4A5C', '#B5495B', '#62B5C9', '#F0EAD8', '#9E4F2C', '#C9A84C'].map((hex) => (
            <div key={hex} className="flex-1 rounded" style={{ backgroundColor: hex, opacity: 0.7 }} />
          ))}
        </div>
      </div>

      {/* 右侧登录区 */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-8">
        {/* 移动端 Logo */}
        <div className="lg:hidden mb-8 text-center">
          <Link to="/">
            <SiteLogo size={40} />
          </Link>
        </div>

        <div className="w-full max-w-sm">
          <Tabs defaultValue="login">
            <TabsList className="w-full mb-6 bg-muted/40">
              <TabsTrigger value="login" className="flex-1 font-song">{t('loginTitle')}</TabsTrigger>
              <TabsTrigger value="register" className="flex-1 font-song">{t('registerTitle')}</TabsTrigger>
            </TabsList>

            {/* 登录 */}
            <TabsContent value="login">
              <div className="mb-6">
                <h2 className="text-xl font-kai font-bold text-foreground">{t('guideWelcome')}</h2>
                <p className="text-sm text-muted-foreground font-song mt-1">{t('collectionLoginHint')}</p>
              </div>

              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-song">{t('username')}</FormLabel>
                        <FormControl>
                          <Input placeholder={t('usernamePlaceholder')} {...field} className="font-song" />
                        </FormControl>
                        <FormMessage className="font-song text-xs" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-song">{t('password')}</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPwd ? 'text' : 'password'}
                              placeholder={t('passwordPlaceholder')}
                              {...field}
                              className="font-song pr-10"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPwd(!showPwd)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="font-song text-xs" />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full font-song" disabled={submitting}>
                    {submitting ? t('loading') : t('loginBtn')}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            {/* 注册 */}
            <TabsContent value="register">
              <div className="mb-6">
                <h2 className="text-xl font-kai font-bold text-foreground">{t('registerTitle')}</h2>
                <p className="text-sm text-muted-foreground font-song mt-1">{t('myCollectionDesc')}</p>
              </div>

              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-song">{t('username')}</FormLabel>
                        <FormControl>
                          <Input placeholder={t('usernamePlaceholder')} {...field} className="font-song" />
                        </FormControl>
                        <FormMessage className="font-song text-xs" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-song">{t('password')}</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPwd ? 'text' : 'password'}
                              placeholder={t('passwordPlaceholder')}
                              {...field}
                              className="font-song pr-10"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPwd(!showPwd)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="font-song text-xs" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="confirm"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-song">{t('password')} ({t('confirm')})</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showConfirmPwd ? 'text' : 'password'}
                              placeholder={t('passwordPlaceholder')}
                              {...field}
                              className="font-song pr-10"
                            />
                            <button
                              type="button"
                              onClick={() => setShowConfirmPwd(!showConfirmPwd)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            >
                              {showConfirmPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="font-song text-xs" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registerForm.control}
                    name="agreement"
                    render={({ field }) => (
                      <FormItem className="flex items-start gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-0.5">
                          <p className="text-xs text-muted-foreground font-song leading-relaxed">
                            {t('agreePrefix')}
                            <span className="text-primary underline cursor-pointer mx-1">{t('termsLink')}</span>
                            {t('agreeAnd')}
                            <span className="text-primary underline cursor-pointer mx-1">{t('privacyLink')}</span>
                          </p>
                          <FormMessage className="font-song text-xs" />
                        </div>
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full font-song" disabled={submitting}>
                    {submitting ? t('loading') : t('registerBtn')}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>

          <div className="mt-6 text-center">
            <Link to="/" className="text-xs text-muted-foreground hover:text-foreground font-song transition-colors">
              ← {t('backHome')}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
