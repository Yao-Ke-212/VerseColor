import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LangContext';
import { MainLayout } from '@/components/layouts/MainLayout';
import { ColorCard } from '@/components/ColorCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';
import { Heart, BookOpen, Trash2, GitCompare, Palette, Copy, Check, X } from 'lucide-react';
import { getDynastyLabel, getColorDisplayName } from '@/lib/dataLabels';
import type { FavoriteWithDetail } from '@/types/types';

// ─────────────── 色彩比对组件 ───────────────
interface ColorCompareItem {
  id: string;
  name: string;
  hex: string;
  r: number;
  g: number;
  b: number;
}

function ColorCompare({ colorFavorites }: { colorFavorites: FavoriteWithDetail[] }) {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const isChinese = lang === 'zh-CN' || lang === 'zh-TW';
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const availableColors: ColorCompareItem[] = colorFavorites
    .filter(f => f.colors)
    .map(f => ({
      id: f.colors!.id,
      name: f.colors!.name,
      hex: f.colors!.hex_value,
      r: f.colors!.rgb_r,
      g: f.colors!.rgb_g,
      b: f.colors!.rgb_b,
    }));

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectedColors = availableColors.filter(c => selected.has(c.id));

  if (colorFavorites.length === 0) {
    return (
      <div className="text-center py-12">
        <GitCompare className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
        <p className="text-muted-foreground font-song text-sm">{t('compareNoFavs')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 选色区 */}
      <div>
        <p className="text-sm font-song text-muted-foreground mb-3">
          {t('compareSelectHint')}
        </p>
        <div className="flex flex-wrap gap-2">
          {availableColors.map(c => (
            <button
              key={c.id}
              type="button"
              onClick={() => toggleSelect(c.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-sm font-kai transition-all ${
                selected.has(c.id)
                  ? 'border-primary bg-primary/10 text-foreground'
                  : 'border-border text-muted-foreground hover:border-primary/50'
              }`}
            >
              <span className="w-3 h-3 rounded-full ring-1 ring-border shrink-0"
                style={{ backgroundColor: c.hex }} />
              {getColorDisplayName(c.name, isChinese)}
              {selected.has(c.id) && <Check className="w-3 h-3 text-primary" />}
            </button>
          ))}
        </div>
        {selected.size > 0 && (
          <button type="button" onClick={() => setSelected(new Set())}
            className="mt-2 text-xs text-muted-foreground font-song flex items-center gap-1 hover:text-foreground">
            <X className="w-3 h-3" /> {t('vizClearSelect')}
          </button>
        )}
      </div>

      {/* 比对展示 */}
      {selectedColors.length >= 2 ? (
        <div>
          <p className="text-xs text-muted-foreground font-song mb-3">
            {t('compareSelected').replace('{count}', String(selectedColors.length))}
          </p>
          <div className="flex gap-3 flex-wrap">
            {selectedColors.map(c => (
              <div key={c.id}
                className="flex-1 min-w-[120px] max-w-[180px] card-rice-paper overflow-hidden cursor-pointer hover:border-primary/50 hover:shadow-md transition-all"
                onClick={() => navigate(`/color/${c.id}`)}
                title={t('viewDetail')}
              >
                {/* 色块 */}
                <div className="w-full aspect-square relative group" style={{ backgroundColor: c.hex }}>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                    <span className="text-white text-[10px] font-song">{t('viewDetail')}</span>
                  </div>
                </div>
                {/* 信息 */}
                <div className="p-3 space-y-1.5">
                  <p className="font-kai font-semibold text-sm text-foreground">{getColorDisplayName(c.name, isChinese)}</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-muted-foreground font-song">HEX</span>
                      <code className="text-[11px] font-mono text-foreground">{c.hex.toUpperCase()}</code>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-muted-foreground font-song">RGB</span>
                      <code className="text-[11px] font-mono text-foreground">{c.r},{c.g},{c.b}</code>
                    </div>
                  </div>
                  {/* RGB 色条 */}
                  <div className="space-y-0.5 mt-2">
                    {[['R', c.r, '#ef4444'], ['G', c.g, '#22c55e'], ['B', c.b, '#3b82f6']].map(([label, val, color]) => (
                      <div key={label as string} className="flex items-center gap-1.5">
                        <span className="text-[9px] font-mono text-muted-foreground w-3">{label}</span>
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div className="h-full rounded-full"
                            style={{ width: `${((val as number) / 255) * 100}%`, backgroundColor: color as string }} />
                        </div>
                        <span className="text-[9px] font-mono text-muted-foreground w-6 text-right">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* 组合预览 */}
          <div className="mt-4">
            <p className="text-xs text-muted-foreground font-song mb-2">{t('comparePalettePreview')}</p>
            <div className="flex h-12 rounded-lg overflow-hidden border border-border shadow-sm">
              {selectedColors.map(c => (
                <div key={c.id} className="flex-1" style={{ backgroundColor: c.hex }}
                  title={c.name} />
              ))}
            </div>
          </div>
        </div>
      ) : selected.size === 1 ? (
        <p className="text-xs text-muted-foreground font-song text-center py-4">{t('compareNeedMore')}</p>
      ) : null}
    </div>
  );
}

// ─────────────── 自由调色组件 ───────────────
function ColorMixer() {
  const { t } = useLang();
  const [r, setR] = useState(140);
  const [g, setG] = useState(90);
  const [b, setB] = useState(80);
  const [copied, setCopied] = useState(false);

  const toHex = useCallback((n: number) => n.toString(16).padStart(2, '0').toUpperCase(), []);
  const hex = `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  const rgb = `rgb(${r}, ${g}, ${b})`;

  // RGB→HSL
  const toHsl = (rr: number, gg: number, bb: number) => {
    const rn = rr / 255, gn = gg / 255, bn = bb / 255;
    const max = Math.max(rn, gn, bn), min = Math.min(rn, gn, bn);
    const l = (max + min) / 2;
    if (max === min) return `hsl(0, 0%, ${Math.round(l * 100)}%)`;
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h = 0;
    if (max === rn) h = ((gn - bn) / d + (gn < bn ? 6 : 0)) / 6;
    else if (max === gn) h = ((bn - rn) / d + 2) / 6;
    else h = ((rn - gn) / d + 4) / 6;
    return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
  };
  const hsl = toHsl(r, g, b);

  const copyValue = (val: string) => {
    navigator.clipboard.writeText(val);
    setCopied(true);
    toast.success(`${t('copyBtn')} ${val}`);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* 左：调色区 */}
        <div className="space-y-5">
          <h4 className="font-kai text-sm font-semibold text-foreground mb-1">{t('mixerAdjustRgb')}</h4>
          {[
            { label: t('mixerRed'),   val: r, set: setR, color: '#ef4444' },
            { label: t('mixerGreen'), val: g, set: setG, color: '#22c55e' },
            { label: t('mixerBlue'),  val: b, set: setB, color: '#3b82f6' },
          ].map(({ label, val, set, color }) => (
            <div key={label} className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-foreground">{label}</span>
                <span className="text-xs font-mono text-muted-foreground tabular-nums">{val}</span>
              </div>
              <div className="relative">
                <div className="h-2.5 rounded-full overflow-hidden mb-1.5"
                  style={{
                    background: `linear-gradient(to right, ${
                      label.startsWith('R') ? '#000' : `rgb(${r},${g},${b})`
                    }, ${color})`
                  }} />
                <Slider
                  min={0} max={255} step={1}
                  value={[val]}
                  onValueChange={([v]) => set(v)}
                  className="w-full"
                />
              </div>
            </div>
          ))}
        </div>

        {/* 右：预览与色值 */}
        <div className="space-y-4">
          {/* 大色块预览 */}
          <div className="w-full aspect-square rounded-xl border border-border shadow-ink transition-colors duration-150"
            style={{ backgroundColor: hex }} />
          {/* 色值展示 */}
          <div className="space-y-2">
            {[
              { label: 'HEX', value: hex },
              { label: 'RGB', value: rgb },
              { label: 'HSL', value: hsl },
            ].map(({ label, value }) => (
              <div key={label}
                className="flex items-center justify-between p-2.5 rounded-lg bg-muted/40 border border-border">
                <span className="text-xs text-muted-foreground font-song w-10">{label}</span>
                <code className="text-xs font-mono text-foreground flex-1 text-center">{value}</code>
                <button type="button" onClick={() => copyValue(value)}
                  className="p-1 rounded hover:bg-muted transition-colors">
                  {copied ? <Check className="w-3 h-3 text-primary" /> : <Copy className="w-3 h-3 text-muted-foreground hover:text-foreground" />}
                </button>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground font-song text-center">
            {t('mixerCopyHint')}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─────────────── 主页面 ───────────────
export default function MyCollectionPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLang();
  const [favorites, setFavorites] = useState<FavoriteWithDetail[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadFavorites();
  }, [user]);

  const loadFavorites = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('favorites')
      .select(`
        *,
        colors:color_id(id, name, hex_value, color_family, rgb_r, rgb_g, rgb_b, emotion_tags, sort_order, created_at, ancient_source, dye_craft, modern_evidence, cultural_interpretation, historical_story),
        poems:poem_id(id, color_id, poem_title, full_text, color_sentence, poet, dynasty, created_at, annotation, color_meaning, creation_background, emotion_tags)
      `)
      .eq('user_id', user!.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setFavorites(Array.isArray(data) ? data : []);
    }
    setLoading(false);
  };

  const removeFavorite = async (id: string) => {
    const { error } = await supabase.from('favorites').delete().eq('id', id);
    if (!error) {
      setFavorites(prev => prev.filter(f => f.id !== id));
      toast.success(t('removeBtn'));
    }
  };

  const colorFavorites = favorites.filter(f => f.favorite_type === 'color' && f.colors);
  const poemFavorites = favorites.filter(f => f.favorite_type === 'poem' && f.poems);

  if (!user) {
    return (
      <MainLayout>
        <div className="max-w-5xl mx-auto px-4 md:px-8 py-16 text-center">
          <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-xl font-kai font-bold text-foreground mb-2">{t('myCollectionTitle')}</h2>
          <p className="text-muted-foreground font-song text-sm mb-6">{t('collectionLoginHint')}</p>
          <Button onClick={() => navigate('/login')} className="font-song">{t('navLogin')}</Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Heart className="w-5 h-5 text-zheshi" />
            <h1 className="text-2xl md:text-3xl font-kai font-bold text-foreground">{t('myCollectionTitle')}</h1>
          </div>
          <p className="text-sm text-muted-foreground font-song">
            {t('collectionCount')} <span className="font-semibold text-foreground">{favorites.length}</span> {t('collectionCountUnit')}
          </p>
        </div>

        <Tabs defaultValue="colors">
          <TabsList className="bg-muted/40 mb-6 flex-wrap h-auto gap-1">
            <TabsTrigger value="colors" className="font-song gap-2">
              <BookOpen className="w-4 h-4" />
              {t('colorFamily')} ({colorFavorites.length})
            </TabsTrigger>
            <TabsTrigger value="poems" className="font-song gap-2">
              <Heart className="w-4 h-4" />
              {t('poemDetail')} ({poemFavorites.length})
            </TabsTrigger>
            <TabsTrigger value="compare" className="font-song gap-2">
              <GitCompare className="w-4 h-4" />
              {t('colorCompare')}
            </TabsTrigger>
            <TabsTrigger value="mixer" className="font-song gap-2">
              <Palette className="w-4 h-4" />
              {t('colorMixer')}
            </TabsTrigger>
          </TabsList>

          {/* 收藏的色彩 */}
          <TabsContent value="colors">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="flex flex-col rounded-lg overflow-hidden border border-border">
                    <Skeleton className="bg-muted h-40" />
                    <div className="p-4 space-y-2">
                      <Skeleton className="bg-muted h-4 w-16" />
                      <Skeleton className="bg-muted h-3 w-24" />
                    </div>
                  </div>
                ))}
              </div>
            ) : colorFavorites.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground font-song text-sm">{t('myCollectionEmpty')}</p>
                <Button variant="outline" onClick={() => navigate('/search')} className="mt-4 font-song">
                  {t('navSearch')}
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {colorFavorites.map((fav) => fav.colors && (
                  <div key={fav.id} className="relative group">
                    <ColorCard color={fav.colors} />
                    <button
                      type="button"
                      onClick={() => removeFavorite(fav.id)}
                      className="absolute top-2 left-2 p-1.5 rounded-full bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-destructive/10"
                    >
                      <Trash2 className="w-3 h-3 text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 收藏的诗词 */}
          <TabsContent value="poems">
            {loading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="bg-muted h-32 rounded-xl" />
                ))}
              </div>
            ) : poemFavorites.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground font-song text-sm">{t('myCollectionEmpty')}</p>
              </div>
            ) : (
              <div className="space-y-4">
                {poemFavorites.map((fav) => fav.poems && (
                  <div key={fav.id} className="card-rice-paper p-5 group relative">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div>
                        <h3 className="font-kai text-base font-semibold text-foreground">
                          《{fav.poems.poem_title}》
                        </h3>
                        <p className="text-xs text-muted-foreground font-song mt-0.5">
                          {getDynastyLabel(fav.poems.dynasty, t)} · {fav.poems.poet}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFavorite(fav.id)}
                        className="p-1.5 rounded hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                    <p className="poem-quote text-sm font-kai text-foreground/80 mb-2">
                      {fav.poems.color_sentence}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`/color/${fav.poems!.color_id}`)}
                      className="text-xs text-muted-foreground font-song h-auto p-0 hover:text-foreground"
                    >
                      {t('viewDetail')} →
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 色彩比对 */}
          <TabsContent value="compare">
            <div className="card-rice-paper p-5 md:p-6">
              <div className="flex items-center gap-2 mb-1">
                <GitCompare className="w-4 h-4 text-primary" />
                <h3 className="font-kai text-base font-semibold text-foreground">{t('colorCompare')}</h3>
              </div>
              <p className="text-xs text-muted-foreground font-song mb-5">
                {t('compareHint')}
              </p>
              {loading ? (
                <Skeleton className="bg-muted h-40 rounded-xl" />
              ) : (
                <ColorCompare colorFavorites={colorFavorites} />
              )}
            </div>
          </TabsContent>

          {/* 自由调色 */}
          <TabsContent value="mixer">
            <div className="card-rice-paper p-5 md:p-6">
              <div className="flex items-center gap-2 mb-1">
                <Palette className="w-4 h-4 text-primary" />
                <h3 className="font-kai text-base font-semibold text-foreground">{t('colorMixer')}</h3>
              </div>
              <p className="text-xs text-muted-foreground font-song mb-5">
                {t('compareHint')}
              </p>
              <ColorMixer />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
