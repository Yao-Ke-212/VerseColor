import { defineConfig, loadEnv } from "vite";
import { miaodaDevPlugin } from "miaoda-sc-plugin";
import react from "@vitejs/plugin-react";
import svgr from "vite-plugin-svgr";
import path from "path";
import * as fs from "fs";

function supabaseAuthMock() {
  return {
    name: 'supabase-auth-mock',
    configureServer(server: any) {
      server.middlewares.use(async (req: any, res: any, next: any) => {
        if (req.url === '/api/auth/register' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => body += chunk);
          req.on('end', async () => {
            try {
              const { username, password } = JSON.parse(body);
              const email = `${username}@miaoda.com`;
              
              // Load .env
              const envFile = fs.readFileSync(path.resolve(__dirname, '.env'), 'utf-8');
              const envUrlMatch = envFile.match(/VITE_SUPABASE_URL=(.*)/);
              const envKeyMatch = envFile.match(/VITE_SUPABASE_ANON_KEY=(.*)/);
              const SUPABASE_URL = envUrlMatch ? envUrlMatch[1].trim() : '';
              const SUPABASE_KEY = envKeyMatch ? envKeyMatch[1].trim() : '';
              
              const response = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
                method: 'POST',
                headers: {
                  'apikey': SUPABASE_KEY,
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
              });
              const data = await response.json();
              
              // Simulate successful login immediately after register if Supabase succeeds
              if (response.ok) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 200;
                res.end(JSON.stringify({
                  code: 0,
                  message: 'success',
                  data: {
                    user: data.user,
                    session: data.session
                  }
                }));
              } else {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = response.status;
                res.end(JSON.stringify(data));
              }
            } catch (e: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
          return;
        }
        
        if (req.url === '/api/auth/login' && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk: any) => body += chunk);
          req.on('end', async () => {
            try {
              const { username, password } = JSON.parse(body);
              const email = `${username}@miaoda.com`;
              
              const envFile = fs.readFileSync(path.resolve(__dirname, '.env'), 'utf-8');
              const envUrlMatch = envFile.match(/VITE_SUPABASE_URL=(.*)/);
              const envKeyMatch = envFile.match(/VITE_SUPABASE_ANON_KEY=(.*)/);
              const SUPABASE_URL = envUrlMatch ? envUrlMatch[1].trim() : '';
              const SUPABASE_KEY = envKeyMatch ? envKeyMatch[1].trim() : '';
              
              const response = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
                method: 'POST',
                headers: {
                  'apikey': SUPABASE_KEY,
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
              });
              const data = await response.json();
              
              if (response.ok) {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = 200;
                res.end(JSON.stringify({
                  code: 0,
                  message: 'success',
                  data: {
                    user: data.user,
                    session: data.session
                  }
                }));
              } else {
                res.setHeader('Content-Type', 'application/json');
                res.statusCode = response.status;
                res.end(JSON.stringify(data));
              }
            } catch (e: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ error: e.message }));
            }
          });
          return;
        }
        next();
      });
    }
  };
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    miaodaDevPlugin(),
    supabaseAuthMock(),
    svgr({
      svgrOptions: {
        icon: true,
        exportType: "named",
        namedExport: "ReactComponent",
      },
    }),
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
