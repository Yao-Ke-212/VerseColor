import { getDynastyLabel } from './src/lib/dataLabels.js'

function t(key) {
  if (key === 'dyn_唐') return '唐';
  return key; // mock
}

console.log(getDynastyLabel('金', t));
